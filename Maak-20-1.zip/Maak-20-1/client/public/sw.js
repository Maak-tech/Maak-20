// Service Worker for Zeina Health Assistant - Mobile PWA functionality

const CACHE_NAME = 'zeina-mobile-v2.0';
const OFFLINE_URL = '/offline.html';

// Core mobile app URLs to cache
const urlsToCache = [
  '/',
  '/chat',
  '/dashboard', 
  '/mood',
  '/goals',
  '/emergency',
  '/medications',
  '/resources',
  '/settings',
  '/admin/members',
  '/admin/alerts', 
  '/admin/settings',
  '/attached_assets/generated_images/Maak_2.0_healthcare_logo_203f7d38.png',
  OFFLINE_URL
];

// Health-specific API endpoints to cache
const HEALTH_API_CACHE = [
  '/api/me/vitals',
  '/api/me/medications',
  '/api/me/health-goals', 
  '/api/me/mood-entries',
  '/api/me/emergency-contacts',
  '/api/me/health-insights'
];

// Install event - cache resources and skip waiting for mobile
self.addEventListener('install', (event) => {
  console.log('Zeina SW: Installing mobile service worker...');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Zeina SW: Caching mobile app resources');
        return cache.addAll(urlsToCache);
      })
      .then(() => {
        // Skip waiting to activate immediately for mobile updates
        return self.skipWaiting();
      })
  );
});

// Fetch event - serve from cache when offline
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Return cached version or fetch from network
        if (response) {
          return response;
        }
        
        // Important: Clone the request
        const fetchRequest = event.request.clone();
        
        return fetch(fetchRequest).then((response) => {
          // Check if valid response
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }
          
          // Important: Clone the response
          const responseToCache = response.clone();
          
          caches.open(CACHE_NAME)
            .then((cache) => {
              cache.put(event.request, responseToCache);
            });
          
          return response;
        });
      })
      .catch(() => {
        // Return offline page for navigation requests
        if (event.request.destination === 'document') {
          return caches.match('/');
        }
      })
  );
});

// Activate event - clean up old caches and claim clients for mobile
self.addEventListener('activate', (event) => {
  console.log('Zeina SW: Activating mobile service worker...');
  
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Zeina SW: Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      // Take control of all clients immediately for mobile
      return self.clients.claim();
    })
  );
});

// Enhanced background sync for mobile health data
self.addEventListener('sync', (event) => {
  console.log('Zeina SW: Background sync triggered:', event.tag);
  
  if (event.tag === 'health-data-sync') {
    event.waitUntil(syncHealthData());
  } else if (event.tag === 'mood-entry-sync') {
    event.waitUntil(syncMoodEntries());
  } else if (event.tag === 'chat-message-sync') {
    event.waitUntil(syncChatMessages());
  } else if (event.tag === 'vital-reading-sync') {
    event.waitUntil(syncVitalReadings());
  } else if (event.tag === 'background-sync') {
    event.waitUntil(syncPendingData());
  }
});

// Cache API responses
self.addEventListener('fetch', (event) => {
  if (event.request.url.includes('/api/')) {
    event.respondWith(
      caches.open('api-cache-v1').then(cache => {
        return fetch(event.request).then(response => {
          if (response.ok) {
            cache.put(event.request, response.clone());
          }
          return response;
        }).catch(() => {
          return cache.match(event.request);
        });
      })
    );
  }
});

// Push notification handling for health alerts
self.addEventListener('push', (event) => {
  console.log('Zeina SW: Push notification received');
  
  if (!event.data) return;

  const data = event.data.json();
  const title = data.title || 'Zeina Health Alert';
  
  const options = {
    body: data.body || 'You have a new health notification',
    icon: '/attached_assets/generated_images/Maak_2.0_healthcare_logo_203f7d38.png',
    badge: '/attached_assets/generated_images/Maak_2.0_healthcare_logo_203f7d38.png', 
    data: data,
    requireInteraction: data.emergency === true,
    tag: data.tag || 'health-notification',
    vibrate: data.emergency ? [200, 100, 200, 100, 200] : [100, 50, 100],
    actions: [
      {
        action: 'view',
        title: 'View Details',
        icon: '/attached_assets/generated_images/Maak_2.0_healthcare_logo_203f7d38.png'
      },
      {
        action: 'dismiss', 
        title: 'Dismiss'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

// Notification click handling for mobile
self.addEventListener('notificationclick', (event) => {
  console.log('Zeina SW: Notification clicked');
  
  event.notification.close();
  
  if (event.action === 'view') {
    const url = event.notification.data?.url || '/';
    event.waitUntil(
      clients.matchAll({ type: 'window' }).then((clients) => {
        // Check if app is already open
        for (const client of clients) {
          if (client.url === url && 'focus' in client) {
            return client.focus();
          }
        }
        // Open new window/tab
        if (clients.openWindow) {
          return clients.openWindow(url);
        }
      })
    );
  }
});

// Enhanced sync functions for mobile health data
async function syncHealthData() {
  console.log('Zeina SW: Syncing health data...');
  try {
    const cache = await caches.open('offline-health-data');
    const requests = await cache.keys();
    
    for (const request of requests) {
      try {
        await fetch(request);
        await cache.delete(request);
        console.log('Zeina SW: Successfully synced health data');
      } catch (error) {
        console.error('Zeina SW: Failed to sync health data:', error);
      }
    }
  } catch (error) {
    console.error('Zeina SW: Health data sync error:', error);
  }
}

async function syncMoodEntries() {
  console.log('Zeina SW: Syncing mood entries...');
  try {
    const cache = await caches.open('offline-mood-data');
    const requests = await cache.keys();
    
    for (const request of requests) {
      try {
        const response = await cache.match(request);
        if (response) {
          const data = await response.json();
          await fetch('/api/me/mood-entries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
          });
          await cache.delete(request);
        }
      } catch (error) {
        console.error('Zeina SW: Failed to sync mood entry:', error);
      }
    }
  } catch (error) {
    console.error('Zeina SW: Mood sync error:', error);
  }
}

async function syncChatMessages() {
  console.log('Zeina SW: Syncing chat messages...');
  try {
    const cache = await caches.open('offline-chat-data');
    const requests = await cache.keys();
    
    for (const request of requests) {
      try {
        const response = await cache.match(request);
        if (response) {
          const data = await response.json();
          await fetch('/api/me/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
          });
          await cache.delete(request);
        }
      } catch (error) {
        console.error('Zeina SW: Failed to sync chat message:', error);
      }
    }
  } catch (error) {
    console.error('Zeina SW: Chat sync error:', error);
  }
}

async function syncVitalReadings() {
  console.log('Zeina SW: Syncing vital readings...');
  try {
    const cache = await caches.open('offline-vitals-data');
    const requests = await cache.keys();
    
    for (const request of requests) {
      try {
        await fetch(request);
        await cache.delete(request);
      } catch (error) {
        console.error('Zeina SW: Failed to sync vital reading:', error);
      }
    }
  } catch (error) {
    console.error('Zeina SW: Vitals sync error:', error);
  }
}

async function syncPendingData() {
  console.log('Zeina SW: Syncing all pending data...');
  await Promise.all([
    syncHealthData(),
    syncMoodEntries(), 
    syncChatMessages(),
    syncVitalReadings()
  ]);
}