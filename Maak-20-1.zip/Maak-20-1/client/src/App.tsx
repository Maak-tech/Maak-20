import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/lib/auth";
import { useTranslation } from 'react-i18next';
import { useEffect } from 'react';
import Navigation from "@/components/Navigation";
import MobileNavigation from "@/components/MobileNavigation";
import PWAInstallPrompt from "@/components/PWAInstallPrompt";
import NotFound from "@/pages/not-found";

// User Pages
import Dashboard from "@/pages/user/Dashboard";
import FixedChat from "@/pages/user/FixedChat";
import Medications from "@/pages/user/Medications";
import Resources from "@/pages/user/Resources";
import Settings from "@/pages/user/Settings";
import LogSymptom from "@/pages/user/LogSymptom";

// Admin Pages
import Members from "@/pages/admin/Members";
import FamilyDashboard from "@/pages/admin/FamilyDashboard";
import MemberDetailView from "@/pages/admin/MemberDetailView";
import Alerts from "@/pages/admin/Alerts";
import MemberDetail from "@/pages/admin/MemberDetail";
import AdminSettings from "@/pages/admin/AdminSettings";

// Advanced Health Components
import AdvancedHealthGoals from "@/components/AdvancedHealthGoals";
import MoodTracker from "@/components/MoodTracker";
import HealthInsightsDashboard from "@/components/HealthInsightsDashboard";
import EmergencyAlertSystem from "@/components/EmergencyAlertSystem";

// Theme Provider
import { ThemeProvider } from "@/components/ThemeProvider";

function Router() {
  const { user, loading } = useAuth();
  const { t, i18n } = useTranslation();

  useEffect(() => {
    // Set document direction and language based on current language
    document.documentElement.dir = i18n.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = i18n.language;

    // Register service worker for PWA functionality
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
          .then((registration) => {
            console.log('Zeina SW registered: ', registration);
          })
          .catch((registrationError) => {
            console.log('Zeina SW registration failed: ', registrationError);
          });
      });
    }
  }, [i18n.language]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-pulse text-muted-foreground">{t('common.loading')}</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold text-foreground">{t('auth.welcome')}</h1>
          <p className="text-muted-foreground">{t('auth.signInPrompt')}</p>
        </div>
      </div>
    );
  }

  const isAdmin = user.role === "admin";

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Navigation */}
      <MobileNavigation emergencyAlerts={0} newInsights={0} />
      
      {/* Desktop Navigation */}
      <div className="hidden md:block">
        <Navigation userRole={isAdmin ? "admin" : "user"} />
      </div>
      
      {/* PWA Install Prompt */}
      <PWAInstallPrompt />
      
      <Switch>
        {/* User Routes */}
        {!isAdmin && (
          <>
            <Route path="/" component={Dashboard} />
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/chat" component={FixedChat} />
            <Route path="/medications" component={Medications} />
            <Route path="/resources" component={Resources} />
            <Route path="/settings" component={Settings} />
            <Route path="/log-symptom" component={LogSymptom} />
            
            {/* New Advanced Health Routes */}
            <Route path="/goals" component={AdvancedHealthGoals} />
            <Route path="/mood" component={MoodTracker} />
            <Route path="/insights" component={HealthInsightsDashboard} />
            <Route path="/emergency" component={EmergencyAlertSystem} />
          </>
        )}

        {/* Admin Routes */}
        {isAdmin && (
          <>
            <Route path="/" component={FamilyDashboard} />
            <Route path="/admin/dashboard" component={FamilyDashboard} />
            <Route path="/admin/members" component={Members} />
            <Route path="/admin/member/:id" component={MemberDetailView} />
            <Route path="/admin/alerts" component={Alerts} />
            <Route path="/admin/settings" component={AdminSettings} />
          </>
        )}

        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
      <Toaster />
    </ThemeProvider>
  );
}

export default App;