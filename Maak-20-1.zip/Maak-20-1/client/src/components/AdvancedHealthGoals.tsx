import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Target, Plus, TrendingUp, Calendar, CheckCircle, AlertCircle } from "lucide-react";

export default function AdvancedHealthGoals() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showNewGoal, setShowNewGoal] = useState(false);
  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    targetValue: '',
    unit: '',
    targetDate: '',
    category: 'fitness',
    priority: 1
  });

  // Fetch health goals
  const { data: goals, isLoading } = useQuery({
    queryKey: ["/api/me/health-goals"],
  });

  // Fetch goal recommendations
  const { data: recommendations } = useQuery({
    queryKey: ["/api/me/goal-recommendations"],
  });

  // Create new goal
  const createGoal = useMutation({
    mutationFn: async (goalData: any) => {
      const response = await fetch("/api/me/health-goals", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer mock"
        },
        body: JSON.stringify(goalData)
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/health-goals"] });
      setShowNewGoal(false);
      setNewGoal({
        title: '',
        description: '',
        targetValue: '',
        unit: '',
        targetDate: '',
        category: 'fitness',
        priority: 1
      });
      toast({ title: "Goal created successfully!" });
    }
  });

  // Update goal progress
  const updateProgress = useMutation({
    mutationFn: async ({ goalId, value, note }: any) => {
      const response = await fetch(`/api/me/health-goals/${goalId}/progress`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer mock"
        },
        body: JSON.stringify({ value, note })
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/health-goals"] });
      toast({ title: "Progress updated!" });
    }
  });

  const getPriorityColor = (priority: number) => {
    switch (priority) {
      case 3: return "bg-red-100 text-red-800";
      case 2: return "bg-yellow-100 text-yellow-800";
      case 1: return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'fitness': return '💪';
      case 'nutrition': return '🥗';
      case 'medication': return '💊';
      case 'mental_health': return '🧠';
      case 'cardiovascular': return '❤️';
      default: return '🎯';
    }
  };

  const calculateProgress = (current: number, target: number) => {
    return Math.min(100, Math.round((current / target) * 100));
  };

  if (isLoading) {
    return <div className="animate-pulse">Loading health goals...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Target className="w-6 h-6 text-blue-600" />
          <h2 className="text-2xl font-bold">Health Goals</h2>
        </div>
        <Dialog open={showNewGoal} onOpenChange={setShowNewGoal}>
          <DialogTrigger asChild>
            <Button className="flex items-center space-x-2">
              <Plus className="w-4 h-4" />
              <span>New Goal</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Health Goal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Goal Title</label>
                <Input
                  value={newGoal.title}
                  onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                  placeholder="e.g., Lower Blood Pressure"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Description</label>
                <Textarea
                  value={newGoal.description}
                  onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })}
                  placeholder="Describe your goal and motivation"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Target Value</label>
                  <Input
                    value={newGoal.targetValue}
                    onChange={(e) => setNewGoal({ ...newGoal, targetValue: e.target.value })}
                    placeholder="120"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Unit</label>
                  <Input
                    value={newGoal.unit}
                    onChange={(e) => setNewGoal({ ...newGoal, unit: e.target.value })}
                    placeholder="mmHg, kg, steps"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Category</label>
                  <Select value={newGoal.category} onValueChange={(value) => setNewGoal({ ...newGoal, category: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fitness">Fitness</SelectItem>
                      <SelectItem value="nutrition">Nutrition</SelectItem>
                      <SelectItem value="medication">Medication</SelectItem>
                      <SelectItem value="mental_health">Mental Health</SelectItem>
                      <SelectItem value="cardiovascular">Cardiovascular</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">Target Date</label>
                  <Input
                    type="date"
                    value={newGoal.targetDate}
                    onChange={(e) => setNewGoal({ ...newGoal, targetDate: e.target.value })}
                  />
                </div>
              </div>
              <Button 
                onClick={() => createGoal.mutate(newGoal)}
                disabled={!newGoal.title || !newGoal.targetValue}
                className="w-full"
              >
                Create Goal
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Goal Recommendations */}
      {recommendations && recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-green-600" />
              <span>Recommended Goals</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendations.slice(0, 4).map((rec: any, index: number) => (
                <div key={index} className="p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-2xl">{getCategoryIcon(rec.category)}</span>
                    <h4 className="font-semibold">{rec.title}</h4>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{rec.description}</p>
                  <div className="flex items-center justify-between">
                    <Badge className={getPriorityColor(rec.priority === 'high' ? 3 : rec.priority === 'medium' ? 2 : 1)}>
                      {rec.priority} priority
                    </Badge>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setNewGoal({
                          title: rec.title,
                          description: rec.description,
                          targetValue: rec.targetValue || '',
                          unit: rec.unit || '',
                          targetDate: '',
                          category: rec.category,
                          priority: rec.priority === 'high' ? 3 : rec.priority === 'medium' ? 2 : 1
                        });
                        setShowNewGoal(true);
                      }}
                    >
                      Use Template
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Current Goals */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {goals && goals.length > 0 ? (
          goals.map((goal: any) => {
            const progress = calculateProgress(parseFloat(goal.currentValue || '0'), parseFloat(goal.targetValue));
            const isCompleted = progress >= 100;
            const isOverdue = goal.targetDate && new Date(goal.targetDate) < new Date();
            
            return (
              <Card key={goal.id} className={`${isCompleted ? 'ring-2 ring-green-500' : ''}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-2xl">{getCategoryIcon(goal.category)}</span>
                      <div>
                        <CardTitle className="text-lg">{goal.title}</CardTitle>
                        {isCompleted && <CheckCircle className="w-5 h-5 text-green-500 inline ml-2" />}
                        {isOverdue && !isCompleted && <AlertCircle className="w-5 h-5 text-red-500 inline ml-2" />}
                      </div>
                    </div>
                    <Badge className={getPriorityColor(goal.priority)}>
                      {goal.priority === 3 ? 'High' : goal.priority === 2 ? 'Medium' : 'Low'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">{goal.description}</p>
                  
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Progress</span>
                      <span>{goal.currentValue || 0} / {goal.targetValue} {goal.unit}</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                    <p className="text-xs text-gray-500 mt-1">{progress}% complete</p>
                  </div>

                  {goal.targetDate && (
                    <div className="flex items-center space-x-2 text-sm text-gray-600 mb-4">
                      <Calendar className="w-4 h-4" />
                      <span>Target: {new Date(goal.targetDate).toLocaleDateString()}</span>
                    </div>
                  )}

                  <div className="flex space-x-2">
                    <Input
                      placeholder="Update progress"
                      type="number"
                      className="flex-1"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          const value = (e.target as HTMLInputElement).value;
                          if (value) {
                            updateProgress.mutate({ goalId: goal.id, value: parseFloat(value), note: '' });
                            (e.target as HTMLInputElement).value = '';
                          }
                        }
                      }}
                    />
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => {
                        const input = e.currentTarget.parentElement?.querySelector('input') as HTMLInputElement;
                        const value = input?.value;
                        if (value) {
                          updateProgress.mutate({ goalId: goal.id, value: parseFloat(value), note: '' });
                          input.value = '';
                        }
                      }}
                    >
                      Update
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })
        ) : (
          <Card className="col-span-full">
            <CardContent className="p-8 text-center">
              <Target className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Health Goals Yet</h3>
              <p className="text-gray-600 mb-4">Create your first health goal to start tracking your progress</p>
              <Button onClick={() => setShowNewGoal(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Goal
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}