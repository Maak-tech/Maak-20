import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertTriangle, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface AlertBannerProps {
  type: "warning" | "critical" | "info";
  title: string;
  message: string;
  onDismiss?: () => void;
  className?: string;
}

export default function AlertBanner({
  type,
  title,
  message,
  onDismiss,
  className = ""
}: AlertBannerProps) {
  const typeConfig = {
    warning: {
      bgColor: "bg-yellow-50 border-yellow-200",
      iconColor: "text-yellow-600",
      titleColor: "text-yellow-800",
      messageColor: "text-yellow-700",
      dismissColor: "text-yellow-600 hover:text-yellow-800"
    },
    critical: {
      bgColor: "bg-red-50 border-red-200", 
      iconColor: "text-red-600",
      titleColor: "text-red-800",
      messageColor: "text-red-700",
      dismissColor: "text-red-600 hover:text-red-800"
    },
    info: {
      bgColor: "bg-blue-50 border-blue-200",
      iconColor: "text-blue-600", 
      titleColor: "text-blue-800",
      messageColor: "text-blue-700",
      dismissColor: "text-blue-600 hover:text-blue-800"
    }
  };

  const config = typeConfig[type];

  return (
    <Alert className={cn(config.bgColor, "p-4 mb-6", className)} data-testid={`alert-banner-${type}`}>
      <div className="flex items-start">
        <AlertTriangle className={cn("w-5 h-5 mt-0.5 mr-3", config.iconColor)} />
        <div className="flex-1">
          <h3 className={cn("text-sm font-medium", config.titleColor)} data-testid="text-alert-title">
            {title}
          </h3>
          <AlertDescription className={cn("text-sm mt-1", config.messageColor)} data-testid="text-alert-message">
            {message}
          </AlertDescription>
        </div>
        {onDismiss && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onDismiss}
            className={cn("ml-auto -mr-2 -mt-2", config.dismissColor)}
            data-testid="button-dismiss-alert"
          >
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>
    </Alert>
  );
}
