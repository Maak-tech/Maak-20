import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from 'react-i18next';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Send } from "lucide-react";

interface ChatFixProps {
  onMessageSent?: () => void;
}

export function ChatFix({ onMessageSent }: ChatFixProps) {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");

  // Fixed send message mutation
  const sendMessage = useMutation({
    mutationFn: async (messageText: string) => {
      try {
        const response = await fetch("/api/me/conversations", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer mock"
          },
          body: JSON.stringify({
            message: messageText,
            language: i18n.language || "en"
          })
        });

        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`HTTP ${response.status}: ${errorText}`);
        }

        const data = await response.json();
        return data;
      } catch (error) {
        console.error("Send message error:", error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log("Message sent successfully:", data);
      queryClient.invalidateQueries({ queryKey: ["/api/me/conversations"] });
      setMessage("");
      
      toast({
        title: "Message sent!",
        description: data.zeinaResponse?.message ? "Zeina responded" : "Message delivered"
      });
      
      onMessageSent?.();
    },
    onError: (error: any) => {
      console.error("Chat send error:", error);
      toast({
        title: "Failed to send message",
        description: error?.message || "Please try again",
        variant: "destructive"
      });
    }
  });

  const handleSendMessage = () => {
    if (!message.trim()) return;
    console.log("Sending message:", message.trim());
    sendMessage.mutate(message.trim());
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex items-end space-x-4 p-4 border-t">
      <div className="flex-1">
        <Textarea
          placeholder="Type your message to Zeina..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="resize-none"
          rows={3}
          onKeyDown={handleKeyPress}
          disabled={sendMessage.isPending}
        />
      </div>
      <Button
        onClick={handleSendMessage}
        disabled={!message.trim() || sendMessage.isPending}
        className="flex items-center space-x-2"
      >
        {sendMessage.isPending ? (
          <span>Sending...</span>
        ) : (
          <>
            <span>Send</span>
            <Send className="w-4 h-4" />
          </>
        )}
      </Button>
    </div>
  );
}