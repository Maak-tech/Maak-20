import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  AlertTriangle, Phone, UserPlus, Shield, Clock, 
  CheckCircle, X, Edit, Trash2
} from "lucide-react";

export default function EmergencyAlertSystem() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showAddContact, setShowAddContact] = useState(false);
  const [newContact, setNewContact] = useState({
    name: '',
    relationship: '',
    phoneNumber: '',
    email: '',
    priority: 1,
    notifyForEmergencies: true
  });

  // Fetch emergency contacts
  const { data: contacts, isLoading } = useQuery({
    queryKey: ["/api/me/emergency-contacts"],
  });

  // Fetch recent alerts
  const { data: recentAlerts } = useQuery({
    queryKey: ["/api/me/emergency-alerts"],
  });

  // Add emergency contact
  const addContact = useMutation({
    mutationFn: async (contactData: any) => {
      const response = await fetch("/api/me/emergency-contacts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer mock"
        },
        body: JSON.stringify(contactData)
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/emergency-contacts"] });
      setShowAddContact(false);
      setNewContact({
        name: '',
        relationship: '',
        phoneNumber: '',
        email: '',
        priority: 1,
        notifyForEmergencies: true
      });
      toast({ title: "Emergency contact added!" });
    }
  });

  // Test emergency system
  const testEmergencySystem = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/me/emergency-test", {
        method: "POST",
        headers: {
          "Authorization": "Bearer mock"
        }
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ 
        title: "Emergency system test sent", 
        description: "Test notifications sent to all emergency contacts"
      });
    }
  });

  const getPriorityBadge = (priority: number) => {
    const colors = {
      1: "bg-red-100 text-red-800",
      2: "bg-orange-100 text-orange-800", 
      3: "bg-yellow-100 text-yellow-800"
    };
    const labels = { 1: "Primary", 2: "Secondary", 3: "Other" };
    return (
      <Badge className={colors[priority as keyof typeof colors]}>
        {labels[priority as keyof typeof labels]}
      </Badge>
    );
  };

  const getAlertSeverity = (level: number) => {
    switch (level) {
      case 3: return { color: "text-red-600", icon: AlertTriangle, label: "Critical Emergency" };
      case 2: return { color: "text-orange-600", icon: AlertTriangle, label: "Urgent Alert" };
      case 1: return { color: "text-yellow-600", icon: AlertTriangle, label: "Health Concern" };
      default: return { color: "text-gray-600", icon: CheckCircle, label: "Normal" };
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Shield className="w-6 h-6 text-red-600" />
          <h2 className="text-2xl font-bold">Emergency Alert System</h2>
        </div>
        <Button 
          onClick={() => testEmergencySystem.mutate()}
          variant="outline"
          className="flex items-center space-x-2"
        >
          <Shield className="w-4 h-4" />
          <span>Test System</span>
        </Button>
      </div>

      {/* Emergency Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-green-600" />
            <span>System Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div>
                <div className="font-semibold">System Active</div>
                <div className="text-sm text-gray-600">24/7 monitoring enabled</div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Phone className="w-8 h-8 text-blue-600" />
              <div>
                <div className="font-semibold">{contacts?.length || 0} Contacts</div>
                <div className="text-sm text-gray-600">Ready to be notified</div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Clock className="w-8 h-8 text-purple-600" />
              <div>
                <div className="font-semibold">Last Check</div>
                <div className="text-sm text-gray-600">2 minutes ago</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Alerts */}
      {recentAlerts && recentAlerts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Emergency Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentAlerts.slice(0, 3).map((alert: any) => {
                const severity = getAlertSeverity(alert.level);
                const SeverityIcon = severity.icon;
                
                return (
                  <Alert key={alert.id}>
                    <SeverityIcon className={`h-4 w-4 ${severity.color}`} />
                    <AlertDescription>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-semibold">{severity.label}</div>
                          <div className="text-sm">{alert.message}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-gray-500">
                            {new Date(alert.createdAt).toLocaleString()}
                          </div>
                          <Badge variant={alert.resolved ? "outline" : "default"}>
                            {alert.resolved ? "Resolved" : "Active"}
                          </Badge>
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Emergency Contacts */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Emergency Contacts</CardTitle>
            <Dialog open={showAddContact} onOpenChange={setShowAddContact}>
              <DialogTrigger asChild>
                <Button className="flex items-center space-x-2">
                  <UserPlus className="w-4 h-4" />
                  <span>Add Contact</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Emergency Contact</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Full Name</label>
                    <Input
                      value={newContact.name}
                      onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                      placeholder="Dr. Sarah Johnson"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Relationship</label>
                    <Select value={newContact.relationship} onValueChange={(value) => setNewContact({ ...newContact, relationship: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select relationship" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="family">Family Member</SelectItem>
                        <SelectItem value="doctor">Doctor</SelectItem>
                        <SelectItem value="emergency">Emergency Service</SelectItem>
                        <SelectItem value="friend">Friend</SelectItem>
                        <SelectItem value="caregiver">Caregiver</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Phone Number</label>
                      <Input
                        value={newContact.phoneNumber}
                        onChange={(e) => setNewContact({ ...newContact, phoneNumber: e.target.value })}
                        placeholder="+1 555 123 4567"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Email</label>
                      <Input
                        type="email"
                        value={newContact.email}
                        onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
                        placeholder="doctor@clinic.com"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Priority Level</label>
                    <Select value={newContact.priority.toString()} onValueChange={(value) => setNewContact({ ...newContact, priority: parseInt(value) })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Primary - Contact first</SelectItem>
                        <SelectItem value="2">Secondary - Contact if primary unavailable</SelectItem>
                        <SelectItem value="3">Other - Notify but not urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button 
                    onClick={() => addContact.mutate(newContact)}
                    disabled={!newContact.name || !newContact.phoneNumber}
                    className="w-full"
                  >
                    Add Emergency Contact
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {contacts && contacts.length > 0 ? (
            <div className="space-y-4">
              {contacts.sort((a: any, b: any) => a.priority - b.priority).map((contact: any) => (
                <div key={contact.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Phone className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-semibold">{contact.name}</div>
                      <div className="text-sm text-gray-600 capitalize">{contact.relationship}</div>
                      <div className="text-sm text-gray-500">{contact.phoneNumber}</div>
                      {contact.email && (
                        <div className="text-sm text-gray-500">{contact.email}</div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    {getPriorityBadge(contact.priority)}
                    <div className="flex space-x-1">
                      <Button variant="ghost" size="sm">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="text-red-600">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Phone className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No emergency contacts</h3>
              <p className="text-gray-600 mb-4">Add trusted contacts who should be notified in case of health emergencies</p>
              <Button onClick={() => setShowAddContact(true)}>
                <UserPlus className="w-4 h-4 mr-2" />
                Add Your First Contact
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Emergency Detection Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Detection Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <div className="font-medium">Critical Symptoms Detection</div>
                <div className="text-sm text-gray-600">Automatically detect emergency keywords and symptoms</div>
              </div>
              <Badge className="bg-green-100 text-green-800">Enabled</Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <div className="font-medium">Vital Signs Monitoring</div>
                <div className="text-sm text-gray-600">Alert when vital signs exceed safe thresholds</div>
              </div>
              <Badge className="bg-green-100 text-green-800">Enabled</Badge>
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <div className="font-medium">Medication Crisis Detection</div>
                <div className="text-sm text-gray-600">Alert when medication adherence drops critically</div>
              </div>
              <Badge className="bg-green-100 text-green-800">Enabled</Badge>
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <div className="font-medium">24/7 Monitoring</div>
                <div className="text-sm text-gray-600">Round-the-clock health pattern analysis</div>
              </div>
              <Badge className="bg-green-100 text-green-800">Active</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}