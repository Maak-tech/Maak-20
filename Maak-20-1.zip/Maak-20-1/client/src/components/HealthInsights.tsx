import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  AlertCircle, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle, 
  Brain, 
  Target, 
  Zap, 
  Clock, 
  Heart, 
  Activity, 
  Lightbulb, 
  ArrowRight, 
  BarChart3
} from 'lucide-react';

interface HealthInsightsProps {
  vitals: any;
  symptoms: any[];
  medications: any[];
}

export default function HealthInsights({ vitals, symptoms, medications }: HealthInsightsProps) {
  const [activeTab, setActiveTab] = useState('insights');
  const [healthScore, setHealthScore] = useState(0);
  const [predictions, setPredictions] = useState<any>({});
  const [recommendations, setRecommendations] = useState<any[]>([]);

  // Calculate comprehensive health score
  useEffect(() => {
    const score = calculateHealthScore(vitals, symptoms, medications);
    setHealthScore(score);
    
    const predictiveAnalysis = generatePredictiveAnalysis(vitals, symptoms, medications);
    setPredictions(predictiveAnalysis);
    
    const personalizedRecs = generatePersonalizedRecommendations(vitals, symptoms, medications);
    setRecommendations(personalizedRecs);
  }, [vitals, symptoms, medications]);

  const calculateHealthScore = (vitals: any, symptoms: any, medications: any): number => {
    let score = 100;
    
    // Vital signs impact (40% of score)
    const bpSystolic = vitals?.bp_systolic?.[0]?.value;
    const heartRate = vitals?.heart_rate?.[0]?.value;
    const spo2 = vitals?.spo2?.[0]?.value;
    
    if (bpSystolic) {
      const bp = parseInt(bpSystolic);
      if (bp > 140) score -= 20;
      else if (bp > 130) score -= 10;
      else if (bp >= 120) score -= 5;
    }
    
    if (heartRate) {
      const hr = parseInt(heartRate);
      if (hr > 100 || hr < 60) score -= 10;
    }
    
    if (spo2) {
      const oxygen = parseInt(spo2);
      if (oxygen < 95) score -= 15;
      else if (oxygen < 98) score -= 5;
    }
    
    // Symptoms impact (30% of score)
    const recentSymptoms = symptoms?.filter((s: any) => 
      new Date(s.reportedAt || s.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    ) || [];
    
    const severeSymptoms = recentSymptoms.filter((s: any) => s.severity >= 7);
    score -= recentSymptoms.length * 3;
    score -= severeSymptoms.length * 5;
    
    // Medication adherence impact (30% of score)
    if (medications?.length > 0) {
      const adherenceRate = calculateMedicationAdherence(medications);
      score -= (100 - adherenceRate) * 0.2;
    }
    
    return Math.max(0, Math.min(100, Math.round(score)));
  };

  const calculateMedicationAdherence = (medications: any[]): number => {
    if (!medications || medications.length === 0) return 100;
    
    let totalDoses = 0;
    let takenDoses = 0;
    
    medications.forEach(med => {
      totalDoses += med.totalDoses || 7; // Assume 7 doses per week if not specified
      takenDoses += (med.totalDoses || 7) - (med.missedDoses || 0);
    });
    
    return totalDoses > 0 ? Math.round((takenDoses / totalDoses) * 100) : 100;
  };

  const generatePredictiveAnalysis = (vitals: any, symptoms: any, medications: any) => {
    const predictions: any = {
      riskLevel: 'low',
      cardiovascularRisk: 0,
      weeklyTrend: 'stable',
      nextWeekPrediction: {},
      alerts: []
    };
    
    // Cardiovascular risk prediction
    const bpReadings = vitals?.bp_systolic?.slice(0, 7) || [];
    if (bpReadings.length >= 3) {
      const values = bpReadings.map((v: any) => parseInt(v.value));
      const trend = values[0] - values[values.length - 1];
      const avgBP = values.reduce((a: number, b: number) => a + b, 0) / values.length;
      
      if (avgBP > 140) predictions.cardiovascularRisk = 75;
      else if (avgBP > 130) predictions.cardiovascularRisk = 45;
      else if (avgBP > 120) predictions.cardiovascularRisk = 25;
      else predictions.cardiovascularRisk = 10;
      
      if (trend > 10) {
        predictions.weeklyTrend = 'increasing';
        predictions.nextWeekPrediction.bp = avgBP + (trend * 0.7);
        predictions.alerts.push('Blood pressure trend suggests potential increase next week');
      } else if (trend < -10) {
        predictions.weeklyTrend = 'improving';
        predictions.nextWeekPrediction.bp = Math.max(110, avgBP + (trend * 0.3));
      } else {
        predictions.nextWeekPrediction.bp = avgBP;
      }
    }
    
    // Symptom pattern prediction
    const recentSymptoms = symptoms?.filter((s: any) => 
      new Date(s.reportedAt || s.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    )?.length || 0;
    
    if (recentSymptoms > 5) {
      predictions.riskLevel = 'high';
      predictions.alerts.push('High symptom frequency detected - recommend medical consultation');
    } else if (recentSymptoms > 2) {
      predictions.riskLevel = 'moderate';
    }
    
    return predictions;
  };

  const generatePersonalizedRecommendations = (vitals: any, symptoms: any, medications: any) => {
    const recommendations = [];
    
    const bpSystolic = vitals?.bp_systolic?.[0]?.value;
    const adherenceRate = calculateMedicationAdherence(medications);
    
    // BP-specific recommendations
    if (bpSystolic && parseInt(bpSystolic) > 130) {
      recommendations.push({
        category: 'Cardiovascular',
        priority: 'high',
        title: 'Blood Pressure Management',
        description: 'Your BP is elevated. Consider reducing sodium intake and increasing physical activity.',
        actions: [
          'Limit sodium to 2,300mg per day',
          'Take a 30-minute walk daily',
          'Practice deep breathing exercises',
          'Monitor BP twice daily'
        ],
        estimatedImpact: '10-15 mmHg reduction',
        timeframe: '2-4 weeks',
        icon: <Heart className="w-5 h-5" />
      });
    }
    
    // Medication adherence recommendations
    if (adherenceRate < 85) {
      recommendations.push({
        category: 'Medication',
        priority: 'high',
        title: 'Improve Medication Adherence',
        description: `Your adherence rate is ${adherenceRate}%. Better consistency can significantly improve outcomes.`,
        actions: [
          'Set daily medication reminders',
          'Use a pill organizer',
          'Keep medications visible',
          'Track missed doses'
        ],
        estimatedImpact: 'Better symptom control',
        timeframe: '1-2 weeks',
        icon: <Clock className="w-5 h-5" />
      });
    }
    
    // Activity recommendations
    const recentSymptoms = symptoms?.filter((s: any) => 
      new Date(s.reportedAt || s.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    ) || [];
    
    if (recentSymptoms.length <= 2 && healthScore > 70) {
      recommendations.push({
        category: 'Wellness',
        priority: 'medium',
        title: 'Enhance Your Health Journey',
        description: 'Your health metrics are stable. Time to focus on optimization and prevention.',
        actions: [
          'Increase exercise intensity gradually',
          'Add strength training 2x/week',
          'Focus on sleep quality (7-9 hours)',
          'Consider meditation or yoga'
        ],
        estimatedImpact: 'Improved overall wellness',
        timeframe: '4-6 weeks',
        icon: <Target className="w-5 h-5" />
      });
    }
    
    return recommendations;
  };

  const generateAdvancedInsights = () => {
    const insights = [];
    
    // Enhanced blood pressure analysis
    const bpReadings = vitals?.bp_systolic?.slice(0, 7) || [];
    if (bpReadings.length >= 3) {
      const values = bpReadings.map((v: any) => parseInt(v.value));
      const trend = values[0] - values[values.length - 1];
      const volatility = calculateVolatility(values);
      
      if (trend > 15) {
        insights.push({
          type: 'critical',
          title: 'Significant BP Increase',
          description: `Blood pressure rose ${trend} points over recent readings. Immediate attention recommended.`,
          icon: <AlertCircle className="w-4 h-4" />,
          action: 'Contact healthcare provider'
        });
      } else if (trend > 5) {
        insights.push({
          type: 'warning',
          title: 'Blood Pressure Rising',
          description: `BP increased by ${trend} points. Monitor closely and consider lifestyle adjustments.`,
          icon: <TrendingUp className="w-4 h-4" />,
          action: 'Increase monitoring frequency'
        });
      } else if (trend < -10) {
        insights.push({
          type: 'positive',
          title: 'Excellent BP Improvement',
          description: `Outstanding! BP decreased by ${Math.abs(trend)} points. Keep up the great work!`,
          icon: <TrendingDown className="w-4 h-4" />,
          action: 'Continue current regimen'
        });
      }
      
      if (volatility > 20) {
        insights.push({
          type: 'info',
          title: 'High BP Variability',
          description: 'Your blood pressure shows high variability. Consider stress management techniques.',
          icon: <Activity className="w-4 h-4" />,
          action: 'Practice stress reduction'
        });
      }
    }
    
    // Medication adherence insights
    const adherenceRate = calculateMedicationAdherence(medications);
    if (adherenceRate < 70) {
      insights.push({
        type: 'critical',
        title: 'Poor Medication Adherence',
        description: `Only ${adherenceRate}% adherence. This significantly impacts treatment effectiveness.`,
        icon: <AlertCircle className="w-4 h-4" />,
        action: 'Implement adherence strategies'
      });
    } else if (adherenceRate >= 95) {
      insights.push({
        type: 'positive',
        title: 'Excellent Medication Adherence',
        description: `Outstanding ${adherenceRate}% adherence! Your consistency is paying off.`,
        icon: <CheckCircle className="w-4 h-4" />,
        action: 'Keep up the excellent work'
      });
    }
    
    return insights;
  };

  const calculateVolatility = (values: number[]): number => {
    if (values.length < 2) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = values.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / values.length;
    return Math.sqrt(variance);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600 dark:text-green-400';
    if (score >= 60) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getScoreBackground = (score: number) => {
    if (score >= 80) return 'from-green-500 to-green-600';
    if (score >= 60) return 'from-yellow-500 to-yellow-600';
    return 'from-red-500 to-red-600';
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-300';
      case 'moderate': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-300';
      case 'high': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-300';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const insights = generateAdvancedInsights();

  return (
    <div className="space-y-6">
      {/* Health Score Dashboard */}
      <Card className="relative overflow-hidden">
        <div className={`absolute inset-0 bg-gradient-to-r ${getScoreBackground(healthScore)} opacity-10`}></div>
        <CardHeader className="relative">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className={`w-10 h-10 rounded-full bg-gradient-to-r ${getScoreBackground(healthScore)} flex items-center justify-center`}>
                <Activity className="w-5 h-5 text-white" />
              </div>
              <span>Health Score</span>
            </div>
            <div className={`text-3xl font-bold ${getScoreColor(healthScore)}`}>
              {healthScore}/100
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="relative">
          <Progress value={healthScore} className="h-3 mb-4" />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="text-center">
              <div className="font-medium text-muted-foreground">Risk Level</div>
              <Badge className={getRiskLevelColor(predictions.riskLevel)}>
                {predictions.riskLevel?.toUpperCase()}
              </Badge>
            </div>
            <div className="text-center">
              <div className="font-medium text-muted-foreground">CV Risk</div>
              <div className="font-bold">{predictions.cardiovascularRisk || 0}%</div>
            </div>
            <div className="text-center">
              <div className="font-medium text-muted-foreground">Trend</div>
              <div className="font-bold capitalize">{predictions.weeklyTrend || 'stable'}</div>
            </div>
            <div className="text-center">
              <div className="font-medium text-muted-foreground">Adherence</div>
              <div className="font-bold">{calculateMedicationAdherence(medications)}%</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Navigation Tabs */}
      <div className="flex space-x-1 bg-muted p-1 rounded-lg">
        {[
          { id: 'insights', label: 'Insights', icon: <Lightbulb className="w-4 h-4" /> },
          { id: 'predictions', label: 'Predictions', icon: <BarChart3 className="w-4 h-4" /> },
          { id: 'recommendations', label: 'Recommendations', icon: <Target className="w-4 h-4" /> }
        ].map(tab => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab(tab.id)}
            className="flex items-center space-x-2 flex-1"
          >
            {tab.icon}
            <span>{tab.label}</span>
          </Button>
        ))}
      </div>

      {/* Content based on active tab */}
      {activeTab === 'insights' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="w-5 h-5" />
              <span>AI-Powered Health Insights</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {insights.map((insight, index) => (
                <div key={index} className={`p-4 rounded-lg border transition-all hover:shadow-md ${
                  insight.type === 'warning' ? 'border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20 dark:border-yellow-800' :
                  insight.type === 'positive' ? 'border-green-200 bg-green-50 dark:bg-green-900/20 dark:border-green-800' :
                  insight.type === 'critical' ? 'border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-800' :
                  'border-blue-200 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-800'
                }`}>
                  <div className="flex items-start space-x-3">
                    <div className={`mt-0.5 ${
                      insight.type === 'warning' ? 'text-yellow-600' :
                      insight.type === 'positive' ? 'text-green-600' :
                      insight.type === 'critical' ? 'text-red-600' :
                      'text-blue-600'
                    }`}>
                      {insight.icon}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-foreground">{insight.title}</h4>
                      <p className="text-sm text-muted-foreground mt-1">{insight.description}</p>
                      {insight.action && (
                        <div className="mt-2">
                          <Button variant="outline" size="sm" className="text-xs">
                            {insight.action}
                            <ArrowRight className="w-3 h-3 ml-1" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              {insights.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No specific insights available yet.</p>
                  <p className="text-sm">Keep tracking your health data to see personalized recommendations.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'predictions' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="w-5 h-5" />
              <span>Predictive Analytics</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Risk Assessment */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg border">
                  <h4 className="font-medium mb-3 flex items-center">
                    <Heart className="w-4 h-4 mr-2 text-red-500" />
                    Cardiovascular Risk
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Risk Level</span>
                      <span className="font-medium">{predictions.cardiovascularRisk || 0}%</span>
                    </div>
                    <Progress value={predictions.cardiovascularRisk || 0} className="h-2" />
                    <p className="text-xs text-muted-foreground">
                      Based on BP trends, symptoms, and lifestyle factors
                    </p>
                  </div>
                </div>
                
                <div className="p-4 rounded-lg border">
                  <h4 className="font-medium mb-3 flex items-center">
                    <TrendingUp className="w-4 h-4 mr-2 text-blue-500" />
                    Weekly Trend
                  </h4>
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${
                      predictions.weeklyTrend === 'improving' ? 'text-green-600' :
                      predictions.weeklyTrend === 'increasing' ? 'text-red-600' :
                      'text-blue-600'
                    }`}>
                      {predictions.weeklyTrend?.toUpperCase() || 'STABLE'}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Overall health trajectory
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Next Week Predictions */}
              {predictions.nextWeekPrediction?.bp && (
                <div className="p-4 rounded-lg border bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
                  <h4 className="font-medium mb-3 flex items-center">
                    <Zap className="w-4 h-4 mr-2 text-purple-500" />
                    Next Week Prediction
                  </h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Predicted BP:</span>
                      <div className="font-bold text-lg">{Math.round(predictions.nextWeekPrediction.bp)}/85</div>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Confidence:</span>
                      <div className="font-bold text-lg">75%</div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Alerts */}
              {predictions.alerts?.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center">
                    <AlertCircle className="w-4 h-4 mr-2 text-amber-500" />
                    Predictive Alerts
                  </h4>
                  {predictions.alerts.map((alert: string, index: number) => (
                    <div key={index} className="p-3 rounded-lg border border-amber-200 bg-amber-50 dark:bg-amber-900/20 dark:border-amber-800">
                      <p className="text-sm">{alert}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'recommendations' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5" />
              <span>Personalized Recommendations</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recommendations.map((rec, index) => (
                <div key={index} className={`p-6 rounded-lg border transition-all hover:shadow-md ${
                  rec.priority === 'high' ? 'border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-800' :
                  rec.priority === 'medium' ? 'border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20 dark:border-yellow-800' :
                  'border-green-200 bg-green-50 dark:bg-green-900/20 dark:border-green-800'
                }`}>
                  <div className="flex items-start space-x-4">
                    <div className={`p-2 rounded-lg ${
                      rec.priority === 'high' ? 'bg-red-100 text-red-600' :
                      rec.priority === 'medium' ? 'bg-yellow-100 text-yellow-600' :
                      'bg-green-100 text-green-600'
                    }`}>
                      {rec.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{rec.title}</h4>
                        <Badge variant="outline" className="text-xs">
                          {rec.category}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-4">{rec.description}</p>
                      
                      <div className="space-y-3">
                        <div>
                          <h5 className="font-medium text-sm mb-2">Action Steps:</h5>
                          <ul className="space-y-1">
                            {rec.actions.map((action: string, actionIndex: number) => (
                              <li key={actionIndex} className="text-sm flex items-center">
                                <CheckCircle className="w-3 h-3 mr-2 text-green-500" />
                                {action}
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 text-xs">
                          <div>
                            <span className="font-medium text-muted-foreground">Expected Impact:</span>
                            <div className="font-medium">{rec.estimatedImpact}</div>
                          </div>
                          <div>
                            <span className="font-medium text-muted-foreground">Timeframe:</span>
                            <div className="font-medium">{rec.timeframe}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {recommendations.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No specific recommendations available yet.</p>
                  <p className="text-sm">Your health data will generate personalized action plans.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}