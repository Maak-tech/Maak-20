import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle, 
  Brain, Heart, Activity, Calendar, Target, Lightbulb
} from "lucide-react";

export default function HealthInsightsDashboard() {
  // Fetch health insights
  const { data: insights, isLoading } = useQuery({
    queryKey: ["/api/me/health-insights"],
  });

  // Fetch health analytics
  const { data: analytics } = useQuery({
    queryKey: ["/api/me/health-analytics"],
  });

  const getPriorityIcon = (priority: number) => {
    switch (priority) {
      case 3: return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 2: return <TrendingUp className="w-4 h-4 text-yellow-500" />;
      case 1: return <CheckCircle className="w-4 h-4 text-green-500" />;
      default: return <Lightbulb className="w-4 h-4 text-blue-500" />;
    }
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'trend_alert': return <TrendingUp className="w-5 h-5" />;
      case 'recommendation': return <Lightbulb className="w-5 h-5" />;
      case 'weekly_summary': return <Calendar className="w-5 h-5" />;
      case 'monthly_report': return <Activity className="w-5 h-5" />;
      default: return <Brain className="w-5 h-5" />;
    }
  };

  const getHealthScore = () => {
    if (!analytics) return 75;
    return Math.round((analytics.vitalScore + analytics.adherenceScore + analytics.moodScore) / 3);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  if (isLoading) {
    return <div className="animate-pulse">Loading health insights...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-2">
        <Brain className="w-6 h-6 text-purple-600" />
        <h2 className="text-2xl font-bold">Health Insights & Analytics</h2>
      </div>

      {/* Health Score Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <div className={`text-3xl font-bold ${getScoreColor(getHealthScore())}`}>
              {getHealthScore()}
            </div>
            <div className="text-sm text-gray-600">Overall Health Score</div>
            <Progress value={getHealthScore()} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-blue-600">
              {analytics?.vitalScore || 85}
            </div>
            <div className="text-sm text-gray-600">Vital Signs</div>
            <div className="flex items-center justify-center mt-1">
              <Heart className="w-4 h-4 mr-1" />
              <TrendingUp className="w-4 h-4 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-green-600">
              {analytics?.adherenceScore || 92}
            </div>
            <div className="text-sm text-gray-600">Medication Adherence</div>
            <div className="flex items-center justify-center mt-1">
              <Target className="w-4 h-4 mr-1" />
              <CheckCircle className="w-4 h-4 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-purple-600">
              {analytics?.moodScore || 68}
            </div>
            <div className="text-sm text-gray-600">Mental Wellbeing</div>
            <div className="flex items-center justify-center mt-1">
              <Brain className="w-4 h-4 mr-1" />
              <TrendingUp className="w-4 h-4 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Insights Tabs */}
      <Tabs defaultValue="recent" className="space-y-4">
        <TabsList>
          <TabsTrigger value="recent">Recent Insights</TabsTrigger>
          <TabsTrigger value="trends">Health Trends</TabsTrigger>
          <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
          <TabsTrigger value="reports">Weekly Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="recent">
          <div className="space-y-4">
            {insights && insights.length > 0 ? (
              insights.slice(0, 6).map((insight: any) => (
                <Card key={insight.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3 flex-1">
                        {getInsightIcon(insight.type)}
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h4 className="font-semibold">{insight.title}</h4>
                            {getPriorityIcon(insight.priority)}
                          </div>
                          <p className="text-sm text-gray-600 leading-relaxed">
                            {insight.content}
                          </p>
                          {insight.insights && (
                            <div className="mt-2 p-2 bg-blue-50 rounded text-sm">
                              <strong>Key Insight:</strong> {insight.insights.summary || "Pattern detected in your health data"}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="text-right ml-4">
                        <Badge variant={insight.status === 'read' ? 'outline' : 'default'}>
                          {insight.status}
                        </Badge>
                        <div className="text-xs text-gray-500 mt-1">
                          {new Date(insight.generatedAt).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <Brain className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No insights available yet</h3>
                  <p className="text-gray-600">Keep tracking your health data to receive personalized insights</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="trends">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5" />
                  <span>Blood Pressure Trend</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>7-day average</span>
                    <span className="font-semibold">128/84 mmHg</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Trend direction</span>
                    <div className="flex items-center space-x-1">
                      <TrendingDown className="w-4 h-4 text-green-500" />
                      <span className="text-green-600">Improving</span>
                    </div>
                  </div>
                  <div className="p-3 bg-green-50 rounded text-sm">
                    <strong>Good news!</strong> Your blood pressure has decreased by 8% this week. Keep up with your current medication routine.
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="w-5 h-5" />
                  <span>Activity Patterns</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Daily steps average</span>
                    <span className="font-semibold">6,847 steps</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Most active time</span>
                    <span className="font-semibold">3-5 PM</span>
                  </div>
                  <div className="p-3 bg-blue-50 rounded text-sm">
                    <strong>Insight:</strong> You're most consistent with activity in the afternoon. Consider scheduling important health activities during this time.
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="w-5 h-5" />
                  <span>Mood Patterns</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Average mood this week</span>
                    <span className="font-semibold">6.8/10</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Best day</span>
                    <span className="font-semibold">Tuesday (8.5/10)</span>
                  </div>
                  <div className="p-3 bg-purple-50 rounded text-sm">
                    <strong>Pattern detected:</strong> Your mood improves significantly on days when you exercise. Consider maintaining regular physical activity.
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="w-5 h-5" />
                  <span>Goal Progress</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Goals on track</span>
                    <span className="font-semibold text-green-600">3 of 4</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Completion rate</span>
                    <span className="font-semibold">75%</span>
                  </div>
                  <div className="p-3 bg-green-50 rounded text-sm">
                    <strong>Excellent progress!</strong> You're consistently meeting your health goals. Your blood pressure goal is particularly impressive.
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="recommendations">
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <Lightbulb className="w-6 h-6 text-yellow-500 mt-1" />
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Personalized Health Recommendations</h4>
                    <div className="space-y-3">
                      <div className="p-3 border-l-4 border-blue-500 bg-blue-50">
                        <strong>Timing Optimization:</strong> Your blood pressure readings are lowest in the morning. Consider scheduling your BP medication for 7 AM for maximum effectiveness.
                      </div>
                      <div className="p-3 border-l-4 border-green-500 bg-green-50">
                        <strong>Exercise Integration:</strong> Your mood scores are 40% higher on exercise days. Try scheduling 20-minute walks on days when you're feeling low.
                      </div>
                      <div className="p-3 border-l-4 border-purple-500 bg-purple-50">
                        <strong>Medication Adherence:</strong> You miss medications most often on weekends. Set weekend-specific reminders at 9 AM and 6 PM.
                      </div>
                      <div className="p-3 border-l-4 border-orange-500 bg-orange-50">
                        <strong>Stress Management:</strong> Your stress levels peak around 2 PM on weekdays. Consider scheduling brief mindfulness sessions during lunch breaks.
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Health Report</CardTitle>
                <div className="text-sm text-gray-600">September 1-7, 2025</div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold mb-2">Key Achievements</h4>
                    <ul className="space-y-1 text-sm">
                      <li className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>Maintained 95% medication adherence</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>Blood pressure improved by 8%</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>Exercised 4 out of 7 days</span>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Areas for Improvement</h4>
                    <ul className="space-y-1 text-sm">
                      <li className="flex items-center space-x-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-500" />
                        <span>Sleep quality averaged 6.2/10 (target: 7+)</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-500" />
                        <span>Stress levels peaked mid-week</span>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Next Week's Focus</h4>
                    <ul className="space-y-1 text-sm text-blue-600">
                      <li>• Maintain current medication schedule</li>
                      <li>• Add 15-minute evening wind-down routine for better sleep</li>
                      <li>• Practice stress management techniques during lunch breaks</li>
                      <li>• Continue current exercise routine</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}