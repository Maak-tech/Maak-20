import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Plus, AlertCircle } from 'lucide-react';

interface SymptomResponse {
  symptom: {
    id: string;
    label: string;
    severity: number;
    notes?: string;
    onset: string;
  };
  recommendations: string[];
}

export default function ManualSymptomEntry() {
  const [label, setLabel] = useState('');
  const [severity, setSeverity] = useState([5]);
  const [notes, setNotes] = useState('');
  const [onset, setOnset] = useState(new Date().toISOString().split('T')[0]);
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [lastRecommendations, setLastRecommendations] = useState<string[]>([]);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addSymptomMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/me/symptoms', 'POST', data),
    onSuccess: (response: SymptomResponse) => {
      toast({
        title: "Symptom logged successfully",
        description: `${response.symptom.label} has been recorded`,
      });

      // Show recommendations
      if (response.recommendations && response.recommendations.length > 0) {
        setLastRecommendations(response.recommendations);
        setShowRecommendations(true);
      }

      // Reset form
      setLabel('');
      setSeverity([5]);
      setNotes('');
      setOnset(new Date().toISOString().split('T')[0]);

      // Refresh symptoms data
      queryClient.invalidateQueries({ queryKey: ['/api/me/symptoms'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error logging symptom",
        description: error.message || "Failed to log symptom. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!label.trim()) {
      toast({
        title: "Missing information",
        description: "Please enter a symptom description",
        variant: "destructive"
      });
      return;
    }

    addSymptomMutation.mutate({
      label: label.trim(),
      severity: severity[0],
      notes: notes.trim() || undefined,
      onset: onset
    });
  };

  const getSeverityDescription = (value: number) => {
    if (value <= 2) return 'Mild';
    if (value <= 4) return 'Mild to Moderate';
    if (value <= 6) return 'Moderate';
    if (value <= 8) return 'Severe';
    return 'Very Severe';
  };

  const getSeverityColor = (value: number) => {
    if (value <= 3) return 'text-green-600';
    if (value <= 6) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Plus className="w-5 h-5" />
          <span>Log a Symptom</span>
        </CardTitle>
        <CardDescription>
          Manually record a health symptom for tracking and personalized recommendations
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="symptom-label">Symptom Description *</Label>
            <Input
              id="symptom-label"
              type="text"
              placeholder="e.g., headache, nausea, chest pain, back pain"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              data-testid="input-symptom-label"
            />
            <p className="text-sm text-muted-foreground">
              Be specific about the condition (e.g., "headache" not "head pain")
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="severity-slider">Severity Level</Label>
              <div className={`text-lg font-medium ${getSeverityColor(severity[0])}`}>
                {severity[0]}/10 - {getSeverityDescription(severity[0])}
              </div>
            </div>
            <div className="px-2">
              <Slider
                id="severity-slider"
                value={severity}
                onValueChange={setSeverity}
                max={10}
                min={0}
                step={1}
                className="w-full"
                data-testid="slider-severity"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>No pain</span>
                <span>Unbearable</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="symptom-onset">When did this start?</Label>
            <Input
              id="symptom-onset"
              type="date"
              value={onset}
              onChange={(e) => setOnset(e.target.value)}
              data-testid="input-symptom-onset"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="symptom-notes">Additional Notes (Optional)</Label>
            <Textarea
              id="symptom-notes"
              placeholder="Any additional details about triggers, context, or patterns..."
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              data-testid="textarea-symptom-notes"
            />
          </div>

          <Button 
            type="submit" 
            disabled={addSymptomMutation.isPending}
            className="w-full"
            data-testid="button-submit-symptom"
          >
            {addSymptomMutation.isPending ? 'Logging Symptom...' : 'Log Symptom'}
          </Button>
        </form>

        {showRecommendations && lastRecommendations.length > 0 && (
          <Card className="mt-6 border-blue-200 bg-blue-50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-blue-600" />
                <span>Helpful Resources</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {lastRecommendations.map((recommendation, index) => (
                  <li key={index} className="flex items-start space-x-2 text-sm">
                    <span className="text-blue-600 mt-1">•</span>
                    <span>{recommendation}</span>
                  </li>
                ))}
              </ul>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowRecommendations(false)}
                className="mt-4"
              >
                Dismiss
              </Button>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  );
}