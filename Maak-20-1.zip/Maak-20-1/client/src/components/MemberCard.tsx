import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface MemberCardProps {
  id: string;
  name: string;
  role: string;
  age: number;
  lastVitalTime: string;
  riskLevel: "normal" | "warning" | "critical";
  vitals: {
    heartRate?: number;
    spo2?: number;
    bloodPressure?: string;
  };
  onViewDetails: (id: string) => void;
  className?: string;
}

export default function MemberCard({
  id,
  name,
  role,
  age,
  lastVitalTime,
  riskLevel,
  vitals,
  onViewDetails,
  className = ""
}: MemberCardProps) {
  const riskConfig = {
    normal: {
      badge: "bg-green-100 text-green-700",
      text: "Normal",
      avatar: "from-blue-400 to-blue-600"
    },
    warning: {
      badge: "bg-yellow-100 text-yellow-700", 
      text: "Alert",
      avatar: "from-yellow-400 to-yellow-600"
    },
    critical: {
      badge: "bg-red-100 text-red-700",
      text: "Critical", 
      avatar: "from-red-400 to-red-600"
    }
  };

  const config = riskConfig[riskLevel];
  const initials = name.split(' ').map(n => n[0]).join('').toUpperCase();

  return (
    <Card className={cn("hover:shadow-lg transition-shadow", className)} data-testid={`card-member-${id}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`w-12 h-12 bg-gradient-to-br ${config.avatar} rounded-full flex items-center justify-center text-white font-semibold text-lg`}>
              {initials}
            </div>
            <div>
              <h3 className="font-semibold text-card-foreground" data-testid="text-member-name">
                {name}
              </h3>
              <p className="text-sm text-muted-foreground">
                {role}, {age} years old
              </p>
            </div>
          </div>
          <Badge variant="secondary" className={config.badge} data-testid={`badge-risk-${riskLevel}`}>
            {config.text}
          </Badge>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Last Vitals</span>
            <span className="text-sm font-medium" data-testid="text-last-vital-time">
              {lastVitalTime}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {vitals.heartRate && (
              <div className="text-center">
                <div className="text-lg font-bold text-card-foreground" data-testid="text-heart-rate">
                  {vitals.heartRate}
                </div>
                <div className="text-xs text-muted-foreground">BPM</div>
              </div>
            )}
            {vitals.spo2 && (
              <div className="text-center">
                <div className="text-lg font-bold text-card-foreground" data-testid="text-spo2">
                  {vitals.spo2}%
                </div>
                <div className="text-xs text-muted-foreground">SpO₂</div>
              </div>
            )}
          </div>

          {/* Mini trend chart placeholder */}
          <div className="h-16 bg-muted/50 rounded flex items-end justify-center space-x-1 p-2">
            <div className="w-2 bg-accent h-4 rounded-t"></div>
            <div className="w-2 bg-accent h-6 rounded-t"></div>
            <div className="w-2 bg-accent h-3 rounded-t"></div>
            <div className="w-2 bg-accent h-8 rounded-t"></div>
            <div className="w-2 bg-accent h-5 rounded-t"></div>
            <div className={`w-2 h-10 rounded-t ${riskLevel === 'critical' ? 'bg-red-500' : riskLevel === 'warning' ? 'bg-yellow-500' : 'bg-accent'}`}></div>
            <div className={`w-2 h-12 rounded-t ${riskLevel === 'critical' ? 'bg-red-600' : riskLevel === 'warning' ? 'bg-yellow-600' : 'bg-accent'}`}></div>
          </div>

          <Button 
            variant={riskLevel === 'critical' ? 'destructive' : 'secondary'} 
            className="w-full text-sm"
            onClick={() => onViewDetails(id)}
            data-testid="button-view-details"
          >
            {riskLevel === 'critical' ? 'View Critical Details' : 'View Details'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
