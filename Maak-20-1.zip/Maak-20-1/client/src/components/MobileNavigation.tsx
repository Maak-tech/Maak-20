import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { 
  MessageCircle, 
  Activity, 
  Target, 
  Brain, 
  Shield, 
  Settings,
  Menu,
  X,
  Home,
  Bell
} from "lucide-react";

const navigationItems = [
  { name: "Dashboard", href: "/", icon: Home, color: "text-blue-600" },
  { name: "Chat", href: "/chat", icon: MessageCircle, color: "text-green-600" },
  { name: "Goals", href: "/goals", icon: Target, color: "text-purple-600" },
  { name: "Mood", href: "/mood", icon: Brain, color: "text-pink-600" },
  { name: "Emergency", href: "/emergency", icon: Shield, color: "text-red-600" },
];

interface MobileNavigationProps {
  emergencyAlerts?: number;
  newInsights?: number;
}

export default function MobileNavigation({ emergencyAlerts = 0, newInsights = 0 }: MobileNavigationProps) {
  const [location] = useLocation();
  const [isMobile, setIsMobile] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setShowMobileMenu(false);
  }, [location]);

  if (!isMobile) {
    // Desktop navigation (existing sidebar)
    return (
      <nav className="hidden md:flex md:flex-col md:w-64 md:bg-white md:border-r md:border-gray-200">
        <div className="flex-1 p-4 space-y-2">
          {navigationItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            const Icon = item.icon;
            
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive 
                    ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-blue-600' : item.color}`} />
                <span className="font-medium">{item.name}</span>
                {item.name === "Emergency" && emergencyAlerts > 0 && (
                  <Badge variant="destructive" className="ml-auto text-xs">
                    {emergencyAlerts}
                  </Badge>
                )}
              </Link>
            );
          })}
        </div>
      </nav>
    );
  }

  return (
    <>
      {/* Mobile Header */}
      <header className="md:hidden fixed top-0 left-0 right-0 z-40 bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-blue-600" />
            </div>
            <h1 className="text-lg font-semibold text-gray-900">Zeina</h1>
            {newInsights > 0 && (
              <Badge variant="secondary" className="text-xs">
                {newInsights} new
              </Badge>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            {emergencyAlerts > 0 && (
              <div className="relative">
                <Bell className="w-5 h-5 text-red-500" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></div>
              </div>
            )}
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="p-2 rounded-lg hover:bg-gray-100"
            >
              {showMobileMenu ? (
                <X className="w-5 h-5 text-gray-600" />
              ) : (
                <Menu className="w-5 h-5 text-gray-600" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {showMobileMenu && (
        <div
          className="md:hidden fixed inset-0 z-30 bg-black bg-opacity-50"
          onClick={() => setShowMobileMenu(false)}
        />
      )}

      {/* Mobile Menu */}
      <nav
        className={`md:hidden fixed top-0 right-0 h-full w-80 max-w-[85vw] bg-white z-40 transform transition-transform duration-300 ease-in-out ${
          showMobileMenu ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="p-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-lg font-semibold">Navigation</h2>
            <button
              onClick={() => setShowMobileMenu(false)}
              className="p-2 rounded-lg hover:bg-gray-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-2">
            {navigationItems.map((item) => {
              const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
              const Icon = item.icon;
              
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                    isActive 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className={`w-6 h-6 ${isActive ? 'text-blue-600' : item.color}`} />
                  <span className="font-medium text-base">{item.name}</span>
                  {item.name === "Emergency" && emergencyAlerts > 0 && (
                    <Badge variant="destructive" className="ml-auto">
                      {emergencyAlerts}
                    </Badge>
                  )}
                </Link>
              );
            })}
          </div>

          <div className="mt-8 pt-8 border-t border-gray-200">
            <Link
              href="/settings"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                location === "/settings"
                  ? 'bg-gray-50 text-gray-900' 
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Settings className="w-6 h-6 text-gray-500" />
              <span className="font-medium text-base">Settings</span>
            </Link>
          </div>

          <div className="mt-8 p-4 bg-blue-50 rounded-lg">
            <div className="text-sm text-blue-700 font-medium mb-1">
              Zeina AI Health Assistant
            </div>
            <div className="text-xs text-blue-600">
              Your intelligent health companion
            </div>
          </div>
        </div>
      </nav>

      {/* Bottom Navigation (Alternative mobile nav) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-gray-200 px-2 py-1">
        <div className="flex items-center justify-around">
          {navigationItems.slice(0, 5).map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            const Icon = item.icon;
            
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex flex-col items-center py-2 px-3 rounded-lg transition-colors ${
                  isActive ? 'text-blue-600' : 'text-gray-500'
                }`}
              >
                <div className="relative">
                  <Icon className="w-5 h-5" />
                  {item.name === "Emergency" && emergencyAlerts > 0 && (
                    <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></div>
                  )}
                </div>
                <span className="text-xs font-medium mt-1">{item.name}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Spacer for mobile content */}
      <div className="md:hidden h-16" /> {/* Top spacer */}
      <div className="md:hidden h-20" /> {/* Bottom spacer */}
    </>
  );
}