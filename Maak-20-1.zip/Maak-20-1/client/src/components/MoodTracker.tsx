import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { Heart, Brain, Moon, Zap, TrendingUp, Calendar } from "lucide-react";

const EMOTIONS = [
  { name: 'Happy', emoji: '😊', color: 'bg-yellow-100 text-yellow-800' },
  { name: 'Calm', emoji: '😌', color: 'bg-blue-100 text-blue-800' },
  { name: 'Anxious', emoji: '😰', color: 'bg-orange-100 text-orange-800' },
  { name: 'Sad', emoji: '😢', color: 'bg-purple-100 text-purple-800' },
  { name: 'Angry', emoji: '😠', color: 'bg-red-100 text-red-800' },
  { name: 'Excited', emoji: '🤩', color: 'bg-green-100 text-green-800' },
  { name: 'Stressed', emoji: '😤', color: 'bg-gray-100 text-gray-800' },
  { name: 'Content', emoji: '😊', color: 'bg-emerald-100 text-emerald-800' }
];

const MOOD_TRIGGERS = [
  'Work stress', 'Family', 'Health concerns', 'Sleep', 'Weather', 
  'Exercise', 'Social situations', 'Finances', 'Medication changes', 'Diet'
];

const COPING_STRATEGIES = [
  'Deep breathing', 'Exercise', 'Meditation', 'Talking to someone', 'Music',
  'Reading', 'Walking', 'Journaling', 'Hobbies', 'Rest'
];

export default function MoodTracker() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newMoodEntry, setNewMoodEntry] = useState({
    moodScore: [5],
    emotionalState: '',
    stressLevel: [3],
    sleepQuality: [5],
    energyLevel: [5],
    notes: '',
    triggers: [] as string[],
    copingStrategies: [] as string[]
  });

  // Fetch mood entries
  const { data: moodEntries, isLoading } = useQuery({
    queryKey: ["/api/me/mood-entries"],
  });

  // Create mood entry
  const createMoodEntry = useMutation({
    mutationFn: async (moodData: any) => {
      const response = await fetch("/api/me/mood-entries", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer mock"
        },
        body: JSON.stringify({
          ...moodData,
          moodScore: moodData.moodScore[0],
          stressLevel: moodData.stressLevel[0],
          sleepQuality: moodData.sleepQuality[0],
          energyLevel: moodData.energyLevel[0]
        })
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/mood-entries"] });
      setNewMoodEntry({
        moodScore: [5],
        emotionalState: '',
        stressLevel: [3],
        sleepQuality: [5],
        energyLevel: [5],
        notes: '',
        triggers: [],
        copingStrategies: []
      });
      toast({ title: "Mood entry saved!" });
    }
  });

  const getMoodColor = (score: number) => {
    if (score >= 8) return 'text-green-600';
    if (score >= 6) return 'text-yellow-600';
    if (score >= 4) return 'text-orange-600';
    return 'text-red-600';
  };

  const getMoodEmoji = (score: number) => {
    if (score >= 8) return '😊';
    if (score >= 6) return '🙂';
    if (score >= 4) return '😐';
    return '😞';
  };

  const toggleTrigger = (trigger: string) => {
    setNewMoodEntry(prev => ({
      ...prev,
      triggers: prev.triggers.includes(trigger) 
        ? prev.triggers.filter(t => t !== trigger)
        : [...prev.triggers, trigger]
    }));
  };

  const toggleCopingStrategy = (strategy: string) => {
    setNewMoodEntry(prev => ({
      ...prev,
      copingStrategies: prev.copingStrategies.includes(strategy)
        ? prev.copingStrategies.filter(s => s !== strategy)
        : [...prev.copingStrategies, strategy]
    }));
  };

  const calculateAverageMood = (entries: any[]) => {
    if (!entries.length) return 5;
    return entries.reduce((sum: number, entry: any) => sum + entry.moodScore, 0) / entries.length;
  };

  if (isLoading) {
    return <div className="animate-pulse">Loading mood tracker...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-2">
        <Brain className="w-6 h-6 text-purple-600" />
        <h2 className="text-2xl font-bold">Mood & Mental Health</h2>
      </div>

      {/* Quick Mood Entry */}
      <Card>
        <CardHeader>
          <CardTitle>How are you feeling today?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Mood Score */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="font-medium">Overall Mood</label>
              <span className={`text-2xl ${getMoodColor(newMoodEntry.moodScore[0])}`}>
                {getMoodEmoji(newMoodEntry.moodScore[0])} {newMoodEntry.moodScore[0]}/10
              </span>
            </div>
            <Slider
              value={newMoodEntry.moodScore}
              onValueChange={(value) => setNewMoodEntry(prev => ({ ...prev, moodScore: value }))}
              min={1}
              max={10}
              step={1}
              className="mb-4"
            />
          </div>

          {/* Emotional State */}
          <div>
            <label className="font-medium block mb-3">Current Emotional State</label>
            <div className="grid grid-cols-4 gap-2">
              {EMOTIONS.map((emotion) => (
                <Button
                  key={emotion.name}
                  variant={newMoodEntry.emotionalState === emotion.name ? "default" : "outline"}
                  size="sm"
                  onClick={() => setNewMoodEntry(prev => ({ ...prev, emotionalState: emotion.name }))}
                  className="flex flex-col items-center p-2 h-auto"
                >
                  <span className="text-lg mb-1">{emotion.emoji}</span>
                  <span className="text-xs">{emotion.name}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Other Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <Heart className="w-4 h-4" />
                <label className="font-medium">Stress Level</label>
                <span className="text-sm text-gray-600">{newMoodEntry.stressLevel[0]}/10</span>
              </div>
              <Slider
                value={newMoodEntry.stressLevel}
                onValueChange={(value) => setNewMoodEntry(prev => ({ ...prev, stressLevel: value }))}
                min={1}
                max={10}
                step={1}
              />
            </div>

            <div>
              <div className="flex items-center space-x-2 mb-2">
                <Moon className="w-4 h-4" />
                <label className="font-medium">Sleep Quality</label>
                <span className="text-sm text-gray-600">{newMoodEntry.sleepQuality[0]}/10</span>
              </div>
              <Slider
                value={newMoodEntry.sleepQuality}
                onValueChange={(value) => setNewMoodEntry(prev => ({ ...prev, sleepQuality: value }))}
                min={1}
                max={10}
                step={1}
              />
            </div>

            <div>
              <div className="flex items-center space-x-2 mb-2">
                <Zap className="w-4 h-4" />
                <label className="font-medium">Energy Level</label>
                <span className="text-sm text-gray-600">{newMoodEntry.energyLevel[0]}/10</span>
              </div>
              <Slider
                value={newMoodEntry.energyLevel}
                onValueChange={(value) => setNewMoodEntry(prev => ({ ...prev, energyLevel: value }))}
                min={1}
                max={10}
                step={1}
              />
            </div>
          </div>

          {/* Triggers */}
          <div>
            <label className="font-medium block mb-3">What's affecting your mood? (Select all that apply)</label>
            <div className="flex flex-wrap gap-2">
              {MOOD_TRIGGERS.map((trigger) => (
                <Badge
                  key={trigger}
                  variant={newMoodEntry.triggers.includes(trigger) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => toggleTrigger(trigger)}
                >
                  {trigger}
                </Badge>
              ))}
            </div>
          </div>

          {/* Coping Strategies */}
          <div>
            <label className="font-medium block mb-3">What's helping you cope?</label>
            <div className="flex flex-wrap gap-2">
              {COPING_STRATEGIES.map((strategy) => (
                <Badge
                  key={strategy}
                  variant={newMoodEntry.copingStrategies.includes(strategy) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => toggleCopingStrategy(strategy)}
                >
                  {strategy}
                </Badge>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="font-medium block mb-2">Additional Notes</label>
            <Textarea
              value={newMoodEntry.notes}
              onChange={(e) => setNewMoodEntry(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="How are you really feeling? Any specific thoughts or events affecting your mood today?"
              rows={3}
            />
          </div>

          <Button 
            onClick={() => createMoodEntry.mutate(newMoodEntry)}
            className="w-full"
            disabled={createMoodEntry.isPending}
          >
            {createMoodEntry.isPending ? 'Saving...' : 'Save Mood Entry'}
          </Button>
        </CardContent>
      </Card>

      {/* Mood History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5" />
            <span>Recent Mood History</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {moodEntries && moodEntries.length > 0 ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {calculateAverageMood(moodEntries.slice(0, 7)).toFixed(1)}
                  </div>
                  <div className="text-sm text-gray-600">7-day average</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {moodEntries.filter((entry: any) => entry.moodScore >= 7).length}
                  </div>
                  <div className="text-sm text-gray-600">Good days</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {moodEntries.filter((entry: any) => entry.moodScore <= 4).length}
                  </div>
                  <div className="text-sm text-gray-600">Difficult days</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {Math.round(moodEntries.reduce((sum: number, entry: any) => sum + entry.stressLevel, 0) / moodEntries.length * 10) / 10}
                  </div>
                  <div className="text-sm text-gray-600">Avg stress</div>
                </div>
              </div>

              <div className="space-y-3">
                {moodEntries.slice(0, 5).map((entry: any) => (
                  <div key={entry.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{getMoodEmoji(entry.moodScore)}</span>
                      <div>
                        <div className="font-medium">
                          {entry.emotionalState} - {entry.moodScore}/10
                        </div>
                        <div className="text-sm text-gray-600">
                          Stress: {entry.stressLevel}/10 | Energy: {entry.energyLevel}/10 | Sleep: {entry.sleepQuality}/10
                        </div>
                        {entry.notes && (
                          <div className="text-sm text-gray-700 mt-1 italic">"{entry.notes}"</div>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-600 flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(entry.recordedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Brain className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No mood entries yet</h3>
              <p className="text-gray-600">Start tracking your daily mood and mental wellbeing</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}