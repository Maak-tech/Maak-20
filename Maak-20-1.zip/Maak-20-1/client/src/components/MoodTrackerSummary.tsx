import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';

export default function MoodTrackerSummary() {
  const { data: moodEntries, isLoading } = useQuery({
    queryKey: ["/api/me/mood-entries"],
  });

  const getMoodEmoji = (score: number) => {
    if (score >= 8) return '😊';
    if (score >= 6) return '🙂';
    if (score >= 4) return '😐';
    if (score >= 2) return '🙁';
    return '😞';
  };

  const calculateAverageMood = (entries: any[]) => {
    if (!entries || entries.length === 0) return 0;
    const sum = entries.reduce((acc, entry) => acc + entry.moodScore, 0);
    return sum / entries.length;
  };

  if (isLoading) {
    return <div className="animate-pulse">Loading mood data...</div>;
  }

  if (!moodEntries || !Array.isArray(moodEntries) || moodEntries.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground text-sm mb-3">No mood entries yet</p>
        <Link href="/mood">
          <Button variant="outline" size="sm">Track Your Mood</Button>
        </Link>
      </div>
    );
  }

  const entriesArray = Array.isArray(moodEntries) ? moodEntries : [];
  const recentEntries = entriesArray.slice(0, 3);
  const avgMood = calculateAverageMood(entriesArray.slice(0, 7));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 text-center">
        <div>
          <div className="text-2xl font-bold text-blue-600">
            {avgMood.toFixed(1)}
          </div>
          <div className="text-sm text-muted-foreground">7-day average</div>
        </div>
        <div>
          <div className="text-xl">
            {getMoodEmoji(recentEntries[0]?.moodScore || 0)}
          </div>
          <div className="text-sm text-muted-foreground">Today</div>
        </div>
      </div>
      
      <div className="space-y-2">
        {recentEntries.map((entry: any) => (
          <div key={entry.id} className="flex items-center justify-between p-2 bg-muted rounded">
            <div className="flex items-center space-x-2">
              <span className="text-lg">{getMoodEmoji(entry.moodScore)}</span>
              <span className="font-medium">{entry.emotionalState}</span>
            </div>
            <Badge variant="outline">{entry.moodScore}/10</Badge>
          </div>
        ))}
      </div>
      
      <Link href="/mood">
        <Button variant="outline" size="sm" className="w-full">
          View Full Mood History
        </Button>
      </Link>
    </div>
  );
}