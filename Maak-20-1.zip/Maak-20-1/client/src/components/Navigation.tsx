import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useTranslation } from 'react-i18next';
import { LanguageToggle } from './LanguageToggle';
import { ThemeToggle } from './ThemeToggle';
import { 
  Activity, 
  MessageCircle, 
  Pill, 
  BookOpen, 
  Settings, 
  Users,
  AlertTriangle,
  UserCheck
} from "lucide-react";

interface NavigationProps {
  userRole?: "user" | "admin";
}

export default function Navigation({ userRole = "user" }: NavigationProps) {
  const [location] = useLocation();
  const { t } = useTranslation();

  const userNavItems = [
    { path: "/dashboard", label: t('nav.dashboard'), icon: Activity },
    { path: "/chat", label: t('nav.chat'), icon: MessageCircle },
    { path: "/medications", label: t('nav.medications'), icon: Pill },
    { path: "/resources", label: t('nav.resources'), icon: BookOpen },
    { path: "/settings", label: t('nav.settings'), icon: Settings },
  ];

  const adminNavItems = [
    { path: "/admin/members", label: t('nav.members'), icon: Users },
    { path: "/admin/alerts", label: t('nav.alerts'), icon: AlertTriangle },
    { path: "/admin/settings", label: t('nav.settings'), icon: Settings },
  ];

  const navItems = userRole === "admin" ? adminNavItems : userNavItems;

  return (
    <nav className="bg-neutral-50 border-b border-secondary-300 shadow-sm">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <img 
                src="attached_assets/73b940b6-077b-4bbe-a8eb-f9393791ff0a_1757022833654.png" 
                alt="Maak Logo" 
                className="w-8 h-8"
                data-testid="img-logo"
              />
              <span className="text-xl font-bold text-primary-600">Maak</span>
            </div>
          </div>
          <div className="flex space-x-1" aria-label="Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link key={item.path} href={item.path}>
                <button
                  className={cn(
                    "flex items-center space-x-2 px-4 py-3 text-sm font-medium rounded-t-2xl transition-colors shadow-md",
                    isActive
                      ? "bg-primary-600 text-white"
                      : "bg-primary-100 text-primary-600 hover:bg-primary-400 hover:text-white"
                  )}
                  data-testid={`nav-${item.path.split('/').pop()}`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              </Link>
            );
          })}
          </div>
          <div className="flex items-center space-x-2">
            <ThemeToggle />
            <LanguageToggle />
          </div>
        </div>
      </div>
    </nav>
  );
}
