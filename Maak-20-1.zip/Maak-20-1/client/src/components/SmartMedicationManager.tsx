import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Pill, 
  AlertCircle,
  Shield,
  Target,
  Brain,
  Activity,
  Heart,
  Timer,
  BarChart3,
  Zap
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface SmartMedicationManagerProps {
  medications: any[];
  medicationLogs: any[];
  onMedicationTaken: (medicationId: string) => void;
}

export default function SmartMedicationManager({ 
  medications, 
  medicationLogs, 
  onMedicationTaken 
}: SmartMedicationManagerProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('today');
  const [interactions, setInteractions] = useState<any[]>([]);
  const [adherenceStats, setAdherenceStats] = useState<any>({});

  // Fetch drug interactions
  const { data: drugInteractions } = useQuery({
    queryKey: ['/api/me/drug-interactions'],
    enabled: medications.length > 1,
  });

  // Calculate comprehensive medication analytics
  useEffect(() => {
    const stats = calculateAdherenceAnalytics(medications, medicationLogs);
    setAdherenceStats(stats);
    
    const detectedInteractions = detectDrugInteractions(medications);
    setInteractions(detectedInteractions);
  }, [medications, medicationLogs]);

  const calculateAdherenceAnalytics = (meds: any[], logs: any[]) => {
    const stats: any = {
      overall: 0,
      weeklyTrend: 0,
      criticalMedications: 0,
      missedDoses: 0,
      perfectDays: 0,
      averageDelay: 0,
      medicationDetails: []
    };

    if (!meds.length) return stats;

    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const recentLogs = logs.filter(log => new Date(log.scheduledAt) >= weekAgo);

    // Calculate per-medication adherence
    stats.medicationDetails = meds.map(med => {
      const medLogs = recentLogs.filter(log => log.medicationId === med.id);
      const scheduledDoses = medLogs.length;
      const takenDoses = medLogs.filter(log => log.status === 'taken').length;
      const adherenceRate = scheduledDoses > 0 ? (takenDoses / scheduledDoses) * 100 : 100;
      
      const delays = medLogs
        .filter(log => log.status === 'taken' && log.delayMinutes)
        .map(log => log.delayMinutes || 0);
      const avgDelay = delays.length > 0 ? delays.reduce((a, b) => a + b, 0) / delays.length : 0;

      return {
        id: med.id,
        name: med.name,
        adherenceRate: Math.round(adherenceRate),
        trend: calculateTrend(medLogs),
        avgDelay: Math.round(avgDelay),
        critical: med.critical,
        riskLevel: adherenceRate < 70 ? 'high' : adherenceRate < 85 ? 'medium' : 'low'
      };
    });

    // Overall statistics
    const totalScheduled = recentLogs.length;
    const totalTaken = recentLogs.filter(log => log.status === 'taken').length;
    stats.overall = totalScheduled > 0 ? Math.round((totalTaken / totalScheduled) * 100) : 100;
    stats.missedDoses = recentLogs.filter(log => log.status === 'missed').length;
    stats.criticalMedications = meds.filter(med => med.critical).length;
    
    // Calculate average delay
    const allDelays = recentLogs
      .filter(log => log.status === 'taken' && log.delayMinutes)
      .map(log => log.delayMinutes || 0);
    stats.averageDelay = allDelays.length > 0 ? Math.round(allDelays.reduce((a, b) => a + b, 0) / allDelays.length) : 0;

    return stats;
  };

  const calculateTrend = (logs: any[]) => {
    if (logs.length < 4) return 'stable';
    
    const recentRate = logs.slice(0, 3).filter(log => log.status === 'taken').length / 3;
    const olderRate = logs.slice(3, 6).filter(log => log.status === 'taken').length / 3;
    
    if (recentRate > olderRate + 0.2) return 'improving';
    if (recentRate < olderRate - 0.2) return 'declining';
    return 'stable';
  };

  const detectDrugInteractions = (meds: any[]) => {
    const interactions = [];
    
    // Simplified drug interaction detection (in real app, use FDA API)
    for (let i = 0; i < meds.length; i++) {
      for (let j = i + 1; j < meds.length; j++) {
        const med1 = meds[i];
        const med2 = meds[j];
        
        // Common interaction patterns
        const interaction = checkInteractionPattern(med1, med2);
        if (interaction) {
          interactions.push({
            id: `${med1.id}-${med2.id}`,
            medication1: med1.name,
            medication2: med2.name,
            severity: interaction.severity,
            type: interaction.type,
            description: interaction.description,
            recommendation: interaction.recommendation
          });
        }
      }
    }
    
    return interactions;
  };

  const checkInteractionPattern = (med1: any, med2: any) => {
    // Simplified interaction rules (in production, use comprehensive drug database)
    const name1 = med1.name.toLowerCase();
    const name2 = med2.name.toLowerCase();
    
    // Blood pressure medications with other BP meds
    if (isBPMedication(name1) && isBPMedication(name2)) {
      return {
        severity: 'moderate',
        type: 'additive',
        description: 'Both medications lower blood pressure. May cause excessive reduction.',
        recommendation: 'Monitor blood pressure closely and adjust dosing as needed.'
      };
    }
    
    // Blood thinners with NSAIDs
    if ((isBloodThinner(name1) && isNSAID(name2)) || (isBloodThinner(name2) && isNSAID(name1))) {
      return {
        severity: 'major',
        type: 'bleeding_risk',
        description: 'Increased risk of bleeding when used together.',
        recommendation: 'Consider alternative pain management. If necessary, monitor for bleeding signs.'
      };
    }
    
    // Diabetes medications
    if (isDiabetesMed(name1) && isDiabetesMed(name2)) {
      return {
        severity: 'moderate',
        type: 'hypoglycemia',
        description: 'Combined use may increase risk of low blood sugar.',
        recommendation: 'Monitor blood glucose more frequently.'
      };
    }
    
    return null;
  };

  const isBPMedication = (name: string) => {
    const bpMeds = ['lisinopril', 'atenolol', 'amlodipine', 'losartan', 'metoprolol', 'hydrochlorothiazide'];
    return bpMeds.some(med => name.includes(med));
  };

  const isBloodThinner = (name: string) => {
    const bloodThinners = ['warfarin', 'aspirin', 'clopidogrel', 'rivaroxaban', 'apixaban'];
    return bloodThinners.some(med => name.includes(med));
  };

  const isNSAID = (name: string) => {
    const nsaids = ['ibuprofen', 'naproxen', 'diclofenac', 'celecoxib'];
    return nsaids.some(med => name.includes(med));
  };

  const isDiabetesMed = (name: string) => {
    const diabetesMeds = ['metformin', 'insulin', 'glipizide', 'pioglitazone', 'sitagliptin'];
    return diabetesMeds.some(med => name.includes(med));
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'major': return 'border-red-500 bg-red-50 dark:bg-red-900/20';
      case 'moderate': return 'border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20';
      case 'minor': return 'border-green-500 bg-green-50 dark:bg-green-900/20';
      default: return 'border-gray-500 bg-gray-50 dark:bg-gray-900/20';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'major': return <AlertTriangle className="w-5 h-5 text-red-600" />;
      case 'moderate': return <AlertCircle className="w-5 h-5 text-yellow-600" />;
      case 'minor': return <Shield className="w-5 h-5 text-green-600" />;
      default: return <AlertCircle className="w-5 h-5 text-gray-600" />;
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving': return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'declining': return <TrendingDown className="w-4 h-4 text-red-600" />;
      default: return <Activity className="w-4 h-4 text-blue-600" />;
    }
  };

  const getAdherenceColor = (rate: number) => {
    if (rate >= 90) return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-300';
    if (rate >= 75) return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-300';
    return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-300';
  };

  const todayMedications = medications.filter(med => {
    // Filter medications due today based on schedule
    return true; // Simplified - in real app, check actual schedule
  });

  return (
    <div className="space-y-6">
      {/* Medication Overview Dashboard */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Pill className="w-5 h-5" />
            <span>Smart Medication Management</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <div className="text-2xl font-bold text-green-600">{adherenceStats.overall || 0}%</div>
              <div className="text-sm text-muted-foreground">Overall Adherence</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <div className="text-2xl font-bold text-blue-600">{adherenceStats.averageDelay || 0}m</div>
              <div className="text-sm text-muted-foreground">Avg Delay</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <div className="text-2xl font-bold text-purple-600">{adherenceStats.criticalMedications || 0}</div>
              <div className="text-sm text-muted-foreground">Critical Meds</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <div className="text-2xl font-bold text-red-600">{adherenceStats.missedDoses || 0}</div>
              <div className="text-sm text-muted-foreground">Missed This Week</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Drug Interaction Warnings */}
      {interactions.length > 0 && (
        <Card className="border-yellow-500">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-yellow-700">
              <AlertTriangle className="w-5 h-5" />
              <span>Drug Interaction Alerts</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {interactions.map((interaction, index) => (
                <Alert key={index} className={getSeverityColor(interaction.severity)}>
                  <div className="flex items-start space-x-3">
                    {getSeverityIcon(interaction.severity)}
                    <div className="flex-1">
                      <div className="font-medium">
                        {interaction.medication1} + {interaction.medication2}
                      </div>
                      <AlertDescription className="mt-1">
                        <div className="mb-2">{interaction.description}</div>
                        <div className="text-sm font-medium">
                          <strong>Recommendation:</strong> {interaction.recommendation}
                        </div>
                      </AlertDescription>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {interaction.severity.toUpperCase()}
                    </Badge>
                  </div>
                </Alert>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Navigation Tabs */}
      <div className="flex space-x-1 bg-muted p-1 rounded-lg">
        {[
          { id: 'today', label: 'Today', icon: <Calendar className="w-4 h-4" /> },
          { id: 'adherence', label: 'Adherence', icon: <BarChart3 className="w-4 h-4" /> },
          { id: 'insights', label: 'AI Insights', icon: <Brain className="w-4 h-4" /> }
        ].map(tab => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab(tab.id)}
            className="flex items-center space-x-2 flex-1"
          >
            {tab.icon}
            <span>{tab.label}</span>
          </Button>
        ))}
      </div>

      {/* Content based on active tab */}
      {activeTab === 'today' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Timer className="w-5 h-5" />
              <span>Today's Medications</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {todayMedications.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Pill className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No medications scheduled for today</p>
                </div>
              ) : (
                todayMedications.map((medication, index) => {
                  const todayLog = medicationLogs.find(log => 
                    log.medicationId === medication.id && 
                    new Date(log.scheduledAt).toDateString() === new Date().toDateString()
                  );
                  const isTaken = todayLog?.status === 'taken';
                  const isDelayed = todayLog?.delayMinutes > 30;
                  
                  return (
                    <div key={medication.id} className={`p-4 rounded-lg border transition-all ${
                      isTaken ? 'bg-green-50 border-green-200 dark:bg-green-900/20' :
                      isDelayed ? 'bg-red-50 border-red-200 dark:bg-red-900/20' :
                      'bg-gray-50 border-gray-200 dark:bg-gray-900/20'
                    }`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                            isTaken ? 'bg-green-100 text-green-600' :
                            medication.critical ? 'bg-red-100 text-red-600' :
                            'bg-blue-100 text-blue-600'
                          }`}>
                            {isTaken ? (
                              <CheckCircle2 className="w-6 h-6" />
                            ) : medication.critical ? (
                              <Heart className="w-6 h-6" />
                            ) : (
                              <Pill className="w-6 h-6" />
                            )}
                          </div>
                          <div>
                            <div className="font-medium flex items-center space-x-2">
                              <span>{medication.name} {medication.dose}</span>
                              {medication.critical && (
                                <Badge variant="destructive" className="text-xs">Critical</Badge>
                              )}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {medication.instructions || 'Take as prescribed'}
                            </div>
                            {todayLog?.delayMinutes > 0 && (
                              <div className="text-xs text-red-600 mt-1">
                                Taken {todayLog.delayMinutes} minutes late
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          {isTaken ? (
                            <Badge className="bg-green-100 text-green-700">
                              ✓ Taken
                            </Badge>
                          ) : (
                            <Button
                              size="sm"
                              onClick={() => onMedicationTaken(medication.id)}
                              className="bg-gradient-to-r from-blue-500 to-purple-600 text-white"
                            >
                              Mark Taken
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'adherence' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5" />
              <span>Adherence Analytics</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {adherenceStats.medicationDetails?.map((med: any, index: number) => (
                <div key={med.id} className="p-4 rounded-lg border">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <h4 className="font-medium">{med.name}</h4>
                      {getTrendIcon(med.trend)}
                      {med.critical && (
                        <Badge variant="destructive" className="text-xs">Critical</Badge>
                      )}
                    </div>
                    <Badge className={getAdherenceColor(med.adherenceRate)}>
                      {med.adherenceRate}%
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Adherence Rate</span>
                      <span>{med.adherenceRate}%</span>
                    </div>
                    <Progress value={med.adherenceRate} className="h-2" />
                    
                    <div className="grid grid-cols-3 gap-4 text-sm mt-3">
                      <div>
                        <span className="text-muted-foreground">Trend:</span>
                        <div className="font-medium capitalize">{med.trend}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Avg Delay:</span>
                        <div className="font-medium">{med.avgDelay}m</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Risk Level:</span>
                        <div className={`font-medium capitalize ${
                          med.riskLevel === 'high' ? 'text-red-600' :
                          med.riskLevel === 'medium' ? 'text-yellow-600' :
                          'text-green-600'
                        }`}>
                          {med.riskLevel}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'insights' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="w-5 h-5" />
              <span>AI-Powered Insights</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border">
                <div className="flex items-start space-x-3">
                  <Zap className="w-5 h-5 text-purple-600 mt-1" />
                  <div>
                    <h4 className="font-medium text-purple-700">Smart Adherence Prediction</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Based on your patterns, you're at {adherenceStats.overall >= 85 ? 'low' : 'moderate'} risk of missing medications next week.
                      {adherenceStats.overall < 85 && ' Consider setting additional reminders during afternoon hours.'}
                    </p>
                  </div>
                </div>
              </div>
              
              {adherenceStats.criticalMedications > 0 && (
                <div className="p-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200">
                  <div className="flex items-start space-x-3">
                    <Heart className="w-5 h-5 text-red-600 mt-1" />
                    <div>
                      <h4 className="font-medium text-red-700">Critical Medication Alert</h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        You have {adherenceStats.criticalMedications} critical medication(s). 
                        Missing these could significantly impact your health outcomes.
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200">
                <div className="flex items-start space-x-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600 mt-1" />
                  <div>
                    <h4 className="font-medium text-green-700">Optimization Suggestion</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your adherence is {adherenceStats.overall >= 90 ? 'excellent' : 'good'}! 
                      {adherenceStats.averageDelay > 30 && ' Try taking medications 30 minutes earlier to reduce delays.'}
                      {adherenceStats.averageDelay <= 30 && ' Your timing consistency is helping optimize therapeutic effects.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}