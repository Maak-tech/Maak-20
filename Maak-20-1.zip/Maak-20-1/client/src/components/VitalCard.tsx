import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Filler,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Filler);

interface VitalCardProps {
  title: string;
  value: string | number;
  unit?: string;
  icon: React.ReactNode;
  status: "normal" | "warning" | "critical";
  lastUpdated: string;
  chartData?: number[];
  className?: string;
}

export default function VitalCard({
  title,
  value,
  unit,
  icon,
  status,
  lastUpdated,
  chartData = [],
  className = ""
}: VitalCardProps) {
  const statusConfig = {
    normal: { 
      badge: "bg-green-100 text-green-700", 
      text: "Normal",
      iconBg: "bg-green-100 text-green-600"
    },
    warning: { 
      badge: "bg-yellow-100 text-yellow-700", 
      text: "Warning",
      iconBg: "bg-yellow-100 text-yellow-600"
    },
    critical: { 
      badge: "bg-red-100 text-red-700", 
      text: "Critical",
      iconBg: "bg-red-100 text-red-600"
    }
  };

  const config = statusConfig[status];

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { display: false },
      y: { display: false }
    },
    elements: {
      point: { radius: 0 },
      line: { tension: 0.4 }
    }
  };

  const data = {
    labels: chartData.map((_, i) => `${i}`),
    datasets: [{
      data: chartData,
      borderColor: 'hsl(var(--chart-1))',
      backgroundColor: 'hsla(var(--chart-1), 0.1)',
      fill: true
    }]
  };

  return (
    <Card className={`hover:shadow-lg transition-shadow ${className}`} data-testid={`card-vital-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${config.iconBg}`}>
              {icon}
            </div>
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
          </div>
          <Badge variant="secondary" className={config.badge}>
            {config.text}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="text-2xl font-bold" data-testid={`text-value-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          {value}{unit && ` ${unit}`}
        </div>
        <div className="text-sm text-muted-foreground" data-testid="text-last-updated">
          Last: {lastUpdated}
        </div>
        {chartData.length > 0 && (
          <div className="chart-container">
            <Line data={data} options={chartOptions} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
