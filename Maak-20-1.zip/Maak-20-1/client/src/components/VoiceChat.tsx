import { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Mic, MicOff, Volume2, VolumeX } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
/// <reference types="../types/speech" />

interface VoiceChatProps {
  onMessageReceived: (message: string) => void;
  onMessageSent?: (message: string) => void;
  disabled?: boolean;
}

export function VoiceChat({ onMessageReceived, onMessageSent, disabled = false }: VoiceChatProps) {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState(''); // State to hold error messages
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthesisRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Initialize speech recognition
  useEffect(() => {
    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      try {
        const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
        recognitionRef.current = new SpeechRecognition();

        if (recognitionRef.current) {
          recognitionRef.current.continuous = false;
          recognitionRef.current.interimResults = true;

          // Enhanced Arabic dialect support
          const getArabicLang = () => {
            // Try to detect user's preferred Arabic dialect
            const userLang = navigator.language || navigator.languages?.[0] || 'ar-SA';

            // Map common Arabic regions to their speech recognition codes
            const arabicDialects: Record<string, string> = {
              'ar-SA': 'ar-SA', // Saudi Arabia (Modern Standard Arabic)
              'ar-AE': 'ar-SA', // UAE -> Saudi dialect (closest supported)
              'ar-EG': 'ar-EG', // Egyptian Arabic
              'ar-JO': 'ar-JO', // Jordanian Arabic
              'ar-LB': 'ar-LB', // Lebanese Arabic
              'ar-SY': 'ar-SA', // Syrian -> Saudi dialect
              'ar-IQ': 'ar-SA', // Iraqi -> Saudi dialect
              'ar-KW': 'ar-SA', // Kuwaiti -> Saudi dialect
              'ar-QA': 'ar-SA', // Qatari -> Saudi dialect
              'ar-BH': 'ar-SA', // Bahraini -> Saudi dialect
              'ar-OM': 'ar-SA', // Omani -> Saudi dialect
              'ar-MA': 'ar-MA', // Moroccan Arabic
              'ar-DZ': 'ar-DZ', // Algerian Arabic
              'ar-TN': 'ar-TN', // Tunisian Arabic
            };

            return arabicDialects[userLang] || 'ar-SA'; // Default to Saudi Arabic
          };

          recognitionRef.current.lang = i18n.language === 'ar' ? getArabicLang() : 'en-US';
          recognitionRef.current.maxAlternatives = 1;

          recognitionRef.current.onstart = () => {
            setIsListening(true);
            setTranscript('');
            setError(''); // Clear error on new start
          };

          recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
            let finalTranscript = '';
            let interimTranscript = '';

            for (let i = event.resultIndex; i < event.results.length; i++) {
              const transcript = event.results[i][0].transcript;
              if (event.results[i].isFinal) {
                finalTranscript += transcript;
              } else {
                interimTranscript += transcript;
              }
            }

            setTranscript(finalTranscript || interimTranscript);

            if (finalTranscript) {
              onMessageReceived(finalTranscript);
              setTranscript('');
            }
          };

          recognitionRef.current.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            setIsListening(false);
            // Assuming there's an setIsProcessing state that needs to be reset, though it's not defined in the provided snippet.
            // If not, this line can be removed. For now, let's keep it as it was in the original `changes` snippet.
            // setIsProcessing(false); 

            let errorMessage = 'Voice recognition failed. Please try again.';

            switch (event.error) {
              case 'no-speech':
                errorMessage = 'No speech detected. Please try again.';
                break;
              case 'audio-capture':
                errorMessage = 'Microphone not available. Please check your microphone.';
                break;
              case 'not-allowed':
                errorMessage = 'Microphone access denied. Please enable microphone permissions.';
                break;
              case 'network':
                errorMessage = 'Network error. Please check your connection.';
                break;
              case 'aborted':
                errorMessage = 'Speech recognition was aborted.';
                break;
            }

            setError(errorMessage); // Set error state
            toast({
              title: 'Voice Recognition Error',
              description: errorMessage,
              variant: 'destructive'
            });
          };

          recognitionRef.current.onend = () => {
            setIsListening(false);
          };
        }
      } catch (error) {
        console.error('Failed to initialize speech recognition:', error);
        toast({
          title: t('chat.error'),
          description: 'Speech recognition not available on this device.',
          variant: 'destructive'
        });
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [i18n.language, onMessageReceived, toast, t]);

  // Speech synthesis function
  const speakMessage = (message: string) => {
    if ('speechSynthesis' in window) {
      // Stop any ongoing speech
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = i18n.language === 'ar' ? 'ar-SA' : 'en-US';
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;

      // Function to set voice after voices are loaded
      const setVoice = () => {
        const voices = window.speechSynthesis.getVoices();
        console.log('Available voices:', voices.length);

        if (voices.length > 0) {
          // Try to find a voice that matches the language
          const preferredVoice = voices.find(voice => 
            voice.lang.startsWith(i18n.language === 'ar' ? 'ar' : 'en')
          );

          if (preferredVoice) {
            utterance.voice = preferredVoice;
            console.log('Selected voice:', preferredVoice.name, preferredVoice.lang);
          } else {
            // Fallback to first available voice
            utterance.voice = voices[0];
            console.log('Using fallback voice:', voices[0].name, voices[0].lang);
          }
        }
      };

      // Load voices if they're not already loaded
      if (window.speechSynthesis.getVoices().length === 0) {
        window.speechSynthesis.onvoiceschanged = () => {
          setVoice();
          window.speechSynthesis.onvoiceschanged = null; // Remove listener
        };
      } else {
        setVoice();
      }

      utterance.onstart = () => {
        console.log('Speech started');
        setIsSpeaking(true);
      };

      utterance.onend = () => {
        console.log('Speech ended');
        setIsSpeaking(false);
      };

      utterance.onerror = (event) => {
        console.error('Speech synthesis error:', event.error);
        setIsSpeaking(false);
        toast({
          title: t('chat.error'),
          description: 'Text-to-speech failed. Please try again.',
          variant: 'destructive'
        });
      };

      synthesisRef.current = utterance;

      // Small delay to ensure voice is set
      setTimeout(() => {
        window.speechSynthesis.speak(utterance);
      }, 100);
    }
  };

  const startListening = async () => {
    if (!recognitionRef.current || isListening) return;

    try {
      setIsListening(true);
      setError(''); // Clear error on new start

      // Request microphone permission explicitly on mobile
      if (/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) {
        try {
          await navigator.mediaDevices.getUserMedia({ audio: true });
        } catch (permError) {
          console.error('Microphone permission denied:', permError);
          toast({
            title: t('chat.error'),
            description: 'Please allow microphone access and try again',
            variant: 'destructive'
          });
          setIsListening(false);
          return;
        }
      }

      // Update language before starting
      // Enhanced Arabic dialect support
          const getArabicLang = () => {
            // Try to detect user's preferred Arabic dialect
            const userLang = navigator.language || navigator.languages?.[0] || 'ar-SA';

            // Map common Arabic regions to their speech recognition codes
            const arabicDialects: Record<string, string> = {
              'ar-SA': 'ar-SA', // Saudi Arabia (Modern Standard Arabic)
              'ar-AE': 'ar-SA', // UAE -> Saudi dialect (closest supported)
              'ar-EG': 'ar-EG', // Egyptian Arabic
              'ar-JO': 'ar-JO', // Jordanian Arabic
              'ar-LB': 'ar-LB', // Lebanese Arabic
              'ar-SY': 'ar-SA', // Syrian -> Saudi dialect
              'ar-IQ': 'ar-SA', // Iraqi -> Saudi dialect
              'ar-KW': 'ar-SA', // Kuwaiti -> Saudi dialect
              'ar-QA': 'ar-SA', // Qatari -> Saudi dialect
              'ar-BH': 'ar-SA', // Bahraini -> Saudi dialect
              'ar-OM': 'ar-SA', // Omani -> Saudi dialect
              'ar-MA': 'ar-MA', // Moroccan Arabic
              'ar-DZ': 'ar-DZ', // Algerian Arabic
              'ar-TN': 'ar-TN', // Tunisian Arabic
            };

            return arabicDialects[userLang] || 'ar-SA'; // Default to Saudi Arabic
          };

          recognitionRef.current.lang = i18n.language === 'ar' ? getArabicLang() : 'en-US';

      // Mobile-specific: Add small delay for iOS
      if (/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) {
        setTimeout(() => {
          recognitionRef.current?.start();
        }, 100);
      } else {
        recognitionRef.current.start();
      }
    } catch (error) {
      console.error('Microphone access error:', error);
      setIsListening(false);
      toast({
        title: t('chat.error'),
        description: 'Microphone access denied. Please enable microphone permissions in your browser settings.',
        variant: 'destructive'
      });
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  };

  const stopSpeaking = () => {
    if (window.speechSynthesis && isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  // Check if speech recognition is supported
  const isSpeechRecognitionSupported = typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window);
  const isSpeechSynthesisSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

  // Debug voice capabilities
  useEffect(() => {
    console.log('Voice capabilities check:');
    console.log('Speech Recognition:', isSpeechRecognitionSupported);
    console.log('Speech Synthesis:', isSpeechSynthesisSupported);
    console.log('User Agent:', navigator.userAgent);
    console.log('Language:', i18n.language);

    if (isSpeechSynthesisSupported) {
      const voices = window.speechSynthesis.getVoices();
      console.log('Initial voices:', voices.length);

      if (voices.length === 0) {
        window.speechSynthesis.onvoiceschanged = () => {
          const loadedVoices = window.speechSynthesis.getVoices();
          console.log('Voices loaded:', loadedVoices.length);
          console.log('Available voices:', loadedVoices.map(v => `${v.name} (${v.lang})`));
        };
      } else {
        console.log('Available voices:', voices.map(v => `${v.name} (${v.lang})`));
      }
    }
  }, [isSpeechRecognitionSupported, isSpeechSynthesisSupported, i18n.language]);

  const processVoiceMessage = async (message: string) => {
    try {
      // Detect emotional tone from voice characteristics (basic implementation)
      const emotionalCues = {
        stress: /\b(متوتر|قلقان|خايف|مضطرب|worried|anxious|stressed)\b/i.test(message),
        pain: /\b(ألم|وجع|يوجعني|مؤلم|hurt|pain|ache)\b/i.test(message),
        urgent: /\b(عاجل|سريع|مستعجل|urgent|emergency|help)\b/i.test(message),
        improvement: /\b(أحسن|تحسن|بخير|better|improved|good)\b/i.test(message)
      };

      // Add emotional context to the message
      const enhancedMessage = {
        text: message,
        emotional_context: emotionalCues,
        voice_input: true,
        timestamp: new Date().toISOString()
      };

      // Send the enhanced voice message
      onMessageReceived(JSON.stringify(enhancedMessage));

      // Provide appropriate feedback based on emotional tone
      let toastMessage = message.substring(0, 50) + (message.length > 50 ? '...' : '');
      if (emotionalCues.urgent) {
        toastMessage = t('voice.urgentDetected') || "Urgent message detected - prioritizing response";
      } else if (emotionalCues.pain) {
        toastMessage = t('voice.painDetected') || "Pain indicators detected - analyzing carefully";
      }

      toast({
        title: t('voice.messageSent'),
        description: toastMessage,
      });
    } catch (error) {
      console.error('Error processing voice message:', error);
      toast({
        title: t('voice.error'),
        description: t('voice.processingError'),
        variant: 'destructive'
      });
    }
  };

  if (!isSpeechRecognitionSupported && !isSpeechSynthesisSupported) {
    return (
      <Card className="bg-muted/50">
        <CardContent className="p-4 text-center">
          <p className="text-sm text-muted-foreground">
            Voice features are not supported in this browser
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Try using Chrome, Safari, or Edge for voice support
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">{t('chat.voiceChat')}</h3>
          <div className="flex items-center space-x-2">
            {isSpeechRecognitionSupported && (
              <Button
                variant={isListening ? "destructive" : "default"}
                size="sm"
                onClick={isListening ? stopListening : startListening}
                disabled={disabled || isSpeaking}
                data-testid="button-voice-recognition"
              >
                {isListening ? (
                  <>
                    <MicOff className="w-4 h-4 mr-2" />
                    {t('chat.stopRecording')}
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4 mr-2" />
                    {t('chat.startRecording')}
                  </>
                )}
              </Button>
            )}

            {isSpeechSynthesisSupported && (
              <Button
                variant={isSpeaking ? "destructive" : "outline"}
                size="sm"
                onClick={isSpeaking ? stopSpeaking : () => speakMessage("Hello, I'm Zeina, your health assistant. How can I help you today?")}
                disabled={disabled}
                data-testid="button-text-to-speech"
              >
                {isSpeaking ? (
                  <>
                    <VolumeX className="w-4 h-4 mr-2" />
                    Stop
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4 mr-2" />
                    Test Voice
                  </>
                )}
              </Button>
            )}
          </div>
        </div>

        {isListening && (
          <div className="mb-4 p-3 bg-primary/10 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
              <span className="text-sm font-medium text-primary">{t('chat.listening')}</span>
            </div>
            {transcript && (
              <p className="text-sm text-muted-foreground italic">
                {transcript}
              </p>
            )}
            {error && (
              <p className="text-sm text-destructive mt-2">
                {error}
              </p>
            )}
          </div>
        )}

        {isSpeaking && (
          <div className="mb-4 p-3 bg-accent/10 rounded-lg">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
              <span className="text-sm font-medium text-accent">Zeina is speaking...</span>
            </div>
          </div>
        )}

        <p className="text-xs text-muted-foreground">
          {i18n.language === 'ar' 
            ? 'يمكنك التحدث مع زينة بالعربية أو الإنجليزية'
            : 'You can speak to Zeina in Arabic or English'
          }
        </p>
      </CardContent>
    </Card>
  );
}

// Expose the speakMessage function for external use
export const useSpeechSynthesis = () => {
  const { i18n } = useTranslation();

  const speak = (message: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = i18n.language === 'ar' ? 'ar-SA' : 'en-US';
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;

      const setVoice = () => {
        const voices = window.speechSynthesis.getVoices();
        if (voices.length > 0) {
          const preferredVoice = voices.find(voice => 
            voice.lang.startsWith(i18n.language === 'ar' ? 'ar' : 'en')
          );

          if (preferredVoice) {
            utterance.voice = preferredVoice;
          } else {
            utterance.voice = voices[0];
          }
        }
      };

      if (window.speechSynthesis.getVoices().length === 0) {
        window.speechSynthesis.onvoiceschanged = () => {
          setVoice();
          window.speechSynthesis.onvoiceschanged = null;
        };
      } else {
        setVoice();
      }

      setTimeout(() => {
        window.speechSynthesis.speak(utterance);
      }, 100);
    }
  };

  return { speak };
};