import { useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

// Simple voice chat permission checker and error handler
export function useVoiceChatFix() {
  const { toast } = useToast();

  useEffect(() => {
    // Request microphone permission on component mount
    const requestPermissions = async () => {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          await navigator.mediaDevices.getUserMedia({ audio: true });
          console.log('Microphone permission granted');
        } catch (error) {
          console.warn('Microphone permission not granted:', error);
        }
      }
    };

    requestPermissions();
  }, []);

  const showVoiceError = (error: string) => {
    let message = 'Voice recognition failed. Please try again.';
    
    switch (error) {
      case 'not-allowed':
        message = 'Please enable microphone access in your browser settings for voice features.';
        break;
      case 'audio-capture':
        message = 'Microphone not detected. Please check your microphone connection.';
        break;
      case 'network':
        message = 'Network error. Please check your internet connection.';
        break;
      case 'no-speech':
        message = 'No speech detected. Please speak clearly and try again.';
        break;
    }

    toast({
      title: 'Voice Recognition Issue',
      description: message,
      variant: 'destructive'
    });
  };

  return { showVoiceError };
}