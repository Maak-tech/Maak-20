import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Mic, MicOff, Volume2, VolumeX, Send, Loader2, 
  MessageCircle, Settings, Languages, Phone 
} from "lucide-react";
import { voiceService } from "@/lib/voice-interaction";
import { useTranslation } from 'react-i18next';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  isVoice?: boolean;
  emergencyLevel?: number;
}

export default function VoiceInteractiveChat() {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  
  // Chat state
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  // Fetch existing conversations
  const { data: conversations } = useQuery({
    queryKey: ["/api/me/conversations"],
    refetchInterval: 5000,
  });

  // Update messages when conversations change
  useEffect(() => {
    if (conversations && Array.isArray(conversations)) {
      const chatMessages: Message[] = conversations.map((conv: any) => ({
        id: conv.id,
        content: conv.message,
        role: conv.direction === 'inbound' ? 'user' : 'assistant',
        timestamp: new Date(conv.createdAt),
        isVoice: conv.meta?.isVoice || false,
        emergencyLevel: conv.emergencyLevel
      })).sort((a: Message, b: Message) => a.timestamp.getTime() - b.timestamp.getTime());
      
      setMessages(chatMessages);
    }
  }, [conversations]);
  
  // Voice state
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [voiceEnabled, setVoiceEnabled] = useState(voiceService.isSpeechEnabled);
  const [isAdaptiveMode, setIsAdaptiveMode] = useState(true);
  const [lastInteractionMode, setLastInteractionMode] = useState<'voice' | 'text'>('text');
  const [currentLanguage, setCurrentLanguage] = useState(i18n.language);
  
  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  
  // Chat mutation
  const chatMutation = useMutation({
    mutationFn: async ({ message, isVoiceInput }: { message: string, isVoiceInput: boolean }) => {
      const response = await fetch('/api/me/conversations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer mock'
        },
        body: JSON.stringify({ 
          message,
          language: i18n.language
        })
      });
      
      if (!response.ok) throw new Error('Chat request failed');
      return response.json();
    },
    onSuccess: async (data, variables) => {
      // Invalidate conversations to trigger refetch
      queryClient.invalidateQueries({ queryKey: ["/api/me/conversations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/symptoms"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/vitals"] });
      
      const assistantMessage: Message = {
        id: Date.now().toString(),
        content: data.zeinaResponse.message,
        role: 'assistant',
        timestamp: new Date(),
        isVoice: variables.isVoiceInput && isAdaptiveMode,
        emergencyLevel: data.extraction?.emergency_level
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      
      // Voice response if voice is enabled
      if (voiceEnabled) {
        await voiceService.respondToUser(data.zeinaResponse.message, variables.isVoiceInput);
      }
      
      // Show emergency notification if critical
      if (data.extraction?.emergency_level && data.extraction.emergency_level >= 3) {
        toast({
          title: "Emergency Alert",
          description: "Critical health situation detected",
          variant: "destructive"
        });
      }
      
      setIsTyping(false);
    },
    onError: () => {
      setIsTyping(false);
      toast({
        title: "Connection Error",
        description: "Unable to reach Zeina. Check your connection.",
        variant: "destructive"
      });
    }
  });

  // Voice service setup
  useEffect(() => {
    // Set language based on current locale
    voiceService.setLanguage(i18n.language === 'ar' ? 'ar-SA' : 'en-US');
    
    // Voice event listeners
    const unsubscribeListening = voiceService.on('listening', (listening: boolean) => {
      setIsListening(listening);
    });
    
    const unsubscribeTranscript = voiceService.on('transcript', (data: any) => {
      setInterimTranscript(data.interim);
      
      if (data.final) {
        handleVoiceMessage(data.final);
        setInterimTranscript('');
      }
    });

    // Auto-switch language when different language is detected
    const unsubscribeLanguageDetected = voiceService.on('languageDetected', (data: any) => {
      const { detected, current } = data;
      if (detected !== current) {
        const newLanguage = detected.startsWith('ar') ? 'ar' : 'en';
        if (newLanguage !== currentLanguage) {
          setCurrentLanguage(newLanguage);
          i18n.changeLanguage(newLanguage);
          voiceService.setLanguage(detected);
          
          toast({
            title: newLanguage === 'ar' ? "تم تغيير اللغة تلقائياً" : "Language auto-switched",
            description: newLanguage === 'ar' ? "تم اكتشاف العربية في كلامك" : "Arabic detected in your speech"
          });
        }
      }
    });
    
    const unsubscribeSpeaking = voiceService.on('speaking', (data: any) => {
      setIsSpeaking(data.started);
    });
    
    const unsubscribeError = voiceService.on('error', (error: any) => {
      toast({
        title: "Voice Error",
        description: error.type === 'recognition' ? "Could not understand speech" : "Voice synthesis failed",
        variant: "destructive"
      });
    });

    return () => {
      unsubscribeListening();
      unsubscribeTranscript();
      unsubscribeLanguageDetected();
      unsubscribeSpeaking();
      unsubscribeError();
    };
  }, [i18n.language, toast]);


  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle voice input
  const handleVoiceMessage = (transcript: string) => {
    if (!transcript.trim()) return;
    
    setLastInteractionMode('voice');
    
    const userMessage: Message = {
      id: Date.now().toString(),
      content: transcript,
      role: 'user',
      timestamp: new Date(),
      isVoice: true
    };
    
    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);
    
    chatMutation.mutate({ message: transcript, isVoiceInput: true });
  };

  // Handle text input
  const handleTextMessage = () => {
    if (!inputMessage.trim()) return;
    
    setLastInteractionMode('text');
    
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      role: 'user',
      timestamp: new Date(),
      isVoice: false
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);
    
    chatMutation.mutate({ message: inputMessage, isVoiceInput: false });
  };

  // Voice controls
  const toggleListening = async () => {
    if (isListening) {
      voiceService.stopListening();
    } else {
      if (!voiceService.isSupported) {
        toast({
          title: "Voice Not Supported",
          description: "Your browser doesn't support voice recognition",
          variant: "destructive"
        });
        return;
      }
      
      try {
        await voiceService.startListening();
      } catch (error) {
        toast({
          title: "Microphone Access Denied",
          description: "Please allow microphone access to use voice features",
          variant: "destructive"
        });
      }
    }
  };

  const toggleVoiceEnabled = () => {
    const newEnabled = !voiceEnabled;
    setVoiceEnabled(newEnabled);
    voiceService.enableSpeech(newEnabled);
    
    toast({
      title: newEnabled ? "Voice Enabled" : "Voice Disabled",
      description: newEnabled ? "Zeina will now respond with voice" : "Zeina will only respond with text"
    });
  };

  const toggleLanguage = () => {
    const newLanguage = currentLanguage === 'ar' ? 'en' : 'ar';
    setCurrentLanguage(newLanguage);
    i18n.changeLanguage(newLanguage);
    
    // Update voice service language
    const voiceLang = newLanguage === 'ar' ? 'ar-SA' : 'en-US';
    voiceService.setLanguage(voiceLang);
    
    toast({
      title: newLanguage === 'ar' ? "تم تغيير اللغة إلى العربية" : "Language changed to English",
      description: newLanguage === 'ar' ? "زينة ستتحدث بالعربية الآن" : "Zeina will now speak in English"
    });
  };

  const stopSpeaking = () => {
    voiceService.stopSpeaking();
  };

  const getMessageDisplayTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString(i18n.language, { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
            {isSpeaking ? (
              <Volume2 className="w-5 h-5 text-blue-600 animate-pulse" />
            ) : (
              <MessageCircle className="w-5 h-5 text-blue-600" />
            )}
          </div>
          <div>
            <h1 className="font-semibold text-gray-900">Zeina</h1>
            <p className="text-sm text-gray-500">
              {isListening ? t('chat.listening') : 
               isSpeaking ? t('chat.speaking') :
               isTyping ? t('chat.typing') : t('chat.ready')}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          {isAdaptiveMode && (
            <Badge variant={lastInteractionMode === 'voice' ? 'default' : 'secondary'}>
              {lastInteractionMode === 'voice' ? '🎤 Voice' : '💬 Text'}
            </Badge>
          )}
          
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleLanguage}
            className="text-blue-600 font-semibold"
            title={currentLanguage === 'ar' ? 'Switch to English' : 'Switch to Arabic'}
          >
            {currentLanguage === 'ar' ? 'ع' : 'A'}
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleVoiceEnabled}
            className={voiceEnabled ? 'text-blue-600' : 'text-gray-400'}
          >
            {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <Card className="mx-auto max-w-md">
            <CardContent className="p-6 text-center">
              <MessageCircle className="w-12 h-12 text-blue-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">
                {t('chat.welcome')}
              </h3>
              <p className="text-gray-600 mb-4">
                {voiceService.isSupported ? 
                  t('chat.voiceIntroduction') : 
                  t('chat.textIntroduction')
                }
              </p>
              {voiceService.isSupported && (
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                  <Phone className="w-4 h-4" />
                  <span>{t('chat.voiceReady')}</span>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                  message.role === 'user'
                    ? 'bg-blue-600 text-white'
                    : `bg-white text-gray-900 shadow-sm ${
                        message.emergencyLevel && message.emergencyLevel >= 2 
                          ? 'border-2 border-red-500' 
                          : ''
                      }`
                }`}
              >
                <div className="flex items-center space-x-2 mb-1">
                  {message.isVoice && (
                    <Volume2 className="w-3 h-3 opacity-70" />
                  )}
                  {message.emergencyLevel && message.emergencyLevel >= 2 && (
                    <Badge variant="destructive" className="text-xs">
                      {message.emergencyLevel >= 3 ? 'Emergency' : 'Urgent'}
                    </Badge>
                  )}
                </div>
                <p className="text-sm">{message.content}</p>
                <p className="text-xs opacity-70 mt-1">
                  {getMessageDisplayTime(message.timestamp)}
                </p>
              </div>
            </div>
          ))
        )}
        
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-200 rounded-2xl px-4 py-2">
              <Loader2 className="w-4 h-4 animate-spin" />
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Voice Interim Display */}
      {interimTranscript && (
        <div className="px-4 py-2 bg-blue-50 border-t">
          <div className="flex items-center space-x-2">
            <Mic className="w-4 h-4 text-blue-600 animate-pulse" />
            <span className="text-sm text-blue-700 italic">{interimTranscript}</span>
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="bg-white border-t p-4">
        <div className="flex items-center space-x-2">
          {/* Voice Button */}
          <Button
            variant={isListening ? "default" : "outline"}
            size="sm"
            onClick={toggleListening}
            disabled={!voiceService.isSupported}
            className={`p-3 ${isListening ? 'bg-red-500 hover:bg-red-600' : ''}`}
          >
            {isListening ? (
              <MicOff className="w-4 h-4" />
            ) : (
              <Mic className="w-4 h-4" />
            )}
          </Button>
          
          {/* Text Input */}
          <div className="flex-1 flex space-x-2">
            <Textarea
              ref={inputRef}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder={isListening ? t('chat.listeningPlaceholder') : t('chat.typePlaceholder')}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleTextMessage();
                }
              }}
              disabled={isListening}
              className="flex-1 min-h-[44px] resize-none"
              rows={2}
            />
            <Button
              onClick={handleTextMessage}
              disabled={!inputMessage.trim() || isListening || chatMutation.isPending}
              size="sm"
              className="px-3"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          
          {/* Speaking Control */}
          {isSpeaking && (
            <Button
              variant="outline"
              size="sm"
              onClick={stopSpeaking}
              className="px-3"
            >
              <VolumeX className="w-4 h-4" />
            </Button>
          )}
        </div>
        
        {voiceService.isSupported && (
          <div className="mt-2 text-center">
            <p className="text-xs text-gray-500">
              {isListening ? 
                t('chat.voiceInstructions.listening') : 
                t('chat.voiceInstructions.ready')
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
}