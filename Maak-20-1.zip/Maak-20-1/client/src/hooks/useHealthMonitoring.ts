
import { useState, useEffect } from 'react';
import { useToast } from './use-toast';

interface HealthMetrics {
  heartRate?: number;
  spo2?: number;
  temperature?: number;
  activity?: number;
}

export function useHealthMonitoring() {
  const [metrics, setMetrics] = useState<HealthMetrics>({});
  const [isMonitoring, setIsMonitoring] = useState(false);
  const { toast } = useToast();

  const startMonitoring = async () => {
    try {
      // Check if device has sensors (mock for now)
      if ('DeviceMotionEvent' in window) {
        setIsMonitoring(true);
        
        // Mock heart rate monitoring
        const interval = setInterval(() => {
          const baseHeartRate = 70;
          const variation = Math.random() * 20 - 10;
          const heartRate = Math.round(baseHeartRate + variation);
          
          setMetrics(prev => ({
            ...prev,
            heartRate,
            spo2: Math.round(95 + Math.random() * 4),
            temperature: 36.5 + Math.random() * 1.5
          }));
          
          // Alert for abnormal values
          if (heartRate > 100 || heartRate < 60) {
            toast({
              title: 'Heart Rate Alert',
              description: `Heart rate: ${heartRate} BPM - Consider checking with a healthcare provider`,
              variant: 'destructive'
            });
          }
        }, 5000);
        
        return () => clearInterval(interval);
      }
    } catch (error) {
      console.error('Health monitoring error:', error);
    }
  };

  const stopMonitoring = () => {
    setIsMonitoring(false);
    setMetrics({});
  };

  return {
    metrics,
    isMonitoring,
    startMonitoring,
    stopMonitoring
  };
}
