
import { useEffect } from 'react';

export function usePerformance(componentName: string) {
  useEffect(() => {
    const startTime = performance.now();
    
    return () => {
      const endTime = performance.now();
      const loadTime = endTime - startTime;
      
      // Log slow components
      if (loadTime > 100) {
        console.warn(`Slow component: ${componentName} took ${loadTime.toFixed(2)}ms`);
      }
      
      // Send to analytics (mock for now)
      if ('sendBeacon' in navigator) {
        navigator.sendBeacon('/api/analytics', JSON.stringify({
          component: componentName,
          loadTime,
          timestamp: new Date().toISOString()
        }));
      }
    };
  }, [componentName]);
}
