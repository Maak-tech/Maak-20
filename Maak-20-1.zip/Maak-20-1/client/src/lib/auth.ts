import { useState, useEffect } from "react";

interface User {
  id: string;
  email: string;
  role: string;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mock auth for development - in real app would use Supabase Auth
    const mockUser = {
      id: "mock-user-id",
      email: "user@example.com", 
      role: "user"
    };
    setUser(mockUser);
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    // Mock login
    const mockUser = { id: "mock-user-id", email, role: "user" };
    setUser(mockUser);
    return mockUser;
  };

  const logout = () => {
    setUser(null);
  };

  return {
    user,
    loading,
    login,
    logout
  };
}
