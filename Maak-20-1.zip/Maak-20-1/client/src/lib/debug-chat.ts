// Simple test to verify chat functionality
export async function testChatAPI() {
  try {
    const response = await fetch('/api/me/conversations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer mock'
      },
      body: JSON.stringify({
        message: 'Test from debug script',
        language: 'en'
      })
    });

    const data = await response.json();
    console.log('Chat API test result:', data);
    return data;
  } catch (error) {
    console.error('Chat API test error:', error);
    throw error;
  }
}