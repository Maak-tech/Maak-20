import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  en: {
    translation: {
      // Navigation
      nav: {
        dashboard: "Dashboard",
        chat: "Zeina",
        medications: "Medications", 
        resources: "Resources",
        settings: "Settings",
        members: "Members",
        alerts: "Alerts"
      },
      // Common
      common: {
        loading: "Loading...",
        save: "Save",
        cancel: "Cancel",
        delete: "Delete",
        edit: "Edit",
        close: "Close",
        back: "Back",
        next: "Next",
        submit: "Submit",
        search: "Search",
        filter: "Filter",
        export: "Export",
        import: "Import"
      },
      // Dashboard
      dashboard: {
        welcome: "Welcome to your health dashboard",
        subtitle: "Monitor your health in real-time",
        liveData: "Live Data",
        heartRate: "Heart Rate",
        bloodOxygen: "Blood Oxygen",
        bloodPressure: "Blood Pressure", 
        temperature: "Temperature",
        bpm: "BPM",
        recentVitals: "Recent Vitals",
        weeklyTrends: "Weekly Trends",
        noData: "No data available"
      },
      // Chat
      chat: {
        title: "Chat with Zeina",
        subtitle: "Your AI health assistant",
        typeMessage: "Type your message...",
        send: "Send",
        suggestions: {
          howFeeling: "How am I feeling today?",
          symptoms: "I have some symptoms to report",
          medication: "Remind me about my medication",
          howDoing: "How am I doing?"
        },
        voiceChat: "Voice Chat",
        startRecording: "Start Recording",
        stopRecording: "Stop Recording",
        listening: "Listening...",
        speaking: "Speaking...",
        typing: "Zeina is typing...",
        ready: "Ready",
        processing: "Processing...",
        welcome: "Hello! I'm Zeina",
        voiceIntroduction: "You can talk to me or type your messages. I'll respond naturally based on how you communicate!",
        textIntroduction: "Type your health questions and I'll help you with personalized insights.",
        voiceReady: "Voice interaction ready",
        typePlaceholder: "Ask me about your health...",
        listeningPlaceholder: "Listening... speak now",
        voiceInstructions: {
          listening: "Speak now, I'm listening...",
          ready: "Tap the microphone to start voice chat"
        }
      },
      // Medications
      medications: {
        title: "Medications",
        addMedication: "Add Medication",
        medicationName: "Medication Name",
        dose: "Dose",
        frequency: "Frequency",
        startDate: "Start Date",
        endDate: "End Date",
        instructions: "Instructions",
        critical: "Critical",
        schedule: "Schedule",
        taken: "Taken",
        missed: "Missed",
        pending: "Pending"
      },
      // Settings  
      settings: {
        title: "Settings",
        profile: "Profile",
        preferences: "Preferences",
        notifications: "Notifications",
        language: "Language",
        theme: "Theme",
        privacy: "Privacy",
        account: "Account"
      },
      // Auth
      auth: {
        welcome: "Welcome to Maak 2.0",
        signInPrompt: "Please sign in to continue",
        signIn: "Sign In",
        signOut: "Sign Out"
      },
      // Alerts
      alerts: {
        title: "Health Alerts",
        severity: {
          low: "Low",
          medium: "Medium", 
          high: "High",
          critical: "Critical"
        },
        types: {
          spo2_low: "Low Blood Oxygen",
          hr_high: "High Heart Rate",
          bp_crisis: "Blood Pressure Crisis",
          missed_meds: "Missed Medication",
          sleep_poor: "Poor Sleep Quality"
        }
      }
    }
  },
  ar: {
    translation: {
      // Navigation
      nav: {
        dashboard: "لوحة التحكم",
        chat: "زينة",
        medications: "الأدوية",
        resources: "الموارد", 
        settings: "الإعدادات",
        members: "الأعضاء",
        alerts: "التنبيهات"
      },
      // Common
      common: {
        loading: "جاري التحميل...",
        save: "حفظ",
        cancel: "إلغاء",
        delete: "حذف",
        edit: "تعديل",
        close: "إغلاق",
        back: "العودة",
        next: "التالي",
        submit: "إرسال",
        search: "بحث",
        filter: "تصفية",
        export: "تصدير",
        import: "استيراد"
      },
      // Dashboard
      dashboard: {
        welcome: "مرحباً بك في لوحة الصحة الخاصة بك",
        subtitle: "راقب صحتك في الوقت الفعلي",
        liveData: "بيانات مباشرة",
        heartRate: "معدل ضربات القلب",
        bloodOxygen: "أكسجين الدم",
        bloodPressure: "ضغط الدم",
        temperature: "درجة الحرارة",
        bpm: "نبضة/دقيقة",
        recentVitals: "العلامات الحيوية الأخيرة",
        weeklyTrends: "الاتجاهات الأسبوعية",
        noData: "لا توجد بيانات متاحة"
      },
      // Chat
      chat: {
        title: "محادثة مع زينة",
        subtitle: "مساعدك الصحي الذكي",
        typeMessage: "اكتب رسالتك...",
        send: "إرسال",
        suggestions: {
          howFeeling: "شلوني اليوم؟ / كيف أشعر اليوم؟",
          symptoms: "عندي أعراض أبيها أقولك عليها",
          medication: "ذكريني بالدوا / ذكرني بدوائي", 
          howDoing: "شلون حالي؟ / كيف أحوالي؟"
        },
        voiceChat: "محادثة صوتية",
        startRecording: "ابدأ التسجيل",
        stopRecording: "وقف التسجيل", 
        listening: "أسمعك...",
        speaking: "أتحدث...",
        typing: "زينة تكتب...",
        ready: "جاهزة",
        processing: "أفهم كلامك...",
        welcome: "أهلاً! أنا زينة",
        voiceIntroduction: "تقدر تكلمني أو تكتبلي رسائل. راح أرد عليك بشكل طبيعي حسب طريقة تواصلك معي!",
        textIntroduction: "اكتب أسئلتك الصحية وراح أساعدك بنصائح شخصية.",
        voiceReady: "المحادثة الصوتية جاهزة",
        typePlaceholder: "اسألني عن صحتك...",
        listeningPlaceholder: "أسمعك... تكلم الحين",
        voiceInstructions: {
          listening: "تكلم الحين، أسمعك...",
          ready: "اضغط على الميكروفون لبدء المحادثة الصوتية"
        },
        error: "مشكلة"
      },
      // Medications
      medications: {
        title: "الأدوية",
        addMedication: "إضافة دواء",
        medicationName: "اسم الدواء",
        dose: "الجرعة",
        frequency: "التكرار",
        startDate: "تاريخ البداية",
        endDate: "تاريخ النهاية",
        instructions: "التعليمات",
        critical: "مهم",
        schedule: "الجدولة",
        taken: "تم تناوله",
        missed: "تم تفويته",
        pending: "في الانتظار"
      },
      // Settings
      settings: {
        title: "الإعدادات",
        profile: "الملف الشخصي",
        preferences: "التفضيلات",
        notifications: "الإشعارات",
        language: "اللغة",
        theme: "المظهر",
        privacy: "الخصوصية",
        account: "الحساب"
      },
      // Auth
      auth: {
        welcome: "مرحباً بك في ماك 2.0",
        signInPrompt: "الرجاء تسجيل الدخول للمتابعة",
        signIn: "تسجيل الدخول",
        signOut: "تسجيل الخروج"
      },
      // Alerts
      alerts: {
        title: "التنبيهات الصحية",
        severity: {
          low: "منخفض",
          medium: "متوسط",
          high: "عالي", 
          critical: "حرج"
        },
        types: {
          spo2_low: "انخفاض أكسجين الدم",
          hr_high: "ارتفاع معدل ضربات القلب",
          bp_crisis: "أزمة ضغط الدم",
          missed_meds: "تفويت الدواء",
          sleep_poor: "جودة نوم ضعيفة"
        }
      }
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    debug: false,
    
    interpolation: {
      escapeValue: false, // not needed for react as it escapes by default
    },
    
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage'],
    },
  });

export default i18n;