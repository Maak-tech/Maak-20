// Mobile-specific features for Zeina Health Assistant

// Geolocation API for emergency services
export async function getCurrentLocation(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by this browser'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => resolve(position),
      (error) => reject(error),
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  });
}

// Camera access for health documentation
export async function capturePhoto(options = {}) {
  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('Camera is not supported by this browser');
    }

    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        width: { ideal: 1920 },
        height: { ideal: 1080 },
        facingMode: 'environment', // Use back camera by default
        ...options
      },
      audio: false
    });

    return stream;
  } catch (error) {
    console.error('Error accessing camera:', error);
    throw error;
  }
}

// File picker for health documents
export async function pickHealthDocument(): Promise<File[]> {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*,application/pdf,.doc,.docx';
    input.multiple = true;
    
    input.onchange = (e) => {
      const files = Array.from((e.target as HTMLInputElement).files || []);
      resolve(files);
    };
    
    input.click();
  });
}

// Push notification setup
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) {
    throw new Error('This browser does not support desktop notification');
  }

  if (Notification.permission === 'granted') {
    return 'granted';
  }

  if (Notification.permission !== 'denied') {
    const permission = await Notification.requestPermission();
    return permission;
  }

  return 'denied';
}

// Show local notification
export function showLocalNotification(title: string, options: NotificationOptions = {}) {
  if (Notification.permission === 'granted') {
    const notification = new Notification(title, {
      icon: '/attached_assets/generated_images/Maak_2.0_healthcare_logo_203f7d38.png',
      badge: '/attached_assets/generated_images/Maak_2.0_healthcare_logo_203f7d38.png',
      vibrate: [200, 100, 200],
      requireInteraction: false,
      ...options
    });

    // Auto-close after 5 seconds unless it's an emergency
    if (!options.requireInteraction) {
      setTimeout(() => notification.close(), 5000);
    }

    return notification;
  }
}

// Vibration API for alerts
export function vibratePhone(pattern: number | number[] = 200) {
  if ('vibrate' in navigator) {
    navigator.vibrate(pattern);
  }
}

// Wake lock to keep screen on during important health monitoring
export async function requestWakeLock(): Promise<WakeLockSentinel | null> {
  if ('wakeLock' in navigator) {
    try {
      const wakeLock = await (navigator as any).wakeLock.request('screen');
      console.log('Wake lock acquired');
      return wakeLock;
    } catch (error) {
      console.error('Failed to acquire wake lock:', error);
    }
  }
  return null;
}

// Share API for sharing health data
export async function shareHealthData(data: ShareData): Promise<void> {
  if (navigator.share) {
    try {
      await navigator.share(data);
      console.log('Health data shared successfully');
    } catch (error) {
      if ((error as Error).name !== 'AbortError') {
        console.error('Error sharing health data:', error);
        throw error;
      }
    }
  } else {
    // Fallback to clipboard
    if (navigator.clipboard && data.text) {
      await navigator.clipboard.writeText(data.text);
      console.log('Health data copied to clipboard');
    } else {
      throw new Error('Sharing not supported');
    }
  }
}

// Battery API for monitoring device health
export async function getBatteryInfo(): Promise<any> {
  if ('getBattery' in navigator) {
    try {
      const battery = await (navigator as any).getBattery();
      return {
        charging: battery.charging,
        level: Math.round(battery.level * 100),
        chargingTime: battery.chargingTime,
        dischargingTime: battery.dischargingTime
      };
    } catch (error) {
      console.error('Error getting battery info:', error);
    }
  }
  return null;
}

// Device orientation for emergency detection (falls, etc.)
export function startMotionDetection(callback: (data: DeviceMotionEvent) => void): () => void {
  if ('DeviceMotionEvent' in window) {
    const handleMotion = (event: DeviceMotionEvent) => {
      callback(event);
    };

    window.addEventListener('devicemotion', handleMotion);
    
    return () => {
      window.removeEventListener('devicemotion', handleMotion);
    };
  }
  
  return () => {}; // No-op if not supported
}

// Background sync registration
export async function registerBackgroundSync(tag: string): Promise<void> {
  if ('serviceWorker' in navigator && 'sync' in window.ServiceWorkerRegistration.prototype) {
    try {
      const registration = await navigator.serviceWorker.ready;
      await (registration as any).sync.register(tag);
      console.log(`Background sync registered for tag: ${tag}`);
    } catch (error) {
      console.error('Failed to register background sync:', error);
    }
  }
}

// Offline storage utilities
export const offlineStorage = {
  // Store health data offline
  async storeHealthData(key: string, data: any): Promise<void> {
    try {
      const dataWithTimestamp = {
        ...data,
        timestamp: Date.now(),
        offline: true
      };
      localStorage.setItem(`offline-health-${key}`, JSON.stringify(dataWithTimestamp));
    } catch (error) {
      console.error('Failed to store offline health data:', error);
    }
  },

  // Get offline health data
  async getHealthData(key: string): Promise<any> {
    try {
      const stored = localStorage.getItem(`offline-health-${key}`);
      return stored ? JSON.parse(stored) : null;
    } catch (error) {
      console.error('Failed to retrieve offline health data:', error);
      return null;
    }
  },

  // Clear offline health data
  async clearHealthData(key: string): Promise<void> {
    try {
      localStorage.removeItem(`offline-health-${key}`);
    } catch (error) {
      console.error('Failed to clear offline health data:', error);
    }
  },

  // Get all offline keys
  getOfflineKeys(): string[] {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith('offline-health-')) {
        keys.push(key.replace('offline-health-', ''));
      }
    }
    return keys;
  }
};

// Network status monitoring
export class NetworkMonitor {
  private listeners: ((online: boolean) => void)[] = [];

  constructor() {
    window.addEventListener('online', () => this.notifyListeners(true));
    window.addEventListener('offline', () => this.notifyListeners(false));
  }

  get isOnline(): boolean {
    return navigator.onLine;
  }

  addListener(callback: (online: boolean) => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(listener => listener !== callback);
    };
  }

  private notifyListeners(online: boolean): void {
    this.listeners.forEach(listener => listener(online));
  }
}

// Create singleton instance
export const networkMonitor = new NetworkMonitor();