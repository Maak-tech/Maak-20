import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import * as schema from "@shared/schema";

const sql = neon(import.meta.env.VITE_DATABASE_URL || "/api");
export const db = drizzle(sql, { schema });

export function getAuthToken(): string | null {
  // In a real implementation, this would get the JWT from Supabase Auth
  return localStorage.getItem('auth_token');
}

export function setAuthHeaders(): Record<string, string> {
  const token = getAuthToken();
  return token ? { 'Authorization': `Bearer ${token}` } : {};
}
