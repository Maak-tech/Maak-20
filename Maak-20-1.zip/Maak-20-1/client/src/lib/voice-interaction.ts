// Voice Interaction Service for Zeina AI Assistant
// Handles speech recognition, text-to-speech, and adaptive voice/text modes

export class VoiceInteractionService {
  private recognition: SpeechRecognition | null = null;
  private synthesis: SpeechSynthesis;
  private isListening = false;
  private isEnabledSpeech = false;
  private currentLanguage = 'en-US';
  private listeners: {[key: string]: Function[]} = {};
  private zeina_voice: SpeechSynthesisVoice | null = null;

  constructor() {
    this.synthesis = window.speechSynthesis;
    this.initializeSpeechRecognition();
    this.loadVoicePreferences();
  }

  private initializeSpeechRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      this.recognition = new SpeechRecognitionClass();
      
      if (this.recognition) {
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.maxAlternatives = 3;
        this.recognition.lang = this.currentLanguage;
        
        this.recognition.onstart = () => {
          this.isListening = true;
          this.emit('listening', true);
        };

        this.recognition.onend = () => {
          this.isListening = false;
          this.emit('listening', false);
        };

        this.recognition.onresult = (event: SpeechRecognitionEvent) => {
          let interimTranscript = '';
          let finalTranscript = '';
          let bestConfidence = 0;
          let detectedLanguage = this.currentLanguage;

          for (let i = event.resultIndex; i < event.results.length; i++) {
            const results = event.results[i];
            const transcript = results[0].transcript;
            const confidence = results[0].confidence;
            
            // Detect if text contains Arabic characters
            const hasArabic = /[\u0600-\u06FF]/.test(transcript);
            const hasEnglish = /[a-zA-Z]/.test(transcript);
            
            // Auto-detect language based on script
            if (hasArabic && !hasEnglish) {
              detectedLanguage = 'ar-SA';
            } else if (hasEnglish && !hasArabic) {
              detectedLanguage = 'en-US';
            }
            
            if (results.isFinal) {
              finalTranscript += transcript;
            } else {
              interimTranscript += transcript;
            }
            
            if (confidence > bestConfidence) {
              bestConfidence = confidence;
            }
          }

          // If detected language differs significantly from current, suggest language switch
          if (detectedLanguage !== this.currentLanguage && finalTranscript.length > 0) {
            console.log(`Detected language: ${detectedLanguage}, Current: ${this.currentLanguage}`);
            this.emit('languageDetected', { detected: detectedLanguage, current: this.currentLanguage });
          }

          this.emit('transcript', { 
            interim: interimTranscript,
            final: finalTranscript,
            confidence: bestConfidence || 0.8,
            detectedLanguage: detectedLanguage
          });
        };

        this.recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
          console.error('Speech recognition error:', event.error);
          this.emit('error', { type: 'recognition', error: event.error });
        };
      }
    }
  }

  private loadVoicePreferences() {
    // Load user's voice preferences
    const savedLang = localStorage.getItem('zeina-voice-lang') || 'en-US';
    const savedVoiceEnabled = localStorage.getItem('zeina-voice-enabled') === 'true';
    
    this.currentLanguage = savedLang;
    this.isEnabledSpeech = savedVoiceEnabled;
    
    // Wait for voices to be loaded
    if (this.synthesis.onvoiceschanged !== undefined) {
      this.synthesis.onvoiceschanged = () => {
        this.selectOptimalVoice();
      };
    } else {
      this.selectOptimalVoice();
    }
  }

  private selectOptimalVoice() {
    const voices = this.synthesis.getVoices();
    
    // Premium/Natural voice keywords (these sound more human)
    const premiumVoiceKeywords = [
      'neural', 'premium', 'natural', 'enhanced', 'wavenet', 'studio',
      'journey', 'nova', 'alloy', 'echo', 'fable', 'onyx', 'shimmer'
    ];
    
    // Preferred voices for different languages (prioritizing female voices for Zeina)
    const voicePreferences = {
      'en-US': ['Samantha', 'Karen', 'Moira', 'Victoria', 'Allison', 'Susan', 'Alex', 'Ava'],
      'en-GB': ['Kate', 'Serena', 'Emma', 'Amy'],
      'ar-SA': ['Salma', 'Laila', 'Arabic Female', 'Microsoft Salma Desktop', 'Naayf', 'Majed', 'Maged', 'Tarik', 'Arabic Male']
    };

    const languageKey = this.currentLanguage as keyof typeof voicePreferences;
    const preferredVoices = voicePreferences[languageKey] || [];
    
    let bestVoice = null;
    let bestScore = -1;

    for (const voice of voices) {
      let score = 0;
      const voiceName = voice.name.toLowerCase();
      
      // Language match bonus
      if (voice.lang.startsWith(this.currentLanguage.split('-')[0])) {
        score += 100;
      }
      
      // Preferred voice name bonus
      for (const preferred of preferredVoices) {
        if (voice.name.includes(preferred)) {
          score += 50;
          break;
        }
      }
      
      // Premium/Natural voice bonus
      for (const keyword of premiumVoiceKeywords) {
        if (voiceName.includes(keyword)) {
          score += 40;
          break;
        }
      }
      
      // Female voice preference for Zeina
      if (voiceName.includes('female') || voiceName.includes('woman') || 
          ['samantha', 'karen', 'moira', 'victoria', 'kate', 'emma', 'amy', 'ava', 'allison', 'susan', 'serena', 'salma', 'laila'].some(f => voiceName.includes(f))) {
        score += 30;
      }
      
      // Local service bonus (usually higher quality)
      if (voice.localService) {
        score += 20;
      }
      
      // Avoid robotic sounding voices
      if (voiceName.includes('robot') || voiceName.includes('synthetic') || voiceName.includes('default')) {
        score -= 20;
      }
      
      if (score > bestScore) {
        bestScore = score;
        bestVoice = voice;
      }
    }

    this.zeina_voice = bestVoice || voices[0] || null;
    
    // Debug logging
    if (this.zeina_voice) {
      console.log(`Selected voice for ${this.currentLanguage}:`, this.zeina_voice.name, `(Score: ${bestScore})`);
      console.log('Available voices for language:', voices.filter(v => v.lang.startsWith(this.currentLanguage.split('-')[0])).map(v => `${v.name} (${v.lang})`));
    } else {
      console.warn('No suitable voice found for language:', this.currentLanguage);
    }
  }

  // Public API methods
  startListening(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.recognition) {
        reject(new Error('Speech recognition not supported'));
        return;
      }

      if (this.isListening) {
        resolve();
        return;
      }

      try {
        this.recognition.start();
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  }

  stopListening(): void {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
    }
  }

  speak(text: string, options: {
    rate?: number;
    pitch?: number;
    volume?: number;
    interrupt?: boolean;
  } = {}): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.isEnabledSpeech) {
        resolve();
        return;
      }

      // Stop current speech if interrupt requested
      if (options.interrupt !== false) {
        this.synthesis.cancel();
      }

      const utterance = new SpeechSynthesisUtterance(text);
      
      // Configure voice
      if (this.zeina_voice) {
        utterance.voice = this.zeina_voice;
      }
      utterance.lang = this.currentLanguage;
      
      // Enhanced natural speech parameters
      let baseRate = options.rate || 0.85;  // Slightly slower for clarity
      let basePitch = options.pitch || 1.1; // Slightly higher pitch for feminine voice
      const baseVolume = options.volume || 0.9; // Slightly softer volume
      
      // Adaptive rate based on text characteristics
      const wordCount = text.split(' ').length;
      if (wordCount > 20) {
        baseRate *= 0.95; // Slower for longer sentences
      } else if (wordCount < 5) {
        baseRate *= 1.05; // Slightly faster for short responses
      }
      
      // Adjust for different content types
      if (text.includes('?')) {
        basePitch *= 1.05; // Slightly higher pitch for questions
      }
      if (text.includes('!')) {
        baseRate *= 1.1; // Slightly more energetic for exclamations
        basePitch *= 1.02;
      }
      if (text.match(/[.,;]/g)?.length > 3) {
        baseRate *= 0.92; // Slower for complex sentences with punctuation
      }
      
      // Add subtle variations for more natural speech
      const rateVariation = (Math.random() - 0.5) * 0.08 * baseRate;
      const pitchVariation = (Math.random() - 0.5) * 0.06 * basePitch;
      
      utterance.rate = Math.max(0.6, Math.min(1.8, baseRate + rateVariation));
      utterance.pitch = Math.max(0.8, Math.min(1.5, basePitch + pitchVariation));
      utterance.volume = Math.max(0.7, Math.min(1.0, baseVolume + (Math.random() - 0.5) * 0.1));

      utterance.onstart = () => {
        this.emit('speaking', { started: true, text });
      };

      utterance.onend = () => {
        this.emit('speaking', { started: false, text });
        resolve();
      };

      utterance.onerror = (event) => {
        this.emit('error', { type: 'synthesis', error: event.error });
        reject(new Error(`Speech synthesis error: ${event.error}`));
      };

      this.synthesis.speak(utterance);
    });
  }

  stopSpeaking(): void {
    this.synthesis.cancel();
  }

  // Language and preferences
  setLanguage(lang: string): void {
    this.currentLanguage = lang;
    localStorage.setItem('zeina-voice-lang', lang);
    
    if (this.recognition) {
      this.recognition.lang = lang;
    }
    
    this.selectOptimalVoice();
    this.emit('languageChanged', lang);
  }

  enableSpeech(enabled: boolean): void {
    this.isEnabledSpeech = enabled;
    localStorage.setItem('zeina-voice-enabled', enabled.toString());
    this.emit('speechEnabledChanged', enabled);
  }

  // Adaptive conversation modes
  enableAdaptiveMode(): void {
    // Enable automatic switching between voice and text based on user behavior
    localStorage.setItem('zeina-adaptive-mode', 'true');
  }

  // Smart voice activity detection
  detectVoiceActivity(): Promise<boolean> {
    return new Promise(async (resolve) => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        resolve(false);
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const audioContext = new AudioContext();
        const analyser = audioContext.createAnalyser();
        const microphone = audioContext.createMediaStreamSource(stream);
        
        microphone.connect(analyser);
        analyser.fftSize = 512;
        
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);

        let silenceCount = 0;
        const checkAudio = () => {
          analyser.getByteFrequencyData(dataArray);
          
          // Calculate average volume
          const average = dataArray.reduce((sum, value) => sum + value, 0) / dataArray.length;
          
          if (average > 10) { // Voice detected
            stream.getTracks().forEach(track => track.stop());
            audioContext.close();
            resolve(true);
          } else {
            silenceCount++;
            if (silenceCount > 50) { // ~2 seconds of silence
              stream.getTracks().forEach(track => track.stop());
              audioContext.close();
              resolve(false);
            } else {
              requestAnimationFrame(checkAudio);
            }
          }
        };

        checkAudio();
      } catch (error) {
        console.error('Voice activity detection failed:', error);
        resolve(false);
      }
    });
  }

  // Zeina-specific voice responses
  async respondToUser(message: string, isVoiceInput: boolean = false): Promise<void> {
    // Zeina responds with voice if speech is enabled (regardless of user input type)
    if (this.isEnabledSpeech) {
      await this.speak(message);
    }
    
    // Also emit for UI updates
    this.emit('response', { message, isVoice: this.isEnabledSpeech });
  }

  // Event system
  on(event: string, callback: Function): () => void {
    if (!this.listeners[event]) {
      this.listeners[event] = [];
    }
    this.listeners[event].push(callback);
    
    // Return unsubscribe function
    return () => {
      this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
    };
  }

  private emit(event: string, data?: any): void {
    if (this.listeners[event]) {
      this.listeners[event].forEach(callback => callback(data));
    }
  }

  // Getters
  get isSupported(): boolean {
    return !!(this.recognition && this.synthesis);
  }

  get isCurrentlyListening(): boolean {
    return this.isListening;
  }

  get isSpeechEnabled(): boolean {
    return this.isEnabledSpeech;
  }

  get currentVoice(): SpeechSynthesisVoice | null {
    return this.zeina_voice;
  }

  get availableVoices(): SpeechSynthesisVoice[] {
    return this.synthesis.getVoices();
  }

  // Cleanup
  destroy(): void {
    this.stopListening();
    this.stopSpeaking();
    this.listeners = {};
  }
}

// Create singleton instance
export const voiceService = new VoiceInteractionService();