import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings as SettingsIcon, 
  Shield, 
  Bell, 
  Users, 
  AlertTriangle,
  Save,
  Plus,
  Trash2
} from "lucide-react";

export default function AdminSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDirty, setIsDirty] = useState(false);

  // Fetch admin settings
  const { data: settings, isLoading } = useQuery({
    queryKey: ["/api/admin/settings"],
    queryFn: () => {
      // Mock data until backend integration
      return Promise.resolve({
        family: {
          name: "Hassan Family",
          description: "Family health monitoring group"
        },
        notifications: {
          criticalAlertsEnabled: true,
          emailNotifications: true,
          smsNotifications: false,
          dailyReports: true,
          weeklyReports: true
        },
        alertThresholds: {
          heartRateHigh: 130,
          heartRateLow: 50,
          spo2Low: 90,
          bpSystolicHigh: 180,
          bpDiastolicHigh: 110
        },
        members: [
          {
            id: "member-1",
            name: "Ahmed Hassan",
            email: "ahmed@example.com",
            role: "member",
            status: "active"
          },
          {
            id: "member-2", 
            name: "Fatima Hassan",
            email: "fatima@example.com",
            role: "member",
            status: "active"
          },
          {
            id: "member-3",
            name: "Mohammed Hassan",
            email: "mohammed@example.com", 
            role: "member",
            status: "active"
          }
        ]
      });
    }
  });

  const [localSettings, setLocalSettings] = useState({
    family: { name: "", description: "" },
    notifications: {
      criticalAlertsEnabled: true,
      emailNotifications: true,
      smsNotifications: false,
      dailyReports: true,
      weeklyReports: true
    },
    alertThresholds: {
      heartRateHigh: 130,
      heartRateLow: 50,
      spo2Low: 90,
      bpSystolicHigh: 180,
      bpDiastolicHigh: 110
    }
  });

  // Initialize local settings when data loads
  useState(() => {
    if (settings) {
      setLocalSettings({
        family: settings.family || { name: "", description: "" },
        notifications: settings.notifications || {
          criticalAlertsEnabled: true,
          emailNotifications: true,
          smsNotifications: false,
          dailyReports: true,
          weeklyReports: true
        },
        alertThresholds: settings.alertThresholds || {
          heartRateHigh: 130,
          heartRateLow: 50,
          spo2Low: 90,
          bpSystolicHigh: 180,
          bpDiastolicHigh: 110
        }
      });
    }
  }, [settings]);

  // Save settings mutation
  const saveSettings = useMutation({
    mutationFn: async () => {
      return apiRequest("PUT", "/api/admin/settings", localSettings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/settings"] });
      setIsDirty(false);
      toast({ title: "Settings saved successfully" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  const updateSetting = (section: string, key: string, value: any) => {
    setLocalSettings(prev => ({
      ...prev,
      [section]: { ...prev[section as keyof typeof prev], [key]: value }
    }));
    setIsDirty(true);
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const members = settings?.members || [];

  return (
    <div className="max-w-4xl mx-auto px-4 py-6" data-testid="page-admin-settings">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center" data-testid="text-admin-settings-title">
            <SettingsIcon className="w-6 h-6 mr-2" />
            Admin Settings
          </h1>
          <p className="text-muted-foreground">Manage family settings and monitoring preferences</p>
        </div>
        <Button 
          onClick={() => saveSettings.mutate()}
          disabled={!isDirty || saveSettings.isPending}
          data-testid="button-save-settings"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Changes
        </Button>
      </div>

      <div className="space-y-6">
        {/* Family Information */}
        <Card data-testid="card-family-info">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="w-5 h-5 mr-2" />
              Family Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="familyName">Family Name</Label>
              <Input
                id="familyName"
                value={localSettings.family.name}
                onChange={(e) => updateSetting("family", "name", e.target.value)}
                placeholder="Enter family name"
                data-testid="input-family-name"
              />
            </div>
            <div>
              <Label htmlFor="familyDescription">Description</Label>
              <Input
                id="familyDescription"
                value={localSettings.family.description}
                onChange={(e) => updateSetting("family", "description", e.target.value)}
                placeholder="Optional family description"
                data-testid="input-family-description"
              />
            </div>
          </CardContent>
        </Card>

        {/* Alert Thresholds */}
        <Card data-testid="card-alert-thresholds">
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Alert Thresholds
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="heartRateHigh">High Heart Rate (BPM)</Label>
                <Input
                  id="heartRateHigh"
                  type="number"
                  value={localSettings.alertThresholds.heartRateHigh}
                  onChange={(e) => updateSetting("alertThresholds", "heartRateHigh", parseInt(e.target.value))}
                  data-testid="input-hr-high"
                />
              </div>
              <div>
                <Label htmlFor="heartRateLow">Low Heart Rate (BPM)</Label>
                <Input
                  id="heartRateLow"
                  type="number"
                  value={localSettings.alertThresholds.heartRateLow}
                  onChange={(e) => updateSetting("alertThresholds", "heartRateLow", parseInt(e.target.value))}
                  data-testid="input-hr-low"
                />
              </div>
              <div>
                <Label htmlFor="spo2Low">Low SpO₂ (%)</Label>
                <Input
                  id="spo2Low"
                  type="number"
                  value={localSettings.alertThresholds.spo2Low}
                  onChange={(e) => updateSetting("alertThresholds", "spo2Low", parseInt(e.target.value))}
                  data-testid="input-spo2-low"
                />
              </div>
              <div>
                <Label htmlFor="bpSystolicHigh">High Systolic BP (mmHg)</Label>
                <Input
                  id="bpSystolicHigh"
                  type="number"
                  value={localSettings.alertThresholds.bpSystolicHigh}
                  onChange={(e) => updateSetting("alertThresholds", "bpSystolicHigh", parseInt(e.target.value))}
                  data-testid="input-bp-systolic-high"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card data-testid="card-notification-settings">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Bell className="w-5 h-5 mr-2" />
              Admin Notification Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="criticalAlerts">Critical Alert Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Receive immediate notifications for high-severity alerts
                </p>
              </div>
              <Switch
                id="criticalAlerts"
                checked={localSettings.notifications.criticalAlertsEnabled}
                onCheckedChange={(checked) => updateSetting("notifications", "criticalAlertsEnabled", checked)}
                data-testid="switch-critical-alerts"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="emailNotifications">Email Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Send alert notifications via email
                </p>
              </div>
              <Switch
                id="emailNotifications"
                checked={localSettings.notifications.emailNotifications}
                onCheckedChange={(checked) => updateSetting("notifications", "emailNotifications", checked)}
                data-testid="switch-email-notifications"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="smsNotifications">SMS Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Send critical alerts via SMS
                </p>
              </div>
              <Switch
                id="smsNotifications"
                checked={localSettings.notifications.smsNotifications}
                onCheckedChange={(checked) => updateSetting("notifications", "smsNotifications", checked)}
                data-testid="switch-sms-notifications"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="dailyReports">Daily Health Reports</Label>
                <p className="text-sm text-muted-foreground">
                  Receive daily summary of family health status
                </p>
              </div>
              <Switch
                id="dailyReports"
                checked={localSettings.notifications.dailyReports}
                onCheckedChange={(checked) => updateSetting("notifications", "dailyReports", checked)}
                data-testid="switch-daily-reports"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="weeklyReports">Weekly Health Reports</Label>
                <p className="text-sm text-muted-foreground">
                  Receive weekly comprehensive health analytics
                </p>
              </div>
              <Switch
                id="weeklyReports"
                checked={localSettings.notifications.weeklyReports}
                onCheckedChange={(checked) => updateSetting("notifications", "weeklyReports", checked)}
                data-testid="switch-weekly-reports"
              />
            </div>
          </CardContent>
        </Card>

        {/* Family Members */}
        <Card data-testid="card-family-members">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Family Members
              </div>
              <Button size="sm" data-testid="button-add-member">
                <Plus className="w-4 h-4 mr-2" />
                Add Member
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {members.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No family members added yet
              </p>
            ) : (
              <div className="space-y-3">
                {members.map((member: any) => (
                  <div 
                    key={member.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                    data-testid={`member-item-${member.id}`}
                  >
                    <div>
                      <div className="font-medium" data-testid="text-member-name">
                        {member.name}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {member.email}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Select value={member.role}>
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="member">Member</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        data-testid="button-remove-member"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Save Button */}
        {isDirty && (
          <div className="sticky bottom-4 flex justify-center">
            <Button 
              onClick={() => saveSettings.mutate()}
              disabled={saveSettings.isPending}
              size="lg"
              className="shadow-lg"
              data-testid="button-save-floating"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
