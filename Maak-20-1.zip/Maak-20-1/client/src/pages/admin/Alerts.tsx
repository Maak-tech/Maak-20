import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, CheckCircle, Clock, Filter, Search, User } from "lucide-react";

interface Alert {
  id: string;
  type: string;
  severity: "low" | "med" | "high";
  message: string;
  status: "open" | "acknowledged" | "resolved";
  createdAt: string;
  memberName?: string;
  userId: string;
}

export default function Alerts() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("open");
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch alerts
  const { data: alerts, isLoading } = useQuery({
    queryKey: ["/api/admin/alerts", statusFilter],
    queryFn: () => {
      // Mock data until backend integration
      return Promise.resolve([
        {
          id: "alert-1",
          type: "spo2_low",
          severity: "high" as const,
          message: "SpO₂ dropped to 88% at 11:30 AM",
          status: "open" as const,
          createdAt: "2024-01-15T11:30:00Z",
          memberName: "Mohammed Hassan",
          userId: "member-3"
        },
        {
          id: "alert-2", 
          type: "hr_high",
          severity: "med" as const,
          message: "Heart rate reached 135 BPM at 2:30 PM",
          status: "open" as const,
          createdAt: "2024-01-15T14:30:00Z",
          memberName: "Ahmed Hassan",
          userId: "member-1"
        },
        {
          id: "alert-3",
          type: "missed_med",
          severity: "med" as const,
          message: "Missed medication: Lisinopril at 8:00 AM",
          status: "acknowledged" as const,
          createdAt: "2024-01-15T08:30:00Z",
          memberName: "Fatima Hassan",
          userId: "member-2"
        }
      ].filter(alert => statusFilter === "all" || alert.status === statusFilter));
    }
  });

  // Acknowledge alert mutation
  const acknowledgeAlert = useMutation({
    mutationFn: async (alertId: string) => {
      return apiRequest("POST", `/api/admin/alerts/${alertId}/acknowledge`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/alerts"] });
      toast({ title: "Alert acknowledged" });
    },
    onError: () => {
      toast({ title: "Failed to acknowledge alert", variant: "destructive" });
    },
  });

  // Resolve alert mutation
  const resolveAlert = useMutation({
    mutationFn: async ({ alertId, notes }: { alertId: string; notes?: string }) => {
      return apiRequest("POST", `/api/admin/alerts/${alertId}/resolve`, { notes });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/alerts"] });
      toast({ title: "Alert resolved" });
    },
    onError: () => {
      toast({ title: "Failed to resolve alert", variant: "destructive" });
    },
  });

  const getSeverityConfig = (severity: string) => {
    switch (severity) {
      case "high":
        return {
          badge: "bg-red-100 text-red-700 border-red-200",
          text: "Critical",
          bgColor: "bg-red-50 border-red-200",
          icon: "text-red-600"
        };
      case "med":
        return {
          badge: "bg-yellow-100 text-yellow-700 border-yellow-200",
          text: "Warning",
          bgColor: "bg-yellow-50 border-yellow-200",
          icon: "text-yellow-600"
        };
      case "low":
        return {
          badge: "bg-blue-100 text-blue-700 border-blue-200",
          text: "Info",
          bgColor: "bg-blue-50 border-blue-200", 
          icon: "text-blue-600"
        };
      default:
        return {
          badge: "bg-gray-100 text-gray-700",
          text: "Unknown",
          bgColor: "bg-gray-50",
          icon: "text-gray-600"
        };
    }
  };

  const formatAlertType = (type: string) => {
    return type.replace(/_/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase());
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMinutes = Math.floor((now.getTime() - time.getTime()) / 60000);
    
    if (diffMinutes < 60) return `${diffMinutes} minutes ago`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)} hours ago`;
    return `${Math.floor(diffMinutes / 1440)} days ago`;
  };

  const filteredAlerts = alerts?.filter((alert: Alert) =>
    alert.memberName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    alert.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
    formatAlertType(alert.type).toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-24 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6" data-testid="page-admin-alerts">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-alerts-title">
            Family Alerts
          </h1>
          <p className="text-muted-foreground">Monitor and manage health alerts for all family members</p>
        </div>
      </div>

      {/* Filters and Search */}
      <Card className="mb-6" data-testid="card-alert-filters">
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Filter by:</span>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40" data-testid="select-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="open">Open Alerts</SelectItem>
                <SelectItem value="acknowledged">Acknowledged</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="all">All Alerts</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex-1 max-w-sm">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search alerts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-alerts"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Alerts List */}
      <Card data-testid="card-alerts-list">
        <CardHeader>
          <CardTitle className="text-lg">
            {statusFilter === "open" ? "Active Alerts" : 
             statusFilter === "acknowledged" ? "Acknowledged Alerts" :
             statusFilter === "resolved" ? "Resolved Alerts" : "All Alerts"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredAlerts.length === 0 ? (
            <div className="text-center py-12">
              <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="text-lg font-medium text-muted-foreground mb-2">
                No alerts found
              </h3>
              <p className="text-muted-foreground">
                {statusFilter === "open" ? 
                  "All family members are healthy with no active alerts" :
                  `No ${statusFilter} alerts match your search criteria`
                }
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredAlerts.map((alert: Alert) => {
                const config = getSeverityConfig(alert.severity);
                
                return (
                  <div
                    key={alert.id}
                    className={`flex items-start justify-between p-4 rounded-lg border ${config.bgColor}`}
                    data-testid={`alert-item-${alert.id}`}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        alert.severity === "high" ? "bg-red-500" :
                        alert.severity === "med" ? "bg-yellow-500" : "bg-blue-500"
                      }`}></div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <Badge 
                            variant="outline" 
                            className={config.badge}
                            data-testid={`badge-severity-${alert.severity}`}
                          >
                            {config.text}
                          </Badge>
                          <Badge variant="outline" data-testid="badge-alert-type">
                            {formatAlertType(alert.type)}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2 mb-2">
                          <User className="w-4 h-4 text-muted-foreground" />
                          <span className="font-medium text-card-foreground" data-testid="text-member-name">
                            {alert.memberName || "Unknown Member"}
                          </span>
                        </div>
                        <p className="text-sm text-card-foreground mb-2" data-testid="text-alert-message">
                          {alert.message}
                        </p>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span data-testid="text-alert-time">{formatTimeAgo(alert.createdAt)}</span>
                          </div>
                          {alert.status !== "open" && (
                            <div className="flex items-center space-x-1">
                              <CheckCircle className="w-3 h-3" />
                              <span className="capitalize">{alert.status}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {alert.status === "open" && (
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => acknowledgeAlert.mutate(alert.id)}
                          disabled={acknowledgeAlert.isPending}
                          data-testid="button-acknowledge-alert"
                        >
                          Acknowledge
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => resolveAlert.mutate({ alertId: alert.id })}
                          disabled={resolveAlert.isPending}
                          className={alert.severity === "high" ? "bg-red-600 hover:bg-red-700" : ""}
                          data-testid="button-resolve-alert"
                        >
                          Resolve
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
