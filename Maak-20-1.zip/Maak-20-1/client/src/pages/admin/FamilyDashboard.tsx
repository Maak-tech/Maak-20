import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Users, 
  Heart, 
  Activity, 
  AlertTriangle, 
  Calendar,
  Pill,
  TrendingUp,
  TrendingDown,
  Clock
} from 'lucide-react';

interface FamilyMember {
  id: string;
  fullName: string;
  email: string;
  lastVital?: {
    kind: string;
    value: number;
    measuredAt: string;
  };
  riskLevel: 'low' | 'medium' | 'high';
  alertCount: number;
}

interface FamilyStats {
  totalMembers: number;
  activeAlerts: number;
  medicationAdherence: number;
  recentEvents: number;
}

export default function FamilyDashboard() {
  const { t } = useTranslation();
  const [selectedMember, setSelectedMember] = useState<string | null>(null);

  // Fetch family members
  const { data: familyMembers = [], isLoading: membersLoading } = useQuery<FamilyMember[]>({
    queryKey: ['/api/admin/family-members'],
  });

  // Fetch family stats
  const { data: familyStats } = useQuery<FamilyStats>({
    queryKey: ['/api/admin/family-stats'],
  });

  // Fetch recent alerts
  const { data: recentAlerts = [] } = useQuery<any[]>({
    queryKey: ['/api/admin/alerts', { status: 'open', limit: 5 }],
  });

  const getRiskBadgeColor = (risk: string) => {
    switch (risk) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-green-500';
    }
  };

  const getVitalStatusIcon = (vital?: FamilyMember['lastVital']) => {
    if (!vital) return <Clock className="w-4 h-4 text-muted-foreground" />;
    
    // Simple logic for demo - in real app, this would be more sophisticated
    const isRecent = new Date(vital.measuredAt) > new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    if (vital.kind === 'heart_rate') {
      const isNormal = vital.value >= 60 && vital.value <= 100;
      return isNormal && isRecent ? 
        <Heart className="w-4 h-4 text-green-500" /> : 
        <Heart className="w-4 h-4 text-red-500" />;
    }
    
    return <Activity className="w-4 h-4 text-blue-500" />;
  };

  if (membersLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6" data-testid="page-family-dashboard">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground" data-testid="text-dashboard-title">
          {t('dashboard.familyTitle') || 'Family Health Dashboard'}
        </h1>
        <p className="text-muted-foreground">
          {t('dashboard.familySubtitle') || 'Monitor your family\'s health and wellbeing'}
        </p>
      </div>

      {/* Stats Overview */}
      {familyStats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="w-8 h-8 text-blue-500" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-muted-foreground">Family Members</p>
                  <p className="text-2xl font-bold">{familyStats.totalMembers}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <AlertTriangle className="w-8 h-8 text-red-500" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-muted-foreground">Active Alerts</p>
                  <p className="text-2xl font-bold">{familyStats.activeAlerts}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Pill className="w-8 h-8 text-green-500" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-muted-foreground">Med Adherence</p>
                  <p className="text-2xl font-bold">{familyStats.medicationAdherence}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Activity className="w-8 h-8 text-purple-500" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-muted-foreground">Recent Events</p>
                  <p className="text-2xl font-bold">{familyStats.recentEvents}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Family Members Grid */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                Family Members
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {familyMembers.map((member) => (
                  <Card key={member.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarFallback>
                              {member.fullName?.split(' ').map(n => n[0]).join('') || 'U'}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-semibold text-sm">{member.fullName || member.email}</h3>
                            <p className="text-xs text-muted-foreground">{member.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full ${getRiskBadgeColor(member.riskLevel)}`}></div>
                          {getVitalStatusIcon(member.lastVital)}
                        </div>
                      </div>
                      
                      {member.lastVital && (
                        <div className="mb-3 p-2 bg-muted/50 rounded text-xs">
                          <div className="flex justify-between">
                            <span>Last {member.lastVital.kind.replace('_', ' ')}</span>
                            <span className="font-medium">{member.lastVital.value}</span>
                          </div>
                          <div className="text-muted-foreground mt-1">
                            {new Date(member.lastVital.measuredAt).toLocaleDateString()}
                          </div>
                        </div>
                      )}
                      
                      {member.alertCount > 0 && (
                        <Badge variant="destructive" className="mb-3 text-xs">
                          {member.alertCount} Active Alert{member.alertCount > 1 ? 's' : ''}
                        </Badge>
                      )}
                      
                      <Link href={`/admin/member/${member.id}`}>
                        <Button variant="outline" size="sm" className="w-full" data-testid={`button-view-member-${member.id}`}>
                          View Details
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Alerts */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <AlertTriangle className="w-5 h-5 mr-2" />
                  Recent Alerts
                </div>
                <Link href="/admin/alerts">
                  <Button variant="ghost" size="sm">View All</Button>
                </Link>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentAlerts.length === 0 ? (
                <p className="text-muted-foreground text-sm text-center py-4">
                  No recent alerts
                </p>
              ) : (
                recentAlerts.map((alert: any) => (
                  <div key={alert.id} className="flex items-start space-x-3 p-3 bg-muted/50 rounded">
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      alert.severity === 'high' ? 'bg-red-500' : 
                      alert.severity === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'
                    }`}></div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{alert.type.replace(/_/g, ' ')}</p>
                      <p className="text-xs text-muted-foreground">{alert.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(alert.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}