import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import VitalCard from "@/components/VitalCard";
import { 
  ArrowLeft, 
  Heart, 
  Droplets, 
  Activity, 
  Moon,
  TrendingUp,
  AlertTriangle,
  MessageCircle,
  Pill,
  Calendar
} from "lucide-react";
import { Link } from "wouter";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler);

export default function MemberDetail() {
  const [match] = useRoute("/admin/member/:id");
  const memberId = match?.id;

  // Fetch member details
  const { data: memberData, isLoading } = useQuery({
    queryKey: ["/api/admin/member", memberId, "overview"],
    enabled: !!memberId,
    queryFn: () => {
      // Mock data until backend integration
      return Promise.resolve({
        profile: {
          fullName: "Mohammed Hassan",
          dob: "1968-12-10",
          sex: "male",
          conditions: ["Hypertension", "Type 2 Diabetes"]
        },
        vitals: {
          heart_rate: [
            { value: "72", measuredAt: "2024-01-14T08:00:00Z" },
            { value: "78", measuredAt: "2024-01-14T12:00:00Z" },
            { value: "85", measuredAt: "2024-01-14T16:00:00Z" },
            { value: "92", measuredAt: "2024-01-14T20:00:00Z" },
            { value: "140", measuredAt: "2024-01-15T11:30:00Z" },
          ],
          spo2: [
            { value: "98", measuredAt: "2024-01-14T08:00:00Z" },
            { value: "97", measuredAt: "2024-01-14T12:00:00Z" },
            { value: "96", measuredAt: "2024-01-14T16:00:00Z" },
            { value: "94", measuredAt: "2024-01-14T20:00:00Z" },
            { value: "88", measuredAt: "2024-01-15T11:30:00Z" },
          ],
          bp_systolic: [
            { value: "135", measuredAt: "2024-01-14T08:00:00Z" },
            { value: "142", measuredAt: "2024-01-14T12:00:00Z" },
            { value: "148", measuredAt: "2024-01-14T16:00:00Z" },
            { value: "155", measuredAt: "2024-01-14T20:00:00Z" },
            { value: "165", measuredAt: "2024-01-15T11:30:00Z" },
          ]
        },
        alerts: [
          {
            id: "alert-1",
            type: "spo2_low",
            severity: "high",
            message: "SpO₂ dropped to 88%",
            createdAt: "2024-01-15T11:30:00Z",
            status: "open"
          },
          {
            id: "alert-2",
            type: "bp_high", 
            severity: "med",
            message: "Blood pressure elevated to 165/95",
            createdAt: "2024-01-15T11:30:00Z",
            status: "open"
          }
        ],
        medications: [
          {
            id: "med-1",
            name: "Lisinopril",
            dose: "10mg",
            instructions: "Take once daily with breakfast",
            critical: true
          },
          {
            id: "med-2",
            name: "Metformin", 
            dose: "500mg",
            instructions: "Take twice daily with meals",
            critical: false
          }
        ],
        adherenceRate: 85,
        recentConversations: [
          {
            id: "conv-1",
            message: "I'm feeling dizzy and short of breath",
            createdAt: "2024-01-15T11:25:00Z"
          }
        ]
      });
    }
  });

  if (isLoading || !memberData) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-64 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const { profile, vitals, alerts, medications, adherenceRate, recentConversations } = memberData;
  
  const calculateAge = (dob: string) => {
    return new Date().getFullYear() - new Date(dob).getFullYear();
  };

  const getLatestVital = (vitalType: string) => {
    return vitals[vitalType]?.[vitals[vitalType].length - 1];
  };

  const getVitalChartData = (vitalType: string) => {
    const data = vitals[vitalType] || [];
    return data.map((v: any) => parseFloat(v.value));
  };

  const getVitalStatus = (vitalType: string, value: number): "normal" | "warning" | "critical" => {
    switch (vitalType) {
      case "heart_rate":
        if (value >= 130) return "critical";
        if (value >= 100) return "warning";
        return "normal";
      case "spo2":
        if (value < 90) return "critical";
        if (value < 95) return "warning";
        return "normal";
      case "bp_systolic":
        if (value >= 180) return "critical";
        if (value >= 140) return "warning";
        return "normal";
      default:
        return "normal";
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMinutes = Math.floor((now.getTime() - time.getTime()) / 60000);
    
    if (diffMinutes < 60) return `${diffMinutes} min ago`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)} hours ago`;
    return `${Math.floor(diffMinutes / 1440)} days ago`;
  };

  const criticalAlerts = alerts.filter((alert: any) => alert.severity === "high");
  const openAlerts = alerts.filter((alert: any) => alert.status === "open");

  return (
    <div className="max-w-6xl mx-auto px-4 py-6" data-testid="page-member-detail">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <Link href="/admin/members">
            <Button variant="outline" size="sm" data-testid="button-back">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Members
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-foreground" data-testid="text-member-name">
              {profile.fullName}
            </h1>
            <p className="text-muted-foreground">
              {profile.sex === "male" ? "Male" : "Female"}, {calculateAge(profile.dob)} years old
            </p>
          </div>
        </div>
        {criticalAlerts.length > 0 && (
          <Badge variant="destructive" className="text-sm" data-testid="badge-critical-status">
            Critical Status - {criticalAlerts.length} Alert{criticalAlerts.length !== 1 ? 's' : ''}
          </Badge>
        )}
      </div>

      {/* Medical Conditions */}
      {profile.conditions && profile.conditions.length > 0 && (
        <Card className="mb-6" data-testid="card-conditions">
          <CardHeader>
            <CardTitle className="text-lg">Medical Conditions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {profile.conditions.map((condition: string, index: number) => (
                <Badge key={index} variant="outline" data-testid={`badge-condition-${index}`}>
                  {condition}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Current Vitals */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <VitalCard
          title="Heart Rate"
          value={getLatestVital("heart_rate")?.value || 0}
          unit="BPM"
          icon={<Heart className="w-4 h-4" />}
          status={getVitalStatus("heart_rate", parseFloat(getLatestVital("heart_rate")?.value || "0"))}
          lastUpdated={formatTimeAgo(getLatestVital("heart_rate")?.measuredAt || new Date().toISOString())}
          chartData={getVitalChartData("heart_rate")}
        />
        
        <VitalCard
          title="Blood Oxygen"
          value={getLatestVital("spo2")?.value || 0}
          unit="%"
          icon={<Droplets className="w-4 h-4" />}
          status={getVitalStatus("spo2", parseFloat(getLatestVital("spo2")?.value || "0"))}
          lastUpdated={formatTimeAgo(getLatestVital("spo2")?.measuredAt || new Date().toISOString())}
          chartData={getVitalChartData("spo2")}
        />
        
        <VitalCard
          title="Blood Pressure (Sys)"
          value={getLatestVital("bp_systolic")?.value || 0}
          unit="mmHg"
          icon={<Activity className="w-4 h-4" />}
          status={getVitalStatus("bp_systolic", parseFloat(getLatestVital("bp_systolic")?.value || "0"))}
          lastUpdated={formatTimeAgo(getLatestVital("bp_systolic")?.measuredAt || new Date().toISOString())}
          chartData={getVitalChartData("bp_systolic")}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Alerts */}
        <Card data-testid="card-active-alerts">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Active Alerts ({openAlerts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {openAlerts.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">No active alerts</p>
            ) : (
              <div className="space-y-3">
                {openAlerts.map((alert: any) => (
                  <div
                    key={alert.id}
                    className={`p-3 rounded-lg border ${
                      alert.severity === "high" ? "bg-red-50 border-red-200" :
                      alert.severity === "med" ? "bg-yellow-50 border-yellow-200" :
                      "bg-blue-50 border-blue-200"
                    }`}
                    data-testid={`alert-item-${alert.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-sm" data-testid="text-alert-message">
                          {alert.message}
                        </div>
                        <div className="text-xs text-muted-foreground" data-testid="text-alert-time">
                          {formatTimeAgo(alert.createdAt)}
                        </div>
                      </div>
                      <Badge 
                        variant="outline"
                        className={
                          alert.severity === "high" ? "bg-red-100 text-red-700" :
                          alert.severity === "med" ? "bg-yellow-100 text-yellow-700" :
                          "bg-blue-100 text-blue-700"
                        }
                      >
                        {alert.severity === "high" ? "Critical" :
                         alert.severity === "med" ? "Warning" : "Info"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Medication Adherence */}
        <Card data-testid="card-medication-adherence">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Pill className="w-5 h-5 mr-2" />
              Medication Adherence
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <div className="text-3xl font-bold" data-testid="text-adherence-rate">
                {adherenceRate}%
              </div>
              <div className={`px-3 py-1 rounded-full text-sm ${
                adherenceRate >= 80 ? "bg-green-100 text-green-700" :
                adherenceRate >= 60 ? "bg-yellow-100 text-yellow-700" :
                "bg-red-100 text-red-700"
              }`}>
                {adherenceRate >= 80 ? "Excellent" :
                 adherenceRate >= 60 ? "Good" : "Needs Attention"}
              </div>
            </div>
            <div className="space-y-2">
              {medications.map((medication: any) => (
                <div 
                  key={medication.id}
                  className="flex items-center justify-between p-2 bg-muted/50 rounded"
                  data-testid={`medication-${medication.id}`}
                >
                  <div>
                    <div className="font-medium text-sm" data-testid="text-medication-name">
                      {medication.name} {medication.dose}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {medication.instructions}
                    </div>
                  </div>
                  {medication.critical && (
                    <Badge variant="destructive" className="text-xs">Critical</Badge>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Conversations */}
        <Card data-testid="card-recent-conversations">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <MessageCircle className="w-5 h-5 mr-2" />
              Recent Conversations with Zeina
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentConversations.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No recent conversations
              </p>
            ) : (
              <div className="space-y-3">
                {recentConversations.map((conversation: any) => (
                  <div 
                    key={conversation.id}
                    className="p-3 bg-muted/50 rounded-lg"
                    data-testid={`conversation-${conversation.id}`}
                  >
                    <p className="text-sm" data-testid="text-conversation-message">
                      "{conversation.message}"
                    </p>
                    <div className="text-xs text-muted-foreground mt-2" data-testid="text-conversation-time">
                      {formatTimeAgo(conversation.createdAt)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
