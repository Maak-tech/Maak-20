import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { useRoute } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Heart, 
  Activity, 
  AlertTriangle, 
  Calendar,
  Pill,
  Users,
  TrendingUp,
  TrendingDown,
  Clock,
  Shield,
  Thermometer,
  Droplets,
  User
} from 'lucide-react';

interface MemberDetails {
  id: string;
  fullName: string;
  email: string;
  dob?: string;
  sex?: string;
  conditions?: string[];
}

interface FamilyHistory {
  id: string;
  relation: string;
  condition: string;
  ageOfOnset?: number;
  status: string;
  notes?: string;
}

interface DeviceEvent {
  id: string;
  event: string;
  occurredAt: string;
  meta?: any;
}

interface Vital {
  id: string;
  kind: string;
  value: number;
  unit?: string;
  measuredAt: string;
  source: string;
}

interface Alert {
  id: string;
  type: string;
  severity: string;
  message: string;
  createdAt: string;
  status: string;
}

export default function MemberDetailView() {
  const { t } = useTranslation();
  const [, params] = useRoute('/admin/member/:id');
  const memberId = params?.id;

  // Fetch member details
  const { data: member } = useQuery<MemberDetails>({
    queryKey: ['/api/admin/member', memberId],
    enabled: !!memberId,
  });

  // Fetch family history
  const { data: familyHistory = [] } = useQuery<FamilyHistory[]>({
    queryKey: ['/api/admin/member', memberId, 'family-history'],
    enabled: !!memberId,
  });

  // Fetch recent vitals
  const { data: vitals = [] } = useQuery<Vital[]>({
    queryKey: ['/api/admin/member', memberId, 'vitals'],
    enabled: !!memberId,
  });

  // Fetch device events
  const { data: deviceEvents = [] } = useQuery<DeviceEvent[]>({
    queryKey: ['/api/admin/member', memberId, 'device-events'],
    enabled: !!memberId,
  });

  // Fetch alerts
  const { data: alerts = [] } = useQuery<Alert[]>({
    queryKey: ['/api/admin/member', memberId, 'alerts'],
    enabled: !!memberId,
  });

  // Fetch medications
  const { data: medications = [] } = useQuery<any[]>({
    queryKey: ['/api/admin/member', memberId, 'medications'],
    enabled: !!memberId,
  });

  const getVitalIcon = (kind: string) => {
    switch (kind) {
      case 'heart_rate': return <Heart className="w-4 h-4" />;
      case 'spo2': return <Droplets className="w-4 h-4" />;
      case 'temperature': return <Thermometer className="w-4 h-4" />;
      default: return <Activity className="w-4 h-4" />;
    }
  };

  const getVitalColor = (kind: string, value: number) => {
    switch (kind) {
      case 'heart_rate':
        if (value < 60 || value > 100) return 'text-red-500';
        return 'text-green-500';
      case 'spo2':
        if (value < 95) return 'text-red-500';
        return 'text-green-500';
      case 'temperature':
        if (value > 37.5) return 'text-red-500';
        return 'text-green-500';
      default:
        return 'text-blue-500';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-blue-500';
    }
  };

  if (!member) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="h-64 bg-muted rounded-lg"></div>
            <div className="lg:col-span-2 h-64 bg-muted rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6" data-testid="page-member-detail">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center space-x-4 mb-4">
          <Avatar className="w-16 h-16">
            <AvatarFallback className="text-lg">
              {member.fullName?.split(' ').map(n => n[0]).join('') || 'U'}
            </AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{member.fullName || member.email}</h1>
            <p className="text-muted-foreground">{member.email}</p>
            {member.dob && (
              <p className="text-sm text-muted-foreground">
                Born: {new Date(member.dob).toLocaleDateString()}
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar - Member Info */}
        <div className="space-y-6">
          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {member.sex && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Gender:</span>
                  <span className="capitalize">{member.sex}</span>
                </div>
              )}
              {member.conditions && member.conditions.length > 0 && (
                <div>
                  <span className="text-muted-foreground mb-2 block">Conditions:</span>
                  <div className="space-y-1">
                    {member.conditions.map((condition, index) => (
                      <Badge key={index} variant="secondary" className="mr-1">
                        {condition}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Family History */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Family History</CardTitle>
            </CardHeader>
            <CardContent>
              {familyHistory.length === 0 ? (
                <p className="text-muted-foreground text-sm">No family history recorded</p>
              ) : (
                <div className="space-y-3">
                  {familyHistory.slice(0, 5).map((history) => (
                    <div key={history.id} className="border-l-2 border-muted pl-3">
                      <div className="font-medium text-sm">{history.condition}</div>
                      <div className="text-xs text-muted-foreground">
                        {history.relation} {history.ageOfOnset && `(age ${history.ageOfOnset})`}
                      </div>
                    </div>
                  ))}
                  {familyHistory.length > 5 && (
                    <p className="text-xs text-muted-foreground">
                      +{familyHistory.length - 5} more
                    </p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <Tabs defaultValue="vitals" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="vitals">Vitals</TabsTrigger>
              <TabsTrigger value="medications">Medications</TabsTrigger>
              <TabsTrigger value="alerts">Alerts</TabsTrigger>
              <TabsTrigger value="events">Events</TabsTrigger>
            </TabsList>

            {/* Vitals Tab */}
            <TabsContent value="vitals" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {vitals.slice(0, 6).map((vital) => (
                  <Card key={vital.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {getVitalIcon(vital.kind)}
                          <span className="text-sm font-medium capitalize">
                            {vital.kind.replace('_', ' ')}
                          </span>
                        </div>
                        <Badge variant="outline" className="text-xs">{vital.source}</Badge>
                      </div>
                      <div className={`text-2xl font-bold ${getVitalColor(vital.kind, vital.value)}`}>
                        {vital.value}{vital.unit && ` ${vital.unit}`}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(vital.measuredAt).toLocaleString()}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {vitals.length === 0 && (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Activity className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No vitals recorded yet</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Medications Tab */}
            <TabsContent value="medications" className="space-y-6">
              {medications.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Pill className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No medications recorded</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {medications.map((medication: any) => (
                    <Card key={medication.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold">{medication.name}</h3>
                          {medication.critical && (
                            <Badge variant="destructive" className="text-xs">Critical</Badge>
                          )}
                        </div>
                        {medication.dose && (
                          <p className="text-sm text-muted-foreground mb-2">
                            Dose: {medication.dose}
                          </p>
                        )}
                        {medication.instructions && (
                          <p className="text-xs text-muted-foreground">
                            {medication.instructions}
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Alerts Tab */}
            <TabsContent value="alerts" className="space-y-4">
              {alerts.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Shield className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No alerts for this member</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-3">
                  {alerts.map((alert) => (
                    <Card key={alert.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className={`w-3 h-3 rounded-full mt-1 ${getSeverityColor(alert.severity)}`}></div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <h3 className="font-medium">{alert.type.replace(/_/g, ' ')}</h3>
                              <Badge variant={alert.status === 'open' ? 'destructive' : 'secondary'}>
                                {alert.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">{alert.message}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(alert.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Device Events Tab */}
            <TabsContent value="events" className="space-y-4">
              {deviceEvents.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Clock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No device events recorded</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-3">
                  {deviceEvents.map((event) => (
                    <Card key={event.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium capitalize">{event.event.replace(/_/g, ' ')}</h3>
                          <Badge variant={event.event === 'fall_detected' ? 'destructive' : 'secondary'}>
                            {event.event}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {new Date(event.occurredAt).toLocaleString()}
                        </p>
                        {event.meta && (
                          <div className="mt-2 text-xs text-muted-foreground">
                            <pre className="whitespace-pre-wrap">
                              {JSON.stringify(event.meta, null, 2)}
                            </pre>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}