import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import MemberCard from "@/components/MemberCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, AlertTriangle, TrendingUp, Clock } from "lucide-react";

export default function Members() {
  const [, setLocation] = useLocation();

  // Fetch family members (mock family ID for now)
  const { data: members, isLoading } = useQuery({
    queryKey: ["/api/admin/family/mock-family-id/members"],
    queryFn: () => {
      // Mock data until backend integration
      return Promise.resolve([
        {
          id: "member-1",
          profile: {
            fullName: "Ahmed Hassan",
            dob: "1995-01-15",
            sex: "male"
          },
          latestVitals: {
            heart_rate: { value: "78", measuredAt: "2024-01-15T14:30:00Z" },
            spo2: { value: "98", measuredAt: "2024-01-15T14:25:00Z" }
          },
          openAlertsCount: 1,
          riskLevel: "warning",
          lastVitalTime: "2024-01-15T14:30:00Z"
        },
        {
          id: "member-2", 
          profile: {
            fullName: "Fatima Hassan",
            dob: "1998-05-22",
            sex: "female"
          },
          latestVitals: {
            heart_rate: { value: "72", measuredAt: "2024-01-15T14:15:00Z" },
            spo2: { value: "99", measuredAt: "2024-01-15T14:15:00Z" }
          },
          openAlertsCount: 0,
          riskLevel: "normal",
          lastVitalTime: "2024-01-15T14:15:00Z"
        },
        {
          id: "member-3",
          profile: {
            fullName: "Mohammed Hassan", 
            dob: "1968-12-10",
            sex: "male"
          },
          latestVitals: {
            heart_rate: { value: "140", measuredAt: "2024-01-15T11:30:00Z" },
            spo2: { value: "88", measuredAt: "2024-01-15T11:30:00Z" }
          },
          openAlertsCount: 2,
          riskLevel: "critical",
          lastVitalTime: "2024-01-15T11:30:00Z"
        }
      ]);
    }
  });

  const handleViewMemberDetails = (memberId: string) => {
    setLocation(`/admin/member/${memberId}`);
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded-lg"></div>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-64 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const membersList = members || [];
  const criticalCount = membersList.filter((m: any) => m.riskLevel === "critical").length;
  const warningCount = membersList.filter((m: any) => m.riskLevel === "warning").length;
  const totalAlerts = membersList.reduce((sum: number, m: any) => sum + m.openAlertsCount, 0);

  const calculateAge = (dob: string) => {
    return new Date().getFullYear() - new Date(dob).getFullYear();
  };

  const formatLastVitalTime = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMinutes = Math.floor((now.getTime() - time.getTime()) / 60000);
    
    if (diffMinutes < 60) return `${diffMinutes} min ago`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)} hours ago`;
    return `${Math.floor(diffMinutes / 1440)} days ago`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6" data-testid="page-admin-members">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-admin-title">
            Family Health Dashboard
          </h1>
          <p className="text-muted-foreground">Monitor your family members' health status</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge 
            variant="destructive" 
            className="bg-red-100 text-red-700"
            data-testid="badge-active-alerts"
          >
            {totalAlerts} Active Alerts
          </Badge>
          <Button 
            onClick={() => setLocation("/admin/alerts")}
            data-testid="button-view-all-alerts"
          >
            View All Alerts
          </Button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card data-testid="card-total-members">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-primary" />
              <div>
                <div className="text-2xl font-bold" data-testid="text-total-members">
                  {membersList.length}
                </div>
                <div className="text-sm text-muted-foreground">Family Members</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-critical-members">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <div>
                <div className="text-2xl font-bold text-red-600" data-testid="text-critical-count">
                  {criticalCount}
                </div>
                <div className="text-sm text-muted-foreground">Critical Status</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-warning-members">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-yellow-600" />
              <div>
                <div className="text-2xl font-bold text-yellow-600" data-testid="text-warning-count">
                  {warningCount}
                </div>
                <div className="text-sm text-muted-foreground">Needs Attention</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-total-alerts">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-primary" />
              <div>
                <div className="text-2xl font-bold" data-testid="text-total-alerts">
                  {totalAlerts}
                </div>
                <div className="text-sm text-muted-foreground">Open Alerts</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Family Members Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {membersList.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <Users className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-lg font-medium text-muted-foreground mb-2">
              No family members found
            </h3>
            <p className="text-muted-foreground">
              Add family members to start monitoring their health
            </p>
          </div>
        ) : (
          membersList.map((member: any) => (
            <MemberCard
              key={member.id}
              id={member.id}
              name={member.profile?.fullName || "Unknown Member"}
              role={member.profile?.sex === "male" ? "Son" : "Daughter"}
              age={calculateAge(member.profile?.dob || "1990-01-01")}
              lastVitalTime={formatLastVitalTime(member.lastVitalTime)}
              riskLevel={member.riskLevel}
              vitals={{
                heartRate: member.latestVitals?.heart_rate ? 
                  parseInt(member.latestVitals.heart_rate.value) : undefined,
                spo2: member.latestVitals?.spo2 ? 
                  parseInt(member.latestVitals.spo2.value) : undefined,
              }}
              onViewDetails={handleViewMemberDetails}
            />
          ))
        )}
      </div>
    </div>
  );
}
