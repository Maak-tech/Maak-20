import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from 'react-i18next';
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { VoiceChat, useSpeechSynthesis } from "@/components/VoiceChat";
import { MessageCircle, Send, ThumbsUp, Heart, Smile, MoreHorizontal, Mic, Bot } from "lucide-react";
import { cn } from "@/lib/utils";

interface Message {
  id: string;
  direction: "inbound" | "outbound";
  message: string;
  createdAt: string;
  meta?: any;
}

export default function Chat() {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [showReactions, setShowReactions] = useState<string | null>(null);
  const [typingTimeout, setTypingTimeout] = useState<NodeJS.Timeout | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { speak } = useSpeechSynthesis();

  // Fetch conversations
  const { data: conversations, isLoading } = useQuery({
    queryKey: ["/api/me/conversations"],
    refetchInterval: 5000, // Refresh every 5 seconds for new messages
  });

  // Send message mutation
  const sendMessage = useMutation({
    mutationFn: async (messageText: string) => {
      setIsTyping(true); // Show typing indicator
      return apiRequest("POST", "/api/me/conversations", {
        message: messageText,
        language: i18n.language
      });
    },
    onSuccess: (data: any) => {
      setIsTyping(false); // Hide typing indicator
      queryClient.invalidateQueries({ queryKey: ["/api/me/conversations"] });
      
      // Invalidate dashboard data for real-time updates
      queryClient.invalidateQueries({ queryKey: ["/api/me/vitals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/symptoms"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/medications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/me/alerts"] });
      
      setMessage("");
      
      // Show specific success message based on what was extracted
      if (data.extraction?.vitals && Object.keys(data.extraction.vitals).length > 0) {
        toast({ 
          title: t('chat.dataExtracted') || "Health data extracted and saved automatically",
          description: `Updated: ${Object.keys(data.extraction.vitals).join(', ')}`
        });
      } else {
        toast({ title: t('chat.messageSent') || "Message sent to Zeina" });
      }
      
      // Auto-speak Zeina's response if available
      if (data && data.zeinaResponse?.message) {
        setTimeout(() => speak(data.zeinaResponse.message), 1000);
      }
    },
    onError: (error: any) => {
      setIsTyping(false); // Hide typing indicator on error
      toast({ title: t('chat.sendError') || "Failed to send message", variant: "destructive" });
    },
  });

  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversations]);

  const handleSendMessage = () => {
    if (!message.trim()) return;
    sendMessage.mutate(message.trim());
  };

  const handleQuickSuggestion = (suggestion: string) => {
    setMessage(suggestion);
  };

  const handleVoiceMessage = (voiceText: string) => {
    if (voiceText.trim()) {
      sendMessage.mutate(voiceText.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Handle typing indicator for user
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    
    // Clear existing timeout
    if (typingTimeout) {
      clearTimeout(typingTimeout);
    }
    
    // Set new timeout to simulate typing indicator
    const newTimeout = setTimeout(() => {
      // In a real app, this would send typing status to server
    }, 1000);
    
    setTypingTimeout(newTimeout);
  };

  // Handle message reactions
  const handleReaction = (messageId: string, reaction: string) => {
    toast({ title: `Reacted with ${reaction}` });
    setShowReactions(null);
  };

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (typingTimeout) {
        clearTimeout(typingTimeout);
      }
    };
  }, [typingTimeout]);

  // Debug logging\n  console.log('Conversations data:', conversations);\n  \n  const messages: Message[] = Array.isArray(conversations) ? conversations : [];\n  console.log('Processed messages:', messages.length);
  const sortedMessages = messages.sort((a, b) => 
    new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="h-96 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6" data-testid="page-chat">
      {/* Chat Header */}
      <Card className="rounded-b-none">
        <CardHeader className="pb-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-card-foreground" data-testid="text-chat-title">
                {t('chat.title')}
              </h1>
              <p className="text-sm text-muted-foreground">{t('chat.subtitle')}</p>
            </div>
            <div className="ml-auto flex items-center space-x-2">
              <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                {isTyping ? 'Typing...' : (t('chat.online') || 'Online')}
              </Badge>
              <Button variant="ghost" size="icon" className="w-8 h-8">
                <Mic className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Chat Messages */}
      <Card className="rounded-none border-t-0 border-b-0">
        <CardContent className="p-6 h-96 overflow-y-auto space-y-4" data-testid="chat-messages">
          {sortedMessages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Ask Zeina anything about your health</p>
                <p className="text-sm">Your personal AI health assistant is here to help</p>
              </div>
            </div>
          ) : (
            sortedMessages.map((msg) => (
              <div
                key={msg.id}
                className={`group flex items-start space-x-3 ${
                  msg.direction === "inbound" ? "justify-end" : ""
                }`}
                data-testid={`message-${msg.direction}`}
              >
                {msg.direction === "outbound" && (
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                )}
                
                <div className={`relative max-w-md ${
                  msg.direction === "inbound" ? "ml-auto" : ""
                }`}>
                  <div
                    className={`p-4 rounded-2xl transition-all duration-200 hover:shadow-md ${
                      msg.direction === "inbound"
                        ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-br-md"
                        : "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-bl-md"
                    }`}
                  >
                    <p className="text-sm leading-relaxed" data-testid="text-message-content">
                      {msg.message}
                    </p>
                    <div className={`text-xs mt-2 flex items-center justify-between ${
                      msg.direction === "inbound" ? "text-blue-100" : "text-muted-foreground"
                    }`}>
                      <span>{new Date(msg.createdAt).toLocaleTimeString()}</span>
                      {msg.direction === "inbound" && (
                        <span className="text-xs opacity-60">✓✓</span>
                      )}
                    </div>
                  </div>
                  
                  {/* Message Actions */}
                  <div className={`absolute top-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ${
                    msg.direction === "inbound" ? "-left-12" : "-right-12"
                  }`}>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-8 h-8 hover:bg-gray-100 dark:hover:bg-gray-800"
                      onClick={() => setShowReactions(showReactions === msg.id ? null : msg.id)}
                    >
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  {/* Reaction Menu */}
                  {showReactions === msg.id && (
                    <div className={`absolute top-12 z-10 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg p-2 flex space-x-1 ${
                      msg.direction === "inbound" ? "right-0" : "left-0"
                    }`}>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 hover:bg-blue-50 dark:hover:bg-blue-900"
                        onClick={() => handleReaction(msg.id, '👍')}
                      >
                        👍
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 hover:bg-red-50 dark:hover:bg-red-900"
                        onClick={() => handleReaction(msg.id, '❤️')}
                      >
                        ❤️
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 hover:bg-yellow-50 dark:hover:bg-yellow-900"
                        onClick={() => handleReaction(msg.id, '😊')}
                      >
                        😊
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 hover:bg-purple-50 dark:hover:bg-purple-900"
                        onClick={() => handleReaction(msg.id, '🙏')}
                      >
                        🙏
                      </Button>
                    </div>
                  )}
                </div>

                {msg.direction === "inbound" && (
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
                    <span className="text-white text-sm font-semibold">U</span>
                  </div>
                )}
              </div>
            ))
          )}
          
          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-start space-x-3 animate-fade-in">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl rounded-bl-md p-4 max-w-md">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </CardContent>
      </Card>

      {/* Voice Chat */}
      <div className="mb-4">
        <VoiceChat 
          onMessageReceived={handleVoiceMessage}
          disabled={sendMessage.isPending}
        />
      </div>

      {/* Chat Input */}
      <Card className="rounded-t-none border-t-0">
        <CardContent className="p-6">
          <div className="flex items-end space-x-4">
            <div className="flex-1">
              <Textarea
                placeholder={t('chat.typeMessage') || "Type your message to Zeina..."}
                value={message}
                onChange={handleInputChange}
                className="resize-none border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 rounded-xl"
                rows={3}
                onKeyDown={handleKeyPress}
                data-testid="input-message"
              />
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={!message.trim() || sendMessage.isPending}
              className="flex items-center space-x-2"
              data-testid="button-send-message"
            >
              <span>{t('chat.send')}</span>
              <Send className="w-4 h-4" />
            </Button>
          </div>

          {/* Quick Suggestions */}
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickSuggestion(t('chat.suggestions.howFeeling'))}
              data-testid="button-suggestion-feeling"
            >
              {t('chat.suggestions.howFeeling')}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickSuggestion(t('chat.suggestions.symptoms'))}
              data-testid="button-suggestion-symptoms"
            >
              {t('chat.suggestions.symptoms')}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickSuggestion(t('chat.suggestions.medication'))}
              data-testid="button-suggestion-medication"
            >
              {t('chat.suggestions.medication')}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickSuggestion(t('chat.suggestions.howDoing'))}
              data-testid="button-suggestion-status"
            >
              {t('chat.suggestions.howDoing')}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
