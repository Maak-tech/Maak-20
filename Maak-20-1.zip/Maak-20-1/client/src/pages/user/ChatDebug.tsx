import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";

export default function ChatDebug() {
  const [testResult, setTestResult] = useState<any>(null);

  // Test the API directly
  const testAPI = async () => {
    try {
      console.log("Testing conversations API...");
      
      const response = await fetch("/api/me/conversations", {
        method: "GET",
        headers: {
          "Authorization": "Bearer mock"
        }
      });

      console.log("Response status:", response.status);
      console.log("Response headers:", Object.fromEntries(response.headers));

      if (!response.ok) {
        const errorText = await response.text();
        console.error("API Error:", response.status, errorText);
        setTestResult({ error: `${response.status}: ${errorText}` });
        return;
      }

      const data = await response.json();
      console.log("Raw API Response:", data);
      console.log("Is array?", Array.isArray(data));
      console.log("Length:", data?.length);
      
      setTestResult({
        success: true,
        data,
        isArray: Array.isArray(data),
        length: data?.length,
        firstItem: data?.[0]
      });
      
    } catch (error) {
      console.error("API Test failed:", error);
      setTestResult({ error: error.message });
    }
  };

  // Test with React Query
  const { data: conversations, isLoading, error } = useQuery({
    queryKey: ["/api/me/conversations"],
    enabled: false // Don't auto-fetch
  });

  const testReactQuery = async () => {
    const queryClient = (window as any).queryClient;
    if (queryClient) {
      const result = await queryClient.fetchQuery({
        queryKey: ["/api/me/conversations"]
      });
      console.log("React Query result:", result);
      setTestResult({ reactQuery: result });
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Chat Debug Page</h1>
      
      <div className="space-y-4">
        <Button onClick={testAPI}>Test API Directly</Button>
        <Button onClick={testReactQuery}>Test React Query</Button>
        
        <div className="bg-gray-100 p-4 rounded">
          <h3 className="font-semibold mb-2">Test Results:</h3>
          <pre className="text-sm overflow-auto">
            {JSON.stringify(testResult, null, 2)}
          </pre>
        </div>

        <div className="bg-blue-100 p-4 rounded">
          <h3 className="font-semibold mb-2">React Query State:</h3>
          <p>Is Loading: {isLoading.toString()}</p>
          <p>Error: {error?.toString()}</p>
          <p>Data: {JSON.stringify(conversations)}</p>
        </div>
      </div>
    </div>
  );
}