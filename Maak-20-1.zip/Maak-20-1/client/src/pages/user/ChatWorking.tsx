import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from 'react-i18next';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { MessageCircle, Send, Bot } from "lucide-react";

interface Message {
  id: string;
  direction: "inbound" | "outbound";
  message: string;
  createdAt: string;
  meta?: any;
}

export default function ChatWorking() {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch conversations
  const { data: conversations, isLoading } = useQuery({
    queryKey: ["/api/me/conversations"],
    refetchInterval: 3000,
  });

  // Debug what we're getting
  console.log('Raw conversations data:', conversations);

  // Send message mutation 
  const sendMessage = useMutation({
    mutationFn: async (messageText: string) => {
      setIsTyping(true);
      
      const response = await fetch("/api/me/conversations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer mock"
        },
        body: JSON.stringify({
          message: messageText,
          language: i18n.language || "en"
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${await response.text()}`);
      }

      return await response.json();
    },
    onSuccess: (data) => {
      setIsTyping(false);
      console.log('Message sent successfully:', data);
      queryClient.invalidateQueries({ queryKey: ["/api/me/conversations"] });
      setMessage("");
      
      toast({
        title: "Message sent!",
        description: "Zeina will respond shortly"
      });
    },
    onError: (error: any) => {
      setIsTyping(false);
      console.error('Send error:', error);
      toast({
        title: "Failed to send message",
        description: error?.message || "Please try again",
        variant: "destructive"
      });
    }
  });

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversations]);

  const handleSendMessage = () => {
    if (!message.trim()) return;
    console.log('Sending:', message.trim());
    sendMessage.mutate(message.trim());
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const messages: Message[] = Array.isArray(conversations) ? conversations : [];
  const sortedMessages = messages.sort((a, b) => 
    new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  console.log('Displaying messages:', sortedMessages.length);

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="h-96 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      {/* Chat Header */}
      <Card className="rounded-b-none">
        <CardHeader className="pb-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold">Chat with Zeina</h1>
              <p className="text-sm text-muted-foreground">Your AI health assistant</p>
            </div>
            <div className="ml-auto">
              <Badge variant="secondary" className="bg-green-100 text-green-700">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                {isTyping ? 'Typing...' : 'Online'}
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Chat Messages */}
      <Card className="rounded-none border-t-0 border-b-0">
        <CardContent className="p-6 h-96 overflow-y-auto space-y-4">
          {sortedMessages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Ask Zeina anything about your health</p>
                <p className="text-sm">Your personal AI health assistant is here to help</p>
              </div>
            </div>
          ) : (
            sortedMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex items-start space-x-3 ${
                  msg.direction === "inbound" ? "justify-end" : ""
                }`}
              >
                {msg.direction === "outbound" && (
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                )}
                
                <div className={`max-w-md ${
                  msg.direction === "inbound" ? "ml-auto" : ""
                }`}>
                  <div
                    className={`p-4 rounded-2xl ${
                      msg.direction === "inbound"
                        ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-br-md"
                        : "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-bl-md"
                    }`}
                  >
                    <p className="text-sm leading-relaxed">
                      {msg.message}
                    </p>
                    <div className={`text-xs mt-2 ${
                      msg.direction === "inbound" ? "text-blue-100" : "text-muted-foreground"
                    }`}>
                      {new Date(msg.createdAt).toLocaleTimeString()}
                    </div>
                  </div>
                </div>

                {msg.direction === "inbound" && (
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-sm font-semibold">U</span>
                  </div>
                )}
              </div>
            ))
          )}
          
          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl rounded-bl-md p-4 max-w-md">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </CardContent>
      </Card>

      {/* Chat Input */}
      <Card className="rounded-t-none border-t-0">
        <CardContent className="p-6">
          <div className="flex items-end space-x-4">
            <div className="flex-1">
              <Textarea
                placeholder="Type your message to Zeina..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="resize-none"
                rows={3}
                onKeyDown={handleKeyPress}
                disabled={sendMessage.isPending}
              />
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={!message.trim() || sendMessage.isPending}
              className="flex items-center space-x-2"
            >
              <span>{sendMessage.isPending ? 'Sending...' : 'Send'}</span>
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}