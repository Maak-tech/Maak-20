import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import VitalCard from "@/components/VitalCard";
import AlertBanner from "@/components/AlertBanner";
import HealthInsights from "@/components/HealthInsights";
import SmartMedicationManager from "@/components/SmartMedicationManager";
import MoodTrackerSummary from "@/components/MoodTrackerSummary";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Heart, 
  Droplets, 
  Activity, 
  Moon, 
  MessageCircle, 
  Plus, 
  BookOpen,
  CheckCircle2,
  Clock,
  Brain
} from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

export default function Dashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [dismissedAlerts, setDismissedAlerts] = useState<string[]>([]);

  // Fetch user vitals with frequent updates for Zeina-extracted data
  const { data: vitals, isLoading: vitalsLoading } = useQuery({
    queryKey: ["/api/me/vitals"],
    refetchInterval: 5000, // Refresh every 5 seconds for live data from conversations
    staleTime: 1000, // Consider data stale after 1 second
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });
  
  // Fetch recent symptoms
  const { data: symptoms } = useQuery({
    queryKey: ["/api/me/symptoms"],
    refetchInterval: 15000,
  });

  // Fetch user alerts
  const { data: alerts, isLoading: alertsLoading } = useQuery({
    queryKey: ["/api/me/alerts"],
    select: (data) => (Array.isArray(data) ? data.filter((alert: any) => !dismissedAlerts.includes(alert.id)) : []),
  });

  // Fetch medications for today
  const { data: medicationData, isLoading: medicationsLoading } = useQuery({
    queryKey: ["/api/me/medications"],
  });

  // Mark medication as taken
  const markMedicationTaken = useMutation({
    mutationFn: async (medicationId: string) => {
      return apiRequest("POST", `/api/me/medications/${medicationId}/taken`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/medications"] });
      toast({ title: "Medication marked as taken" });
    },
    onError: () => {
      toast({ title: "Failed to mark medication", variant: "destructive" });
    },
  });

  const getVitalValue = (kind: string) => {
    return (vitals && typeof vitals === 'object' && kind in vitals && Array.isArray((vitals as any)[kind])) ? (vitals as any)[kind][0]?.value || 0 : 0;
  };

  const getVitalTime = (kind: string) => {
    const vital = (vitals && typeof vitals === 'object' && kind in vitals && Array.isArray((vitals as any)[kind])) ? (vitals as any)[kind][0] : null;
    if (!vital) return "No data";
    return new Date(vital.measuredAt).toLocaleString();
  };

  const getVitalChartData = (kind: string) => {
    return (vitals && typeof vitals === 'object' && kind in vitals && Array.isArray((vitals as any)[kind])) ? (vitals as any)[kind].slice(0, 7).reverse().map((v: any) => parseFloat(v.value)) : [];
  };

  const getVitalStatus = (kind: string, value: number): "normal" | "warning" | "critical" => {
    switch (kind) {
      case "heart_rate":
        if (value >= 130) return "critical";
        if (value >= 100) return "warning";
        return "normal";
      case "spo2":
        if (value < 90) return "critical";
        if (value < 95) return "warning";
        return "normal";
      case "bp_systolic":
        if (value >= 180) return "critical";
        if (value >= 140) return "warning";
        return "normal";
      case "sleep_score":
        if (value < 60) return "warning";
        return "normal";
      default:
        return "normal";
    }
  };

  const dismissAlert = (alertId: string) => {
    setDismissedAlerts(prev => [...prev, alertId]);
  };

  const openAlerts = alerts?.filter((alert: any) => alert.status === "open") || [];
  const medications = (medicationData && typeof medicationData === 'object' && 'medications' in medicationData && Array.isArray((medicationData as any).medications)) ? (medicationData as any).medications : [];
  const todayLogs = (medicationData && typeof medicationData === 'object' && 'todayLogs' in medicationData && Array.isArray((medicationData as any).todayLogs)) ? (medicationData as any).todayLogs : [];

  if (vitalsLoading || alertsLoading || medicationsLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-64 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6" data-testid="page-dashboard">
      {/* Header with Live Data Indicator */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="font-bold text-secondary-600 text-[28px]" data-testid="text-welcome">
              Welcome to your health dashboard
            </h1>
            <p className="text-muted-foreground">Monitor your health in real-time</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="live-indicator flex items-center space-x-2 bg-accent/10 text-accent px-3 py-1 rounded-full text-sm">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span>Live Data</span>
            </div>
            <Link href="/settings">
              <Button variant="outline" size="sm" data-testid="button-settings">
                Settings
              </Button>
            </Link>
          </div>
        </div>

        {/* Alert Banners */}
        {openAlerts.map((alert: any) => (
          <AlertBanner
            key={alert.id}
            type={alert.severity === "high" ? "critical" : "warning"}
            title={alert.type.replace(/_/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase())}
            message={alert.message}
            onDismiss={() => dismissAlert(alert.id)}
            className="mb-4"
          />
        ))}
      </div>

      {/* Health Insights */}
      <HealthInsights vitals={vitals || {}} symptoms={Array.isArray(symptoms) ? symptoms : []} medications={medications} />

      {/* Vital Signs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <VitalCard
          title="Heart Rate"
          value={getVitalValue("heart_rate")}
          unit="BPM"
          icon={<Heart className="w-4 h-4" />}
          status={getVitalStatus("heart_rate", getVitalValue("heart_rate"))}
          lastUpdated={getVitalTime("heart_rate")}
          chartData={getVitalChartData("heart_rate")}
        />
        
        <VitalCard
          title="Blood Oxygen"
          value={getVitalValue("spo2")}
          unit="%"
          icon={<Droplets className="w-4 h-4" />}
          status={getVitalStatus("spo2", getVitalValue("spo2"))}
          lastUpdated={getVitalTime("spo2")}
          chartData={getVitalChartData("spo2")}
        />
        
        <VitalCard
          title="Blood Pressure"
          value={`${getVitalValue("bp_systolic")}/${getVitalValue("bp_diastolic")}`}
          icon={<Activity className="w-4 h-4" />}
          status={getVitalStatus("bp_systolic", getVitalValue("bp_systolic"))}
          lastUpdated={getVitalTime("bp_systolic")}
          chartData={getVitalChartData("bp_systolic")}
        />
        
        <VitalCard
          title="Sleep Score"
          value={getVitalValue("sleep_score")}
          icon={<Moon className="w-4 h-4" />}
          status={getVitalStatus("sleep_score", getVitalValue("sleep_score"))}
          lastUpdated={getVitalTime("sleep_score")}
          chartData={getVitalChartData("sleep_score")}
        />
      </div>
      {/* Smart Medication Management */}
      <SmartMedicationManager 
        medications={medications} 
        medicationLogs={todayLogs} 
        onMedicationTaken={(medicationId) => markMedicationTaken.mutate(medicationId)}
      />
      
      {/* Recent Symptoms Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <span>Recent Symptoms</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {Array.isArray(symptoms) && symptoms.length > 0 ? (
            <div className="space-y-2">
              {symptoms.slice(0, 5).map((symptom: any, index: number) => (
                <div 
                  key={index} 
                  className="flex items-center justify-between p-3 bg-muted rounded cursor-pointer hover:bg-muted/80 transition-colors"
                  onClick={() => alert(`Symptom Details:\n\nCondition: ${symptom.label}\nSeverity: ${symptom.severity || 'Not specified'}/10\nOnset: ${symptom.onset ? new Date(symptom.onset).toLocaleString() : 'Not specified'}\nNotes: ${symptom.notes || 'No additional notes'}\nSource: ${symptom.source || 'Zeina'}`)}
                  data-testid={`symptom-item-${index}`}
                >
                  <span className="font-medium">{symptom.label}</span>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    {symptom.severity && <span>Severity: {symptom.severity}/10</span>}
                    <span>{new Date(symptom.onset || symptom.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">No recent symptoms recorded</p>
          )}
        </CardContent>
      </Card>

      {/* Mood Tracking Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="w-5 h-5" />
            <span>Recent Mood</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <MoodTrackerSummary />
        </CardContent>
      </Card>

      {/* Medical History Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="w-5 h-5" />
            <span>Medical History</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Recent Health Events</h4>
                {Array.isArray(symptoms) && symptoms.length > 0 ? (
                  <div className="space-y-2">
                    {symptoms.slice(0, 10).map((symptom: any, index: number) => (
                      <div key={index} className="text-sm border-l-2 border-blue-200 pl-3 py-1">
                        <div className="font-medium">{symptom.label}</div>
                        <div className="text-muted-foreground text-xs">
                          {new Date(symptom.onset || symptom.createdAt).toLocaleDateString()} 
                          {symptom.severity && ` • Severity: ${symptom.severity}/10`}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">No recent symptoms recorded</p>
                )}
              </div>
              
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Health Vitals Trends</h4>
                {vitals && Object.keys(vitals).length > 0 ? (
                  <div className="space-y-2">
                    {Object.entries(vitals).slice(0, 5).map(([vitalType, readings]: [string, any]) => {
                      const latestReading = Array.isArray(readings) && readings.length > 0 ? readings[0] : null;
                      return latestReading ? (
                        <div key={vitalType} className="text-sm border-l-2 border-green-200 pl-3 py-1">
                          <div className="font-medium capitalize">{vitalType.replace('_', ' ')}</div>
                          <div className="text-muted-foreground text-xs">
                            Latest: {latestReading.value} {latestReading.unit || ''} • {new Date(latestReading.measuredAt).toLocaleDateString()}
                          </div>
                        </div>
                      ) : null;
                    })}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">No recent vital signs recorded</p>
                )}
              </div>
            </div>
            
            <div className="pt-3 border-t">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-blue-600">
                    {Array.isArray(symptoms) ? symptoms.length : 0}
                  </div>
                  <div className="text-xs text-muted-foreground">Total Symptoms Tracked</div>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-green-600">
                    {vitals ? Object.values(vitals).reduce((sum: number, readings: any) => sum + (Array.isArray(readings) ? readings.length : 0), 0) : 0}
                  </div>
                  <div className="text-xs text-muted-foreground">Vital Measurements</div>
                </div>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-purple-600">
                    {medications?.length || 0}
                  </div>
                  <div className="text-xs text-muted-foreground">Active Medications</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link href="/chat">
          <Button 
            className="w-full p-6 h-auto text-left justify-start"
            data-testid="button-chat-zeina"
          >
            <div className="flex items-center space-x-3">
              <MessageCircle className="w-6 h-6" />
              <div>
                <div className="font-medium text-[#f0f1f2]">Chat with Zeina</div>
                <div className="text-sm opacity-80">Report symptoms or ask questions</div>
              </div>
            </div>
          </Button>
        </Link>
        
        <Link href="/log-symptom">
          <Button 
            variant="outline" 
            className="w-full p-6 h-auto text-left justify-start"
            data-testid="button-log-symptom"
          >
            <div className="flex items-center space-x-3">
              <Plus className="w-6 h-6" />
              <div>
                <div className="font-medium">Log Symptom</div>
                <div className="text-sm text-muted-foreground">Manually record symptoms</div>
              </div>
            </div>
          </Button>
        </Link>
        
        <Link href="/resources">
          <Button 
            variant="outline" 
            className="w-full p-6 h-auto text-left justify-start"
            data-testid="button-health-resources"
          >
            <div className="flex items-center space-x-3">
              <BookOpen className="w-6 h-6" />
              <div>
                <div className="font-medium">Health Resources</div>
                <div className="text-sm text-muted-foreground">Access educational content</div>
              </div>
            </div>
          </Button>
        </Link>
      </div>
    </div>
  );
}
