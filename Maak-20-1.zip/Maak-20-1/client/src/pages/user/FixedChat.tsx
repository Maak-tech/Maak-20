import VoiceInteractiveChat from "@/components/VoiceInteractiveChat";

export default function FixedChat() {
  return <VoiceInteractiveChat />;
}