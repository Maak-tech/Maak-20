import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import ManualSymptomEntry from '@/components/ManualSymptomEntry';

export default function LogSymptom() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Link href="/dashboard">
            <Button variant="ghost" className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Dashboard</span>
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Log Symptom</h1>
        </div>

        {/* Manual Symptom Entry Form */}
        <ManualSymptomEntry />

        {/* Information Card */}
        <div className="bg-white rounded-lg border p-6 shadow-sm">
          <h3 className="font-semibold text-lg mb-3">Why Track Symptoms?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-muted-foreground">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Pattern Recognition</h4>
              <p>Track patterns and triggers to better understand your health</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Better Care</h4>
              <p>Provide your healthcare provider with detailed symptom history</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Personalized Insights</h4>
              <p>Get tailored recommendations based on your specific symptoms</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Proactive Monitoring</h4>
              <p>Early detection and monitoring of health changes</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}