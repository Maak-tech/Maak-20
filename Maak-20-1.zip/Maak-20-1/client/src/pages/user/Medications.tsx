import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Pill, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  Plus,
  Calendar
} from "lucide-react";

export default function Medications() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch medications
  const { data: medicationData, isLoading } = useQuery({
    queryKey: ["/api/me/medications"],
  });

  // Mark medication as taken
  const markMedicationTaken = useMutation({
    mutationFn: async (medicationId: string) => {
      return apiRequest("POST", `/api/me/medications/${medicationId}/taken`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/medications"] });
      toast({ title: "Medication marked as taken" });
    },
    onError: () => {
      toast({ title: "Failed to mark medication", variant: "destructive" });
    },
  });

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-24 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const medications = medicationData?.medications || [];
  const todayLogs = medicationData?.todayLogs || [];

  // Calculate adherence rate
  const totalScheduled = todayLogs.length;
  const taken = todayLogs.filter((log: any) => log.status === 'taken').length;
  const adherenceRate = totalScheduled > 0 ? Math.round((taken / totalScheduled) * 100) : 0;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6" data-testid="page-medications">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-medications-title">
            Medications
          </h1>
          <p className="text-muted-foreground">Manage your daily medications and track adherence</p>
        </div>
        <Button data-testid="button-add-medication">
          <Plus className="w-4 h-4 mr-2" />
          Add Medication
        </Button>
      </div>

      {/* Adherence Overview */}
      <Card className="mb-6" data-testid="card-adherence">
        <CardHeader>
          <CardTitle className="text-lg">Today's Adherence</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="text-3xl font-bold text-foreground" data-testid="text-adherence-rate">
                {adherenceRate}%
              </div>
              <div>
                <div className="text-sm text-muted-foreground">
                  {taken} of {totalScheduled} medications taken
                </div>
                <div className={`text-sm font-medium ${
                  adherenceRate >= 80 ? 'text-green-600' : 
                  adherenceRate >= 60 ? 'text-yellow-600' : 'text-red-600'
                }`}>
                  {adherenceRate >= 80 ? 'Excellent adherence' :
                   adherenceRate >= 60 ? 'Good adherence' : 'Needs improvement'}
                </div>
              </div>
            </div>
            <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
              adherenceRate >= 80 ? 'bg-green-100 text-green-600' :
              adherenceRate >= 60 ? 'bg-yellow-100 text-yellow-600' : 'bg-red-100 text-red-600'
            }`}>
              {adherenceRate >= 80 ? <CheckCircle2 className="w-8 h-8" /> :
               adherenceRate >= 60 ? <Clock className="w-8 h-8" /> : 
               <AlertTriangle className="w-8 h-8" />}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Today's Schedule */}
      <Card className="mb-6" data-testid="card-todays-schedule">
        <CardHeader>
          <CardTitle className="text-lg flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            Today's Schedule
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {medications.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Pill className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No medications scheduled</p>
              <p className="text-sm">Add your first medication to get started</p>
            </div>
          ) : (
            medications.map((medication: any) => {
              const todayLog = todayLogs.find((log: any) => log.medicationId === medication.id);
              const isTaken = todayLog?.status === "taken";
              const isPending = todayLog?.status === "pending";
              const isMissed = todayLog?.status === "missed";
              
              return (
                <div
                  key={medication.id}
                  className={`flex items-center justify-between p-4 rounded-lg border ${
                    isTaken ? 'bg-green-50 border-green-200' :
                    isMissed ? 'bg-red-50 border-red-200' :
                    'bg-muted/50 border-border'
                  }`}
                  data-testid={`medication-item-${medication.id}`}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                      isTaken ? 'bg-green-100' :
                      isMissed ? 'bg-red-100' :
                      'bg-accent/20'
                    }`}>
                      {isTaken ? (
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                      ) : isMissed ? (
                        <AlertTriangle className="w-6 h-6 text-red-600" />
                      ) : (
                        <Pill className="w-6 h-6 text-accent" />
                      )}
                    </div>
                    <div>
                      <div className="font-medium text-card-foreground" data-testid="text-medication-name">
                        {medication.name}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {medication.dose} • {medication.instructions || "Take as prescribed"}
                      </div>
                      {medication.critical && (
                        <Badge variant="destructive" className="mt-1 text-xs">
                          Critical
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    {isTaken ? (
                      <Badge className="bg-green-100 text-green-700">
                        ✓ Taken at {todayLog.takenAt ? 
                          new Date(todayLog.takenAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 
                          'Unknown time'
                        }
                      </Badge>
                    ) : isMissed ? (
                      <Badge variant="destructive">
                        Missed
                      </Badge>
                    ) : (
                      <Button
                        onClick={() => markMedicationTaken.mutate(medication.id)}
                        disabled={markMedicationTaken.isPending}
                        data-testid="button-mark-taken"
                      >
                        Mark Taken
                      </Button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </CardContent>
      </Card>

      {/* All Medications */}
      <Card data-testid="card-all-medications">
        <CardHeader>
          <CardTitle className="text-lg">All Medications</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {medications.map((medication: any) => (
            <div
              key={medication.id}
              className="flex items-center justify-between p-4 border rounded-lg"
              data-testid={`medication-detail-${medication.id}`}
            >
              <div>
                <div className="font-medium text-card-foreground">
                  {medication.name} {medication.dose}
                </div>
                <div className="text-sm text-muted-foreground">
                  {medication.instructions || "No specific instructions"}
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  {medication.startDate && `Started: ${new Date(medication.startDate).toLocaleDateString()}`}
                  {medication.endDate && ` • Ends: ${new Date(medication.endDate).toLocaleDateString()}`}
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {medication.critical && (
                  <Badge variant="destructive">Critical</Badge>
                )}
                <Button variant="outline" size="sm" data-testid="button-edit-medication">
                  Edit
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
