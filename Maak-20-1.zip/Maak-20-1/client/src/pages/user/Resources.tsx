import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  BookOpen, 
  Heart, 
  Activity, 
  Pill, 
  Phone, 
  ExternalLink,
  Download,
  PlayCircle
} from "lucide-react";

const healthResources = [
  {
    id: 1,
    title: "Understanding Your Heart Rate",
    category: "Cardiovascular Health",
    type: "Article",
    duration: "5 min read",
    description: "Learn about normal heart rate ranges and when to be concerned about elevated readings.",
    icon: <Heart className="w-5 h-5" />,
    priority: "high"
  },
  {
    id: 2,
    title: "Blood Pressure Management",
    category: "Cardiovascular Health", 
    type: "Video Guide",
    duration: "12 min watch",
    description: "Essential tips for managing blood pressure through lifestyle changes and medication adherence.",
    icon: <Activity className="w-5 h-5" />,
    priority: "high"
  },
  {
    id: 3,
    title: "Medication Safety Guide",
    category: "Medication Management",
    type: "PDF Guide",
    duration: "15 pages",
    description: "Comprehensive guide on safe medication practices and avoiding drug interactions.",
    icon: <Pill className="w-5 h-5" />,
    priority: "medium"
  },
  {
    id: 4,
    title: "Emergency Response Plan",
    category: "Emergency Care",
    type: "Quick Reference",
    duration: "2 min read",
    description: "What to do in case of cardiac emergency or severe symptoms.",
    icon: <Phone className="w-5 h-5" />,
    priority: "high"
  },
  {
    id: 5,
    title: "Healthy Sleep Habits",
    category: "Wellness",
    type: "Article",
    duration: "7 min read", 
    description: "Improve your sleep quality with evidence-based strategies for better rest.",
    icon: <BookOpen className="w-5 h-5" />,
    priority: "medium"
  },
  {
    id: 6,
    title: "Symptom Tracking Journal",
    category: "Self-Monitoring",
    type: "Downloadable",
    duration: "Template",
    description: "Track your symptoms effectively with this structured journal template.",
    icon: <Download className="w-5 h-5" />,
    priority: "low"
  }
];

const emergencyContacts = [
  {
    name: "Emergency Services",
    number: "101",
    description: "For immediate medical emergencies"
  },
  {
    name: "Poison Control",
    number: "1-800-222-1222", 
    description: "For medication overdose or poisoning"
  },
  {
    name: "Your Doctor",
    number: "+970-2-XXX-XXXX",
    description: "Your primary healthcare provider"
  }
];

export default function Resources() {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-700";
      case "medium":
        return "bg-yellow-100 text-yellow-700";
      case "low":
        return "bg-green-100 text-green-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "Video Guide":
        return <PlayCircle className="w-4 h-4" />;
      case "PDF Guide":
      case "Downloadable":
        return <Download className="w-4 h-4" />;
      default:
        return <BookOpen className="w-4 h-4" />;
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6" data-testid="page-resources">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground" data-testid="text-resources-title">
          Health Resources
        </h1>
        <p className="text-muted-foreground">
          Educational materials and emergency information to help you manage your health
        </p>
      </div>

      {/* Emergency Contacts */}
      <Card className="mb-6" data-testid="card-emergency-contacts">
        <CardHeader>
          <CardTitle className="text-lg flex items-center text-red-600">
            <Phone className="w-5 h-5 mr-2" />
            Emergency Contacts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {emergencyContacts.map((contact, index) => (
              <div 
                key={index}
                className="p-4 border border-red-200 rounded-lg bg-red-50"
                data-testid={`emergency-contact-${index}`}
              >
                <div className="font-semibold text-red-900" data-testid="text-contact-name">
                  {contact.name}
                </div>
                <div className="text-lg font-bold text-red-700 my-1" data-testid="text-contact-number">
                  {contact.number}
                </div>
                <div className="text-sm text-red-600" data-testid="text-contact-description">
                  {contact.description}
                </div>
                <Button 
                  size="sm" 
                  className="mt-3 bg-red-600 hover:bg-red-700"
                  data-testid="button-call-emergency"
                >
                  <Phone className="w-4 h-4 mr-1" />
                  Call
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Health Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {healthResources.map((resource) => (
          <Card 
            key={resource.id}
            className="hover:shadow-lg transition-shadow"
            data-testid={`resource-card-${resource.id}`}
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                    {resource.icon}
                  </div>
                  <Badge variant="secondary" className={getPriorityColor(resource.priority)}>
                    {resource.priority}
                  </Badge>
                </div>
                <div className="flex items-center text-muted-foreground text-sm">
                  {getTypeIcon(resource.type)}
                  <span className="ml-1">{resource.type}</span>
                </div>
              </div>
              <CardTitle className="text-lg font-semibold mt-3" data-testid="text-resource-title">
                {resource.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Badge variant="outline" className="text-xs">
                  {resource.category}
                </Badge>
                <p className="text-sm text-muted-foreground" data-testid="text-resource-description">
                  {resource.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground" data-testid="text-resource-duration">
                    {resource.duration}
                  </span>
                  <Button 
                    size="sm"
                    data-testid="button-access-resource"
                  >
                    Access
                    <ExternalLink className="w-3 h-3 ml-1" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Additional Resources */}
      <Card className="mt-6" data-testid="card-additional-resources">
        <CardHeader>
          <CardTitle className="text-lg">Additional Resources</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div>
                <div className="font-medium" data-testid="text-additional-resource-title">
                  Ministry of Health - Palestine
                </div>
                <div className="text-sm text-muted-foreground">
                  Official health information and guidelines
                </div>
              </div>
              <Button variant="outline" size="sm" data-testid="button-visit-website">
                Visit Website
                <ExternalLink className="w-4 h-4 ml-1" />
              </Button>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div>
                <div className="font-medium">Health Helpline</div>
                <div className="text-sm text-muted-foreground">
                  24/7 health advice and support
                </div>
              </div>
              <Button variant="outline" size="sm">
                <Phone className="w-4 h-4 mr-1" />
                Call Now
              </Button>
            </div>

            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div>
                <div className="font-medium">Medication Information Database</div>
                <div className="text-sm text-muted-foreground">
                  Comprehensive drug information and interactions
                </div>
              </div>
              <Button variant="outline" size="sm">
                Search Medications
                <ExternalLink className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
