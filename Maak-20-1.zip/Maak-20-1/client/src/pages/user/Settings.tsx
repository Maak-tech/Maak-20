import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings as SettingsIcon, 
  User, 
  Bell, 
  Shield, 
  Globe, 
  Clock,
  Save
} from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDirty, setIsDirty] = useState(false);

  // Fetch current user settings
  const { data: userInfo, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
  });

  const [settings, setSettings] = useState({
    fullName: "",
    language: "ar",
    timezone: "Asia/Hebron",
    allowCheckins: true,
    allowMedReminders: true,
    shareVitalsWithAdmins: true,
    channels: ["in_app", "email"],
    quietHours: { start: "21:00", end: "07:00" }
  });

  // Update settings when data loads
  useState(() => {
    if (userInfo) {
      setSettings({
        fullName: userInfo.profile?.fullName || "",
        language: userInfo.prefs?.language || "ar",
        timezone: userInfo.prefs?.timezone || "Asia/Hebron",
        allowCheckins: userInfo.prefs?.allowCheckins ?? true,
        allowMedReminders: userInfo.prefs?.allowMedReminders ?? true,
        shareVitalsWithAdmins: userInfo.prefs?.shareVitalsWithAdmins ?? true,
        channels: userInfo.prefs?.channels || ["in_app", "email"],
        quietHours: userInfo.prefs?.quietHours || { start: "21:00", end: "07:00" }
      });
    }
  }, [userInfo]);

  // Save settings mutation
  const saveSettings = useMutation({
    mutationFn: async () => {
      // Update profile
      await apiRequest("PUT", "/api/auth/profile", {
        fullName: settings.fullName
      });
      
      // Update coaching preferences
      return apiRequest("PUT", "/api/auth/preferences", {
        language: settings.language,
        timezone: settings.timezone,
        allowCheckins: settings.allowCheckins,
        allowMedReminders: settings.allowMedReminders,
        shareVitalsWithAdmins: settings.shareVitalsWithAdmins,
        channels: settings.channels,
        quietHours: settings.quietHours
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      setIsDirty(false);
      toast({ title: "Settings saved successfully" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    setIsDirty(true);
  };

  const updateNestedSetting = (parent: string, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [parent]: { ...prev[parent as keyof typeof prev], [key]: value }
    }));
    setIsDirty(true);
  };

  const toggleChannel = (channel: string) => {
    const newChannels = settings.channels.includes(channel)
      ? settings.channels.filter(c => c !== channel)
      : [...settings.channels, channel];
    updateSetting("channels", newChannels);
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6" data-testid="page-settings">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center" data-testid="text-settings-title">
            <SettingsIcon className="w-6 h-6 mr-2" />
            Settings
          </h1>
          <p className="text-muted-foreground">Manage your account and preferences</p>
        </div>
        <Button 
          onClick={() => saveSettings.mutate()}
          disabled={!isDirty || saveSettings.isPending}
          data-testid="button-save-settings"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Changes
        </Button>
      </div>

      <div className="space-y-6">
        {/* Profile Settings */}
        <Card data-testid="card-profile-settings">
          <CardHeader>
            <CardTitle className="flex items-center">
              <User className="w-5 h-5 mr-2" />
              Profile Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                value={settings.fullName}
                onChange={(e) => updateSetting("fullName", e.target.value)}
                placeholder="Enter your full name"
                data-testid="input-full-name"
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                value={userInfo?.user?.email || ""}
                disabled
                className="bg-muted"
                data-testid="input-email"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Email cannot be changed. Contact support if needed.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Language & Regional Settings */}
        <Card data-testid="card-language-settings">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Globe className="w-5 h-5 mr-2" />
              Language & Regional Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="language">Language</Label>
              <Select 
                value={settings.language} 
                onValueChange={(value) => updateSetting("language", value)}
              >
                <SelectTrigger data-testid="select-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ar">العربية (Arabic)</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="timezone">Timezone</Label>
              <Select 
                value={settings.timezone} 
                onValueChange={(value) => updateSetting("timezone", value)}
              >
                <SelectTrigger data-testid="select-timezone">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Asia/Hebron">Asia/Hebron (Palestine)</SelectItem>
                  <SelectItem value="Asia/Gaza">Asia/Gaza (Palestine)</SelectItem>
                  <SelectItem value="Asia/Jerusalem">Asia/Jerusalem</SelectItem>
                  <SelectItem value="Europe/London">Europe/London</SelectItem>
                  <SelectItem value="America/New_York">America/New_York</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card data-testid="card-notification-settings">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Bell className="w-5 h-5 mr-2" />
              Notification Preferences
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="allowCheckins">Daily Check-ins</Label>
                <p className="text-sm text-muted-foreground">
                  Receive daily health check-in messages from Zeina
                </p>
              </div>
              <Switch
                id="allowCheckins"
                checked={settings.allowCheckins}
                onCheckedChange={(checked) => updateSetting("allowCheckins", checked)}
                data-testid="switch-allow-checkins"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="allowMedReminders">Medication Reminders</Label>
                <p className="text-sm text-muted-foreground">
                  Get reminders when it's time to take your medications
                </p>
              </div>
              <Switch
                id="allowMedReminders"
                checked={settings.allowMedReminders}
                onCheckedChange={(checked) => updateSetting("allowMedReminders", checked)}
                data-testid="switch-allow-med-reminders"
              />
            </div>

            <div>
              <Label>Notification Channels</Label>
              <div className="space-y-2 mt-2">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="channel-in-app"
                    checked={settings.channels.includes("in_app")}
                    onCheckedChange={() => toggleChannel("in_app")}
                    data-testid="switch-channel-in-app"
                  />
                  <Label htmlFor="channel-in-app">In-app notifications</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="channel-email"
                    checked={settings.channels.includes("email")}
                    onCheckedChange={() => toggleChannel("email")}
                    data-testid="switch-channel-email"
                  />
                  <Label htmlFor="channel-email">Email notifications</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="channel-sms"
                    checked={settings.channels.includes("sms")}
                    onCheckedChange={() => toggleChannel("sms")}
                    data-testid="switch-channel-sms"
                  />
                  <Label htmlFor="channel-sms">SMS notifications</Label>
                </div>
              </div>
            </div>

            <div>
              <Label className="flex items-center mb-3">
                <Clock className="w-4 h-4 mr-2" />
                Quiet Hours
              </Label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="quietStart">Start Time</Label>
                  <Input
                    id="quietStart"
                    type="time"
                    value={settings.quietHours.start}
                    onChange={(e) => updateNestedSetting("quietHours", "start", e.target.value)}
                    data-testid="input-quiet-start"
                  />
                </div>
                <div>
                  <Label htmlFor="quietEnd">End Time</Label>
                  <Input
                    id="quietEnd"
                    type="time"
                    value={settings.quietHours.end}
                    onChange={(e) => updateNestedSetting("quietHours", "end", e.target.value)}
                    data-testid="input-quiet-end"
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                No notifications will be sent during quiet hours
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Privacy Settings */}
        <Card data-testid="card-privacy-settings">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="w-5 h-5 mr-2" />
              Privacy & Sharing
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="shareVitalsWithAdmins">Share Vitals with Family Admins</Label>
                <p className="text-sm text-muted-foreground">
                  Allow family administrators to view your health vitals and alerts
                </p>
              </div>
              <Switch
                id="shareVitalsWithAdmins"
                checked={settings.shareVitalsWithAdmins}
                onCheckedChange={(checked) => updateSetting("shareVitalsWithAdmins", checked)}
                data-testid="switch-share-vitals"
              />
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        {isDirty && (
          <div className="sticky bottom-4 flex justify-center">
            <Button 
              onClick={() => saveSettings.mutate()}
              disabled={saveSettings.isPending}
              size="lg"
              className="shadow-lg"
              data-testid="button-save-floating"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
