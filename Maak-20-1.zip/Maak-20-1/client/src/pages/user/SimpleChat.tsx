import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export default function SimpleChat() {
  const [message, setMessage] = useState("");
  const [conversations, setConversations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Fetch conversations directly
  const fetchConversations = async () => {
    try {
      console.log("Fetching conversations...");
      const response = await fetch("/api/me/conversations", {
        headers: { "Authorization": "Bearer mock" }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const data = await response.json();
      console.log("Fetched data:", data);\n      console.log("Sample conversation:", data?.[0]);
      console.log("Data type:", typeof data);
      console.log("Is array:", Array.isArray(data));
      console.log("Length:", data?.length);
      
      setConversations(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Fetch error:", error);
    }
  };

  // Send message
  const sendMessage = async () => {
    if (!message.trim()) return;
    
    setLoading(true);
    try {
      console.log("Sending message:", message);
      
      const response = await fetch("/api/me/conversations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer mock"
        },
        body: JSON.stringify({
          message: message.trim(),
          language: "en"
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const result = await response.json();
      console.log("Send result:", result);
      
      setMessage("");
      // Refresh conversations after sending
      setTimeout(fetchConversations, 1000);
      
    } catch (error) {
      console.error("Send error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Load conversations on mount
  useEffect(() => {
    fetchConversations();
  }, []);

  const sortedMessages = conversations.sort((a, b) => 
    new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <h1 className="text-2xl font-bold">Simple Chat Test</h1>
      
      {/* Debug Info */}
      <div className="bg-gray-100 p-4 rounded">
        <h3 className="font-semibold">Debug Info:</h3>
        <p>Conversations count: {conversations.length}</p>
        <p>Raw data type: {typeof conversations}</p>
        <p>Is array: {Array.isArray(conversations).toString()}</p>
      </div>

      {/* Messages */}
      <div className="border rounded-lg p-4 h-96 overflow-y-auto bg-white">
        {sortedMessages.length === 0 ? (
          <p className="text-gray-500 text-center">No messages yet</p>
        ) : (
          sortedMessages.map((msg, index) => (
            <div key={msg.id || index} className={`mb-4 ${
              msg.direction === "inbound" ? "text-right" : "text-left"
            }`}>
              <div className={`inline-block p-3 rounded-lg max-w-md ${
                msg.direction === "inbound" 
                  ? "bg-blue-500 text-white" 
                  : "bg-gray-200"
              }`}>
                <p>{msg.message}</p>
                <small className="text-xs opacity-75">
                  {msg.direction} - {new Date(msg.createdAt).toLocaleTimeString()}
                </small>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Input */}
      <div className="flex space-x-2">
        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          className="flex-1"
          rows={2}
        />
        <Button 
          onClick={sendMessage} 
          disabled={loading || !message.trim()}
        >
          {loading ? "Sending..." : "Send"}
        </Button>
      </div>

      <Button onClick={fetchConversations} variant="outline">
        Refresh Conversations
      </Button>
    </div>
  );
}