import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export default function WorkingChat() {
  const [message, setMessage] = useState("");
  const [conversations, setConversations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(false);

  // Fetch conversations
  const fetchConversations = async () => {
    setFetching(true);
    try {
      const response = await fetch("/api/me/conversations", {
        headers: { "Authorization": "Bearer mock" }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log("🔄 Fetched conversations:", data);
        console.log("🔍 First conversation:", data[0]);
        console.log("📊 Data structure check:", {
          isArray: Array.isArray(data),
          length: data?.length,
          hasDirection: data[0]?.direction,
          hasMessage: data[0]?.message,
          hasCreatedAt: data[0]?.createdAt
        });
        
        if (Array.isArray(data)) {
          setConversations(data);
          console.log("✅ Set conversations:", data.length);
        } else {
          console.error("⚠️ Data is not an array:", data);
          setConversations([]);
        }
      } else {
        console.error("❌ Fetch failed:", response.status);
      }
    } catch (error) {
      console.error("❌ Fetch error:", error);
    } finally {
      setFetching(false);
    }
  };

  // Send message
  const sendMessage = async () => {
    if (!message.trim()) {
      console.log("⚠️ Empty message, not sending");
      return;
    }
    
    console.log("🚀 Starting to send message:", message.trim());
    setLoading(true);
    
    try {
      console.log("📤 Making API call...");
      
      const response = await fetch("/api/me/conversations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer mock"
        },
        body: JSON.stringify({
          message: message.trim(),
          language: "en"
        })
      });

      console.log("📡 Response status:", response.status);
      console.log("📡 Response ok:", response.ok);

      if (response.ok) {
        const result = await response.json();
        console.log("✅ Send result:", result);
        setMessage("");
        alert("Message sent! Check console for details.");
        
        // Wait a moment then refresh
        setTimeout(() => {
          console.log("🔄 Refreshing conversations...");
          fetchConversations();
        }, 3000);
      } else {
        const errorText = await response.text();
        console.error("❌ Send failed:", response.status, errorText);
        alert(`Send failed: ${response.status} - ${errorText}`);
      }
    } catch (error) {
      console.error("❌ Send error:", error);
      alert(`Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Load on mount
  useEffect(() => {
    fetchConversations();
    // Auto-refresh every 5 seconds
    const interval = setInterval(fetchConversations, 5000);
    return () => clearInterval(interval);
  }, []);

  // Sort conversations by time
  const sortedMessages = [...conversations].sort((a, b) => 
    new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-500 to-blue-500 text-white p-4">
          <h1 className="text-xl font-bold">💬 Chat with Zeina</h1>
          <p className="text-sm opacity-90">
            Total conversations: {conversations.length} 
            {fetching && " (refreshing...)"}
          </p>
        </div>

        {/* Messages */}
        <div className="h-96 overflow-y-auto p-4 space-y-4 bg-gray-50">
          {/* Emergency display - show ALL conversations */}
          {conversations.length === 0 ? (
            <div className="text-center text-gray-500 mt-20">
              <p>No messages yet. Say hello to Zeina!</p>
            </div>
          ) : (
            conversations
              .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
              .map((conv, index) => (
                <div key={conv.id || index} className="mb-4">
                  <div className={`p-3 rounded-lg max-w-md ${
                    conv.direction === "inbound" 
                      ? "bg-blue-500 text-white ml-auto" 
                      : "bg-white border border-gray-200 mr-auto shadow-sm"
                  }`}>
                    <p className="text-sm">{conv.message || "No message content"}</p>
                    <div className="text-xs opacity-70 mt-1">
                      <strong>{conv.direction === "inbound" ? "You" : "Zeina"}</strong> • {" "}
                      {conv.createdAt ? new Date(conv.createdAt).toLocaleTimeString() : "No timestamp"}
                    </div>
                  </div>
                </div>
              ))
          )}
        </div>

        {/* Input */}
        <div className="p-4 border-t bg-white">
          <div className="flex space-x-2">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message to Zeina..."
              className="flex-1"
              rows={2}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
            />
            <div className="flex flex-col space-y-2">
              <Button 
                onClick={sendMessage} 
                disabled={loading || !message.trim()}
                className="px-6"
              >
                {loading ? "..." : "Send"}
              </Button>
              <Button 
                onClick={fetchConversations} 
                variant="outline"
                size="sm"
                disabled={fetching}
              >
                {fetching ? "..." : "↻"}
              </Button>
            </div>
          </div>
        </div>

        {/* Debug info */}
        <div className="p-2 bg-gray-100 text-xs text-gray-600 border-t">
          <strong>Debug:</strong> 
          Array: {Array.isArray(conversations).toString()} | 
          Count: {conversations.length} | 
          Sample: {conversations[0]?.direction || 'none'}
        </div>
      </div>
    </div>
  );
}