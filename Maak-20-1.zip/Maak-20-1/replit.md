# Overview

Maak 2.0 is a comprehensive wellness platform built as a full-stack application with React frontend and Express backend. The platform serves both regular users who want to track their health vitals and communicate with an AI assistant called Zeina, and family administrators who need to monitor multiple family members' health data. The application integrates with external health devices (HealthKit, Fitbit) for automated data collection and includes an intelligent alert system for health monitoring.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for build tooling
- **Routing**: Wouter for client-side routing with separate user and admin interfaces
- **State Management**: TanStack Query for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library and Tailwind CSS for styling
- **Build System**: Vite with custom configuration for development and production builds

## Backend Architecture
- **Runtime**: Node.js with Express framework using TypeScript
- **API Design**: RESTful APIs organized by domain (auth, ingest, webhooks, admin, me)
- **Job Processing**: Custom job runner for scheduled tasks like medication reminders and health check-ins
- **Authentication**: Integration-ready for Supabase Auth with JWT token handling
- **Error Handling**: Centralized error middleware with structured error responses

## Data Storage
- **Database**: PostgreSQL via Neon serverless with Drizzle ORM for type-safe database operations
- **Schema Design**: Comprehensive health data schema including users, families, vitals, medications, alerts, and conversations
- **Migrations**: Drizzle Kit for database schema management and migrations
- **Data Access**: Repository pattern implementation in storage layer for data operations

## Health Data Integration
- **Vital Signs Processing**: Generic vitals ingestion endpoint supporting multiple data sources
- **Device Integration**: Webhook handlers for Fitbit subscriptions and HealthKit data ingestion
- **Alert System**: Real-time health monitoring with configurable alert rules for vital sign thresholds
- **Data Validation**: Zod schemas for runtime type checking and data validation

## AI and Natural Language Processing
- **Zeina AI Assistant**: OpenAI GPT-5 integration for health conversation analysis
- **Entity Extraction**: NLP processing to extract symptoms, medication actions, and pain scores from user messages
- **Multilingual Support**: Arabic and English language support with locale-aware responses

## Notification System
- **Multi-Channel**: In-app notifications with extensible architecture for email and SMS
- **Real-time Alerts**: Critical health alerts with immediate notification to users and family admins
- **Preference Management**: User-configurable notification preferences including quiet hours and channels

## Development and Deployment
- **Monorepo Structure**: Single repository with client, server, and shared code organization
- **Development Experience**: Replit-optimized development setup with hot reloading and error overlay
- **Environment Configuration**: Dotenv-based configuration management for database and API keys
- **Build Process**: Separate build processes for frontend (Vite) and backend (esbuild) with production optimization

# External Dependencies

## Database and Backend Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle ORM**: Type-safe database operations and schema management
- **Express.js**: Web application framework for API endpoints

## AI and Language Processing
- **OpenAI API**: GPT-5 model for Zeina AI assistant and natural language processing
- **Natural Language Understanding**: Entity extraction for health-related conversations

## Health Device Integrations
- **Fitbit API**: Webhook subscriptions for automated health data collection
- **HealthKit Integration**: iOS health data ingestion (implementation ready)
- **Generic Vitals API**: Flexible endpoint for any health monitoring device

## Frontend Libraries
- **React Ecosystem**: React 18, TanStack Query, Wouter routing
- **UI Framework**: Radix UI primitives with shadcn/ui components and Tailwind CSS
- **Charts and Visualization**: Chart.js integration for health data visualization
- **Form Handling**: React Hook Form with Zod validation

## Notification Services
- **SendGrid**: Email notification service (integration ready)
- **Twilio**: SMS notification service (integration ready)
- **Real-time Communication**: WebSocket support for in-app notifications

## Development Tools
- **TypeScript**: Type safety across the entire application stack
- **Vite**: Fast development server and optimized production builds
- **ESBuild**: Fast backend bundling for production deployment
- **Replit**: Development environment integration with cartographer and error overlay plugins