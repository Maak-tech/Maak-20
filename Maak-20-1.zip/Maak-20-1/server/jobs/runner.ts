import { storage } from "../storage";
import { notificationService } from "../lib/notify";
import { extractEntities } from "../lib/zeina";
import type { Job } from "@shared/schema";

export class JobRunner {
  private isRunning = false;
  private interval: NodeJS.Timeout | null = null;

  start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('Job runner started');
    
    // Run every minute
    this.interval = setInterval(() => {
      this.processDueJobs().catch(console.error);
    }, 60000);
    
    // Run immediately on start
    this.processDueJobs().catch(console.error);
  }

  stop(): void {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
    this.isRunning = false;
    console.log('Job runner stopped');
  }

  private async processDueJobs(): Promise<void> {
    const now = new Date();
    const dueJobs = await storage.getJobsDue(now);
    
    console.log(`Processing ${dueJobs.length} due jobs`);
    
    for (const job of dueJobs) {
      try {
        await this.executeJob(job);
        await storage.updateJobStatus(job.id, 'completed');
      } catch (error) {
        console.error(`Job ${job.id} failed:`, error);
        await storage.updateJobStatus(job.id, 'failed');
      }
    }
  }

  private async executeJob(job: Job): Promise<void> {
    switch (job.kind) {
      case 'daily_checkin':
        await this.handleDailyCheckin(job);
        break;
      case 'med_reminder':
        await this.handleMedReminder(job);
        break;
      case 'followup':
        await this.handleFollowup(job);
        break;
      case 'fitbit_fetch':
        await this.handleFitbitFetch(job);
        break;
      default:
        console.warn(`Unknown job type: ${job.kind}`);
    }
  }

  private async handleDailyCheckin(job: Job): Promise<void> {
    const userId = job.userId!;
    const prefs = await storage.getCoachingPrefs(userId);
    
    if (!prefs?.allowCheckins) return;
    
    const messages = [
      "Good morning! How are you feeling today?",
      "كيف حالك اليوم؟ أتمنى أن تكون بخير",
      "Time for your daily check-in. Any new symptoms to report?"
    ];
    
    const message = prefs.language === 'ar' ? messages[1] : messages[0];
    
    await storage.insertConversation({
      userId,
      direction: 'outbound',
      channel: 'in_app',
      message,
      meta: { type: 'daily_checkin' }
    });
    
    await notificationService.sendNotification(userId, message, prefs.channels);
  }

  private async handleMedReminder(job: Job): Promise<void> {
    const userId = job.userId!;
    const payload = job.payload as any;
    const prefs = await storage.getCoachingPrefs(userId);
    
    if (!prefs?.allowMedReminders) return;
    
    const message = prefs?.language === 'ar' 
      ? `تذكير: حان وقت تناول ${payload.medicationName}`
      : `Reminder: Time to take ${payload.medicationName}`;
    
    await storage.insertConversation({
      userId,
      direction: 'outbound', 
      channel: 'in_app',
      message,
      meta: { type: 'med_reminder', medicationId: payload.medicationId }
    });
    
    await notificationService.sendNotification(userId, message, prefs.channels);
  }

  private async handleFollowup(job: Job): Promise<void> {
    const userId = job.userId!;
    const payload = job.payload as any;
    
    await storage.insertConversation({
      userId,
      direction: 'outbound',
      channel: 'in_app', 
      message: payload.message,
      meta: { type: 'followup' }
    });
    
    const prefs = await storage.getCoachingPrefs(userId);
    await notificationService.sendNotification(userId, payload.message, prefs?.channels);
  }

  private async handleFitbitFetch(job: Job): Promise<void> {
    const userId = job.userId!;
    const payload = job.payload as any;
    
    try {
      // TODO: Implement Fitbit API integration
      console.log(`Fetching Fitbit data for user ${userId}`);
      
      // Mock data fetching - in real implementation would call Fitbit API
      // const fitbitData = await fetchFitbitData(payload.accessToken);
      // await this.processFitbitData(userId, fitbitData);
      
    } catch (error) {
      console.error('Fitbit fetch failed:', error);
      throw error;
    }
  }

  async scheduleJob(job: Partial<Job>): Promise<void> {
    await storage.insertJob({
      ...job,
      status: 'queued',
      runAt: job.runAt || new Date()
    });
  }

  async scheduleDailyCheckin(userId: string): Promise<void> {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(9, 0, 0, 0); // 9 AM
    
    await this.scheduleJob({
      userId,
      kind: 'daily_checkin',
      runAt: tomorrow,
      payload: {}
    });
  }

  async scheduleMedReminder(userId: string, medicationId: string, medicationName: string, scheduledTime: Date): Promise<void> {
    await this.scheduleJob({
      userId,
      kind: 'med_reminder',
      runAt: scheduledTime,
      payload: { medicationId, medicationName }
    });
  }

  async scheduleFollowup(userId: string, message: string, runAt: Date): Promise<void> {
    await this.scheduleJob({
      userId,
      kind: 'followup',
      runAt,
      payload: { message }
    });
  }
}

export const jobRunner = new JobRunner();

// Auto-start job runner in production
if (process.env.NODE_ENV === 'production') {
  jobRunner.start();
}
