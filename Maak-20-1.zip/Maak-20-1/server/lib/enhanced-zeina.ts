// Enhanced Emergency Detection and Mood Analysis for Zeina AI

const EMERGENCY_KEYWORDS = [
  // English - Critical Symptoms
  'emergency', 'urgent', 'help', 'crisis', 'immediate', 'severe', 'critical',
  'chest pain', 'heart attack', 'stroke', 'bleeding', 'unconscious',
  'breathing', 'choking', 'suicide', 'overdose', 'accident',
  'can\'t breathe', 'shortness of breath', 'severe headache', 'confusion',
  'severe pain', 'internal bleeding', 'seizure', 'paralysis',
  
  // Arabic - Critical Symptoms
  'طوارئ', 'عاجل', 'مساعدة', 'أزمة', 'فوري', 'شديد', 'حرج', 'حالة طوارئ',
  'ألم في الصدر', 'نوبة قلبية', 'سكتة دماغية', 'نزيف', 'فاقد الوعي',
  'تنفس', 'اختناق', 'انتحار', 'جرعة زائدة', 'حادث', 'لا أستطيع التنفس',
  'ضيق التنفس', 'صداع شديد', 'ارتباك', 'ألم شديد', 'نزيف داخلي',
  'نوبة صرع', 'شلل'
];

const CONCERN_KEYWORDS = [
  // English - Concerning symptoms
  'worried', 'concerned', 'unusual', 'worsening', 'getting worse',
  'persistent', 'recurring', 'constant', 'chronic', 'intense',
  'fever', 'high temperature', 'difficulty', 'weakness', 'fatigue',
  'dizzy', 'nausea', 'vomiting', 'blood', 'swelling',
  
  // Arabic - Concerning symptoms  
  'قلق', 'قلقان', 'مقلق', 'غير طبيعي', 'يزداد سوءًا', 'يتفاقم',
  'مستمر', 'متكرر', 'ثابت', 'مزمن', 'شديد', 'حمى', 'درجة حرارة عالية',
  'صعوبة', 'ضعف', 'إرهاق', 'دوخة', 'غثيان', 'قيء', 'دم', 'تورم'
];

// Enhanced emotion and mood detection
const MOOD_INDICATORS = {
  positive: ['happy', 'good', 'great', 'excellent', 'wonderful', 'fantastic', 'amazing',
           'سعيد', 'جيد', 'ممتاز', 'رائع', 'مذهل', 'عظيم'],
  negative: ['sad', 'depressed', 'down', 'low', 'terrible', 'awful', 'horrible',
           'حزين', 'مكتئب', 'منخفض', 'سيء', 'فظيع', 'مروع'],
  anxious: ['anxious', 'worried', 'nervous', 'stressed', 'tense', 'overwhelmed',
          'قلق', 'قلقان', 'متوتر', 'مضغوط', 'مرهق', 'غارق'],
  angry: ['angry', 'mad', 'furious', 'irritated', 'frustrated', 'annoyed',
         'غاضب', 'زعلان', 'محبط', 'منزعج', 'متضايق']
};

// Emergency Detection System
export function detectEmergency(message: string, context: any = {}) {
  const messageText = message.toLowerCase();
  
  let emergencyLevel = 0; // 0=normal, 1=concern, 2=urgent, 3=emergency
  let emergencyType = '';
  let recommendations = [];
  
  // Check for emergency keywords
  for (const keyword of EMERGENCY_KEYWORDS) {
    if (messageText.includes(keyword.toLowerCase())) {
      emergencyLevel = Math.max(emergencyLevel, 3);
      emergencyType = 'critical_symptoms';
      recommendations.push('Seek immediate medical attention');
      recommendations.push('Call emergency services if symptoms are severe');
      break;
    }
  }
  
  // Check for concerning symptoms
  if (emergencyLevel < 3) {
    for (const keyword of CONCERN_KEYWORDS) {
      if (messageText.includes(keyword.toLowerCase())) {
        emergencyLevel = Math.max(emergencyLevel, 1);
        emergencyType = 'concerning_symptoms';
        recommendations.push('Monitor symptoms closely');
        recommendations.push('Consider consulting your doctor if symptoms persist');
        break;
      }
    }
  }
  
  // Context-based risk assessment
  if (context.vitals) {
    const recentBP = context.vitals.find((v: any) => v.kind === 'bp_systolic');
    if (recentBP && parseInt(recentBP.value) > 180) {
      emergencyLevel = Math.max(emergencyLevel, 2);
      emergencyType = 'critical_vitals';
      recommendations.push('Blood pressure critically high - seek immediate medical care');
    }
  }
  
  if (context.symptoms) {
    const severeSymptoms = context.symptoms.filter((s: any) => s.severity >= 8);
    if (severeSymptoms.length > 0) {
      emergencyLevel = Math.max(emergencyLevel, 2);
      emergencyType = 'severe_symptoms';
      recommendations.push('Severe symptoms detected - urgent medical evaluation recommended');
    }
  }
  
  return {
    level: emergencyLevel,
    type: emergencyType,
    recommendations,
    requiresImmediateAlert: emergencyLevel >= 3,
    requiresFollowUp: emergencyLevel >= 2
  };
}

// Enhanced Mood Analysis
export function analyzeMood(message: string) {
  const messageText = message.toLowerCase();
  let moodScore = 5; // Default neutral (1-10 scale)
  let emotionalState = 'neutral';
  let confidence = 0;
  
  const moodScores = {
    positive: 0,
    negative: 0,
    anxious: 0,
    angry: 0
  };
  
  // Count mood indicators
  Object.entries(MOOD_INDICATORS).forEach(([mood, indicators]) => {
    indicators.forEach((indicator: string) => {
      if (messageText.includes(indicator.toLowerCase())) {
        moodScores[mood as keyof typeof moodScores] += 1;
        confidence += 0.2;
      }
    });
  });
  
  // Determine dominant mood
  const dominantMood = Object.entries(moodScores)
    .reduce((a, b) => moodScores[a[0] as keyof typeof moodScores] > moodScores[b[0] as keyof typeof moodScores] ? a : b)[0];
  
  if (moodScores[dominantMood as keyof typeof moodScores] > 0) {
    emotionalState = dominantMood;
    
    // Calculate mood score based on dominant emotion
    switch (dominantMood) {
      case 'positive':
        moodScore = 7 + Math.min(moodScores.positive, 3);
        break;
      case 'negative':
        moodScore = 3 - Math.min(moodScores.negative, 2);
        break;
      case 'anxious':
        moodScore = 4 - Math.min(moodScores.anxious, 2);
        break;
      case 'angry':
        moodScore = 3 - Math.min(moodScores.angry, 2);
        break;
    }
  }
  
  return {
    score: Math.max(1, Math.min(10, moodScore)),
    emotionalState,
    confidence: Math.min(1, confidence),
    indicators: moodScores
  };
}

// Health Memory System - tracks patterns and provides context
export function buildHealthMemory(userId: string, conversations: any[], vitals: any[], symptoms: any[]) {
  const memory = {
    healthPatterns: {},
    recentConcerns: [],
    improvementAreas: [],
    successfulInterventions: [],
    recurringTopics: []
  };
  
  // Analyze recent conversations for patterns
  const recentConversations = conversations.slice(0, 10);
  const topicCounts: Record<string, number> = {};
  
  recentConversations.forEach((conv: any) => {
    if (conv.meta?.extraction) {
      const extraction = conv.meta.extraction;
      
      // Track recurring topics
      if (extraction.symptoms) {
        extraction.symptoms.forEach((symptom: any) => {
          topicCounts[symptom.label] = (topicCounts[symptom.label] || 0) + 1;
        });
      }
      
      // Track medication discussions
      if (extraction.med_action) {
        const medTopic = `medication_${extraction.med_action.medication}`;
        topicCounts[medTopic] = (topicCounts[medTopic] || 0) + 1;
      }
    }
  });
  
  // Identify recurring topics (mentioned 3+ times)
  memory.recurringTopics = Object.entries(topicCounts)
    .filter(([_, count]) => count >= 3)
    .map(([topic, count]) => ({ topic, frequency: count }));
  
  // Analyze vital trends
  if (vitals.length >= 5) {
    const bpReadings = vitals.filter((v: any) => v.kind === 'bp_systolic').slice(0, 5);
    if (bpReadings.length >= 3) {
      const trend = bpReadings.map(v => parseInt(v.value));
      const isImproving = trend[0] < trend[trend.length - 1];
      
      if (isImproving) {
        memory.successfulInterventions.push('Blood pressure showing improvement');
      } else {
        memory.improvementAreas.push('Blood pressure management needs attention');
      }
    }
  }
  
  // Recent concerning patterns
  const recentSymptoms = symptoms.slice(0, 5);
  const severeSymptoms = recentSymptoms.filter((s: any) => s.severity >= 7);
  if (severeSymptoms.length > 0) {
    memory.recentConcerns.push(`${severeSymptoms.length} severe symptoms in recent conversations`);
  }
  
  return memory;
}

// Smart Health Goal Recommendations
export function generateGoalRecommendations(context: any, healthMemory: any) {
  const recommendations = [];
  
  // Based on recurring health topics
  if (healthMemory.recurringTopics) {
    healthMemory.recurringTopics.forEach((topic: any) => {
      if (topic.topic.includes('blood_pressure')) {
        recommendations.push({
          type: 'bp_management',
          title: 'Blood Pressure Control Goal',
          description: 'Reduce average blood pressure to healthy levels',
          targetValue: '120',
          unit: 'mmHg',
          category: 'cardiovascular',
          priority: 'high'
        });
      }
      
      if (topic.topic.includes('weight')) {
        recommendations.push({
          type: 'weight_management',
          title: 'Healthy Weight Goal',
          description: 'Achieve and maintain optimal weight',
          targetValue: null, // To be set by user
          unit: 'kg',
          category: 'nutrition',
          priority: 'medium'
        });
      }
      
      if (topic.topic.includes('medication')) {
        recommendations.push({
          type: 'medication_adherence',
          title: 'Medication Compliance',
          description: 'Take medications consistently as prescribed',
          targetValue: '95',
          unit: '%',
          category: 'medication',
          priority: 'high'
        });
      }
    });
  }
  
  // Based on vital trends
  if (context.vitals) {
    const exerciseVitals = context.vitals.filter((v: any) => v.kind === 'heart_rate' && v.source === 'exercise');
    if (exerciseVitals.length < 3) {
      recommendations.push({
        type: 'exercise_routine',
        title: 'Regular Exercise Goal',
        description: 'Establish consistent exercise routine',
        targetValue: '150',
        unit: 'minutes/week',
        category: 'fitness',
        priority: 'medium'
      });
    }
  }
  
  return recommendations.slice(0, 3); // Return top 3 recommendations
}