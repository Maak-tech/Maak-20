
interface LogEntry {
  level: 'info' | 'warn' | 'error' | 'debug';
  message: string;
  userId?: string;
  timestamp: Date;
  meta?: any;
}

class Logger {
  private logs: LogEntry[] = [];
  private maxLogs = 1000;

  log(level: LogEntry['level'], message: string, userId?: string, meta?: any) {
    const entry: LogEntry = {
      level,
      message,
      userId,
      timestamp: new Date(),
      meta
    };

    this.logs.push(entry);
    
    // Keep only recent logs
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs);
    }

    // Console output with better formatting
    const timestamp = entry.timestamp.toISOString();
    const userInfo = userId ? ` [${userId}]` : '';
    const metaInfo = meta ? ` ${JSON.stringify(meta)}` : '';
    
    console.log(`${timestamp} [${level.toUpperCase()}]${userInfo} ${message}${metaInfo}`);
  }

  info(message: string, userId?: string, meta?: any) {
    this.log('info', message, userId, meta);
  }

  warn(message: string, userId?: string, meta?: any) {
    this.log('warn', message, userId, meta);
  }

  error(message: string, userId?: string, meta?: any) {
    this.log('error', message, userId, meta);
  }

  debug(message: string, userId?: string, meta?: any) {
    this.log('debug', message, userId, meta);
  }

  getLogs(level?: string, userId?: string) {
    return this.logs.filter(log => {
      if (level && log.level !== level) return false;
      if (userId && log.userId !== userId) return false;
      return true;
    });
  }
}

export const logger = new Logger();
