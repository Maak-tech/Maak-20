import { storage } from "../storage";
import { logger } from "./logger";

const MOCK_USER_ID = 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11';
const MOCK_AUTH_ID = 'b1ffcd99-8d1c-4f99-9c7e-7cc0ce481b22';

export async function createMockUserIfNotExists() {
  try {
    // Check if user already exists
    const existingUser = await storage.getUserByAuthId("b1ffcd99-8d1c-4f99-9c7e-7cc0ce481b22");

    if (existingUser) {
      logger.info('Mock user already exists', existingUser.id);
      return existingUser;
    }

    const mockUser = await storage.createUser({
      authId: "b1ffcd99-8d1c-4f99-9c7e-7cc0ce481b22",
      email: "demo@maak.health",
      role: "user"
    });

    logger.info('Mock user created', mockUser.id);

    // Create mock profile
    await storage.updateProfile(mockUser.id, {
      fullName: 'Demo User',
      dob: '1990-01-01',
      sex: 'male',
      conditions: ['diabetes', 'hypertension'],
      locale: 'ar'
    });

    // Create coaching preferences
    await storage.updateCoachingPrefs(mockUser.id, {
      allowCheckins: true,
      allowMedReminders: true,
      shareVitalsWithAdmins: true,
      language: 'ar',
      timezone: 'Asia/Hebron'
    });

    // Add some mock vitals
    const now = new Date();
    await storage.insertVitals([
      {
        userId: mockUser.id,
        kind: 'heart_rate',
        value: '75',
        unit: 'bpm',
        measuredAt: new Date(now.getTime() - 1000 * 60 * 60), // 1 hour ago
        source: 'device'
      },
      {
        userId: mockUser.id,
        kind: 'spo2',
        value: '98',
        unit: '%',
        measuredAt: new Date(now.getTime() - 1000 * 60 * 60), // 1 hour ago
        source: 'device'
      },
      {
        userId: mockUser.id,
        kind: 'temperature',
        value: '36.8',
        unit: '°C',
        measuredAt: new Date(now.getTime() - 1000 * 60 * 30), // 30 mins ago
        source: 'manual'
      }
    ]);

    // Add mock medications
    await storage.insertMedication({
      userId: mockUser.id,
      name: 'Metformin',
      dose: '500mg',
      startDate: '2024-01-01',
      instructions: 'Take with meals twice daily',
      critical: true
    });

    console.log('Mock user and data created successfully');
  } catch (error) {
    console.error('Error creating mock user:', error);
  }
}

export { MOCK_USER_ID };