import { storage } from '../storage';
// import { jobRunner } from './jobs'; // Jobs feature not yet implemented

export interface NotificationPreferences {
  enableProactiveCheckIns: boolean;
  checkInFrequency: 'daily' | 'weekly' | 'bi-weekly';
  quietHours: { start: string; end: string };
  severityThreshold: number; // 1-10
}

export class NotificationService {
  /**
   * Schedule proactive check-ins based on user health patterns
   */
  static async scheduleProactiveCheckIn(userId: string): Promise<void> {
    try {
      // Get user health context
      const recentVitals = await storage.getVitals(userId, { range: "7d" });
      const recentSymptoms = await storage.getSymptoms(userId, { range: "7d" });
      const moodEntries = await storage.getMoodEntries(userId, { range: "7d" });
      
      // Determine check-in priority based on health patterns
      let priority = 1; // Default low priority
      let delayHours = 24; // Default daily check-in
      
      // Increase priority if severe symptoms detected
      const severeSymptoms = recentSymptoms.filter(s => s.severity && s.severity >= 7);
      if (severeSymptoms.length > 0) {
        priority = 3; // High priority
        delayHours = 4; // Check in 4 hours
      }
      
      // Increase priority if mood is consistently low
      const lowMoodEntries = moodEntries.filter(m => m.moodScore <= 4);
      if (lowMoodEntries.length >= 3) {
        priority = Math.max(priority, 2); // Medium priority
        delayHours = Math.min(delayHours, 12); // Check in 12 hours
      }
      
      // Schedule the proactive check-in job
      const scheduledAt = new Date(Date.now() + delayHours * 60 * 60 * 1000);
      
      // TODO: Implement job scheduling when jobs system is ready
      // await jobRunner.scheduleJob({
      //   type: 'proactive_check_in',
      //   userId,
      //   scheduledAt,
      //   priority,
      //   payload: {
      //     reason: 'routine_check_in',
      //     context: {
      //       recentSymptoms: severeSymptoms.length,
      //       lowMoodDays: lowMoodEntries.length,
      //       vitalsConcerns: recentVitals.length > 0
      //     }
      //   }
      // });
      
      console.log(`Scheduled proactive check-in for user ${userId} in ${delayHours} hours with priority ${priority}`);
    } catch (error) {
      console.error('Failed to schedule proactive check-in:', error);
    }
  }

  /**
   * Generate health resource recommendations based on user symptoms and conditions
   */
  static async generateHealthResources(userId: string, symptoms: string[]): Promise<string[]> {
    const resources: string[] = [];
    
    // Symptom-specific resources
    for (const symptom of symptoms) {
      const symptomLower = symptom.toLowerCase();
      
      if (symptomLower.includes('headache') || symptomLower.includes('migraine')) {
        resources.push('Understanding Headaches: Causes and Relief Techniques');
        resources.push('Migraine Management: Triggers and Prevention');
      }
      
      if (symptomLower.includes('anxiety') || symptomLower.includes('stress')) {
        resources.push('Stress Management Techniques for Better Health');
        resources.push('Breathing Exercises for Anxiety Relief');
      }
      
      if (symptomLower.includes('pain') || symptomLower.includes('ache')) {
        resources.push('Natural Pain Management Strategies');
        resources.push('When to Seek Medical Attention for Pain');
      }
      
      if (symptomLower.includes('sleep') || symptomLower.includes('insomnia')) {
        resources.push('Healthy Sleep Habits for Better Rest');
        resources.push('Managing Sleep Disorders Naturally');
      }
      
      if (symptomLower.includes('blood pressure') || symptomLower.includes('hypertension')) {
        resources.push('Managing High Blood Pressure Through Diet');
        resources.push('Exercise Guidelines for Heart Health');
      }
    }
    
    // Remove duplicates and limit to top 5
    return Array.from(new Set(resources)).slice(0, 5);
  }

  /**
   * Send proactive health notification
   */
  static async sendProactiveNotification(userId: string, message: string, resources: string[] = []): Promise<void> {
    try {
      // Create an alert for the proactive notification
      await storage.insertAlert({
        userId,
        type: 'health_check_in',
        severity: 'medium',
        message: `Health Check-in from Zeina: ${message}`
      });
      
      console.log(`Sent proactive notification to user ${userId}`);
    } catch (error) {
      console.error('Failed to send proactive notification:', error);
    }
  }
}

export { NotificationService as default };