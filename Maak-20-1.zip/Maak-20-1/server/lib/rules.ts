import type { Vital, InsertAlert } from "@shared/schema";

export interface AlertRule {
  type: string;
  severity: "low" | "med" | "high";
  condition: (vital: Vital) => boolean;
  message: (vital: Vital) => string;
}

export const vitalAlertRules: AlertRule[] = [
  {
    type: "spo2_low",
    severity: "high",
    condition: (vital) => vital.kind === "spo2" && parseFloat(vital.value) < 90,
    message: (vital) => `SpO₂ below 90% (${vital.value}%)`
  },
  {
    type: "spo2_critical",
    severity: "high", 
    condition: (vital) => vital.kind === "spo2" && parseFloat(vital.value) < 85,
    message: (vital) => `Critical SpO₂ level: ${vital.value}%`
  },
  {
    type: "hr_high",
    severity: "med",
    condition: (vital) => vital.kind === "heart_rate" && parseFloat(vital.value) >= 130,
    message: (vital) => `High heart rate: ${vital.value} BPM`
  },
  {
    type: "hr_very_high", 
    severity: "high",
    condition: (vital) => vital.kind === "heart_rate" && parseFloat(vital.value) >= 150,
    message: (vital) => `Very high heart rate: ${vital.value} BPM`
  },
  {
    type: "hr_low",
    severity: "med",
    condition: (vital) => vital.kind === "heart_rate" && parseFloat(vital.value) <= 50,
    message: (vital) => `Low heart rate: ${vital.value} BPM`
  },
  {
    type: "bp_crisis",
    severity: "high",
    condition: (vital) => vital.kind === "bp_systolic" && parseFloat(vital.value) >= 180,
    message: (vital) => `Hypertensive crisis: ${vital.value} mmHg systolic`
  },
  {
    type: "bp_high",
    severity: "med",
    condition: (vital) => vital.kind === "bp_systolic" && parseFloat(vital.value) >= 140,
    message: (vital) => `High blood pressure: ${vital.value} mmHg systolic`
  },
  {
    type: "temp_high",
    severity: "med",
    condition: (vital) => vital.kind === "temperature" && parseFloat(vital.value) >= 38.5,
    message: (vital) => `High temperature: ${vital.value}°C`
  },
  {
    type: "temp_very_high",
    severity: "high", 
    condition: (vital) => vital.kind === "temperature" && parseFloat(vital.value) >= 40.0,
    message: (vital) => `Very high temperature: ${vital.value}°C`
  },
  {
    type: "sleep_poor",
    severity: "low",
    condition: (vital) => vital.kind === "sleep_score" && parseFloat(vital.value) < 60,
    message: (vital) => `Poor sleep quality: ${vital.value}/100`
  }
];

export function evaluateVitalAlerts(vital: Vital): InsertAlert[] {
  const alerts: InsertAlert[] = [];
  
  for (const rule of vitalAlertRules) {
    if (rule.condition(vital)) {
      alerts.push({
        userId: vital.userId!,
        type: rule.type,
        severity: rule.severity,
        message: rule.message(vital),
        vitalId: vital.id,
        status: "open"
      });
    }
  }
  
  return alerts;
}

export function evaluateMedicationAlert(medication: any, log: any): InsertAlert | null {
  const now = new Date();
  const scheduledTime = new Date(log.scheduledAt);
  const missedHours = (now.getTime() - scheduledTime.getTime()) / (1000 * 60 * 60);
  
  // Alert if critical medication missed by more than 2 hours
  if (medication.critical && log.status === "pending" && missedHours > 2) {
    return {
      userId: medication.userId,
      type: "missed_critical_med",
      severity: "high",
      message: `Critical medication missed: ${medication.name}`,
      status: "open"
    };
  }
  
  // Alert if any medication missed by more than 6 hours
  if (log.status === "pending" && missedHours > 6) {
    return {
      userId: medication.userId,
      type: "missed_med",
      severity: "med", 
      message: `Medication missed: ${medication.name}`,
      status: "open"
    };
  }
  
  return null;
}

export function shouldTriggerFallAlert(vitals: Vital[]): boolean {
  // Simple fall detection: rapid heart rate increase + potential impact detection
  // This would be more sophisticated in a real implementation
  const recentVitals = vitals.filter(v => {
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
    return new Date(v.measuredAt) > fiveMinutesAgo;
  });
  
  const heartRates = recentVitals
    .filter(v => v.kind === "heart_rate")
    .map(v => parseFloat(v.value))
    .sort((a, b) => b - a);
    
  return heartRates.length > 1 && heartRates[0] - heartRates[1] > 40;
}
