import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import * as schema from "@shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is required");
}

const sql = neon(process.env.DATABASE_URL);
export const db = drizzle(sql, { schema });

import { storage } from "../storage";

export function getCurrentUserId(req: any): string | null {
  // Extract auth ID from JWT token or session
  // For development, use a mock auth ID that matches our mock user
  return req.headers['x-user-id'] || 'b1ffcd99-8d1c-4f99-9c7e-7cc0ce481b22';
}

export async function requireAuth(req: any): Promise<string> {
  const authId = getCurrentUserId(req);
  console.log('Auth ID:', authId);
  if (!authId) {
    throw new Error('Authentication required');
  }
  
  // Look up the actual user ID from the auth ID
  const user = await storage.getUserByAuthId(authId);
  console.log('Found user:', user);
  if (!user) {
    throw new Error('User not found');
  }
  
  console.log('User ID:', user.id);
  return user.id;
}
