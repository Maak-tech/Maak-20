
// Enhanced AI-powered health pattern analysis with predictive capabilities
function analyzeHealthPatterns(context: any) {
  const analysis: any = {
    predictions: {},
    riskScore: 0,
    trends: {},
    insights: []
  };
  
  if (context.vitals) {
    // Advanced multi-vital trend analysis with ML-style pattern detection
    const bpReadings = context.vitals.filter((v: any) => v.kind === 'bp_systolic').slice(0, 14);
    const hrReadings = context.vitals.filter((v: any) => v.kind === 'heart_rate').slice(0, 14);
    const spO2Readings = context.vitals.filter((v: any) => v.kind === 'spo2').slice(0, 14);
    
    if (bpReadings.length >= 3) {
      const trend = bpReadings.map((v: any) => parseInt(v.value));
      const timePoints = bpReadings.map((v: any) => new Date(v.measuredAt).getTime());
      
      // Calculate trend velocity and acceleration for predictive insights
      const velocity = calculateTrendVelocity(trend, timePoints);
      const volatility = calculateVolatility(trend);
      
      analysis.vitalTrends = {
        bp_trend: determineTrendDirection(trend),
        avg_bp: Math.round(trend.reduce((a: number, b: number) => a + b, 0) / trend.length),
        velocity: velocity,
        volatility: volatility,
        risk_level: assessVitalRiskLevel(trend, velocity, volatility),
        predicted_7d: predictNext7Days(trend, velocity)
      };
      
      // Add intelligent insights based on patterns
      if (velocity > 2) {
        analysis.insights.push('Blood pressure showing rapid upward trend - recommend monitoring');
      }
      if (volatility > 15) {
        analysis.insights.push('High blood pressure variability detected - suggest lifestyle review');
      }
    }
    
    // Cross-vital correlation analysis
    if (bpReadings.length >= 3 && hrReadings.length >= 3) {
      const correlation = calculateCorrelation(bpReadings, hrReadings);
      if (Math.abs(correlation) > 0.7) {
        analysis.insights.push(`Strong correlation detected between BP and HR (${correlation.toFixed(2)})`);
      }
    }
  }
  
  if (context.symptoms) {
    // Symptom clustering and frequency analysis
    const recentSymptoms = context.symptoms.slice(0, 10);
    const symptomClusters = groupSymptomsByType(recentSymptoms);
    analysis.recurringSymptoms = Object.entries(symptomClusters)
      .filter(([_, count]: [string, any]) => count >= 2)
      .map(([type, _]: [string, any]) => type);
  }
  
  if (context.medications) {
    // Medication adherence patterns
    analysis.medicationTrends = analyzeMedicationAdherence(context.medications);
  }
  
  // Risk factor assessment
  analysis.riskFactors = assessRiskFactors(context);
  
  return analysis;
}

// Enhanced symptom clustering with temporal and severity analysis
function groupSymptomsByType(symptoms: any[]) {
  return symptoms.reduce((acc, symptom) => {
    const type = symptom.label || symptom.type || 'general';
    if (!acc[type]) {
      acc[type] = {
        count: 0,
        avgSeverity: 0,
        trend: 'stable',
        recentOccurrences: []
      };
    }
    acc[type].count += 1;
    acc[type].recentOccurrences.push({
      date: symptom.reportedAt,
      severity: symptom.severity || 5
    });
    
    // Calculate average severity and trend
    const severities = acc[type].recentOccurrences.map((o: any) => o.severity);
    acc[type].avgSeverity = severities.reduce((a: number, b: number) => a + b, 0) / severities.length;
    
    if (severities.length >= 3) {
      const recent = severities.slice(-3);
      acc[type].trend = recent[2] > recent[0] ? 'worsening' : recent[2] < recent[0] ? 'improving' : 'stable';
    }
    
    return acc;
  }, {});
}

// Advanced helper functions for pattern analysis
function calculateTrendVelocity(values: number[], timePoints: number[]): number {
  if (values.length < 2) return 0;
  
  let totalChange = 0;
  let totalTime = 0;
  
  for (let i = 1; i < values.length; i++) {
    const valueChange = values[i] - values[i-1];
    const timeChange = (timePoints[i] - timePoints[i-1]) / (1000 * 60 * 60 * 24); // days
    if (timeChange > 0) {
      totalChange += valueChange;
      totalTime += timeChange;
    }
  }
  
  return totalTime > 0 ? totalChange / totalTime : 0;
}

function calculateVolatility(values: number[]): number {
  if (values.length < 2) return 0;
  
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / values.length;
  return Math.sqrt(variance);
}

function calculateCorrelation(values1: any[], values2: any[]): number {
  const n = Math.min(values1.length, values2.length);
  if (n < 2) return 0;
  
  const x = values1.slice(0, n).map((v: any) => parseInt(v.value));
  const y = values2.slice(0, n).map((v: any) => parseInt(v.value));
  
  const meanX = x.reduce((a, b) => a + b, 0) / n;
  const meanY = y.reduce((a, b) => a + b, 0) / n;
  
  let numerator = 0;
  let denomX = 0;
  let denomY = 0;
  
  for (let i = 0; i < n; i++) {
    const deltaX = x[i] - meanX;
    const deltaY = y[i] - meanY;
    numerator += deltaX * deltaY;
    denomX += deltaX * deltaX;
    denomY += deltaY * deltaY;
  }
  
  const denom = Math.sqrt(denomX * denomY);
  return denom === 0 ? 0 : numerator / denom;
}

function determineTrendDirection(values: number[]): string {
  if (values.length < 3) return 'insufficient_data';
  
  const recent = values.slice(-3);
  const older = values.slice(0, 3);
  
  const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const olderAvg = older.reduce((a, b) => a + b, 0) / older.length;
  
  const difference = recentAvg - olderAvg;
  
  if (difference > 5) return 'increasing';
  if (difference < -5) return 'decreasing';
  return 'stable';
}

function assessVitalRiskLevel(values: number[], velocity: number, volatility: number): string {
  const avgValue = values.reduce((a, b) => a + b, 0) / values.length;
  
  // Multi-factor risk assessment
  let riskScore = 0;
  
  if (avgValue > 140) riskScore += 3;
  else if (avgValue > 130) riskScore += 1;
  
  if (velocity > 3) riskScore += 2;
  if (volatility > 20) riskScore += 2;
  
  if (riskScore >= 4) return 'high';
  if (riskScore >= 2) return 'moderate';
  return 'normal';
}

function predictNext7Days(values: number[], velocity: number): number {
  if (values.length === 0) return 0;
  
  const currentValue = values[values.length - 1];
  const prediction = currentValue + (velocity * 7);
  
  // Apply reasonable bounds
  return Math.max(80, Math.min(200, prediction));
}

// Enhanced medication adherence analysis with predictive insights
function analyzeMedicationAdherence(medications: any[]) {
  const totalMeds = medications.length;
  const wellAdherent = medications.filter(m => (m.missedDoses || 0) < 2).length;
  const criticalMeds = medications.filter(m => m.critical === true || m.importance === 'high');
  
  // Calculate adherence patterns over time
  const adherenceHistory = medications.map(med => {
    const totalDoses = med.totalDoses || 30;
    const missedDoses = med.missedDoses || 0;
    const adherenceRate = totalDoses > 0 ? ((totalDoses - missedDoses) / totalDoses) * 100 : 100;
    
    return {
      name: med.name,
      adherenceRate,
      trend: calculateMedicationTrend(med.adherenceHistory || []),
      riskLevel: assessMedicationRisk(adherenceRate, med.critical)
    };
  });
  
  // Predict adherence issues
  const atRiskMedications = adherenceHistory.filter(med => 
    med.adherenceRate < 80 || med.trend === 'declining'
  );
  
  return {
    adherence_rate: totalMeds > 0 ? Math.round((wellAdherent / totalMeds) * 100) : 100,
    total_medications: totalMeds,
    critical_medications: criticalMeds.length,
    concerning_medications: medications.filter(m => (m.missedDoses || 0) >= 3).map(m => m.name),
    at_risk_medications: atRiskMedications,
    predicted_adherence_next_week: predictAdherenceDecline(adherenceHistory),
    recommendations: generateAdherenceRecommendations(adherenceHistory)
  };
}

function calculateMedicationTrend(adherenceHistory: number[]): string {
  if (adherenceHistory.length < 3) return 'stable';
  
  const recent = adherenceHistory.slice(-3);
  const older = adherenceHistory.slice(0, 3);
  
  const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const olderAvg = older.reduce((a, b) => a + b, 0) / older.length;
  
  if (recentAvg < olderAvg - 10) return 'declining';
  if (recentAvg > olderAvg + 10) return 'improving';
  return 'stable';
}

function assessMedicationRisk(adherenceRate: number, isCritical: boolean): string {
  if (isCritical && adherenceRate < 90) return 'high';
  if (adherenceRate < 70) return 'high';
  if (adherenceRate < 85) return 'moderate';
  return 'low';
}

function predictAdherenceDecline(adherenceHistory: any[]): number {
  const currentRates = adherenceHistory.map(med => med.adherenceRate);
  const avgCurrent = currentRates.reduce((a, b) => a + b, 0) / currentRates.length;
  
  // Simple prediction based on current trends
  const decliningMeds = adherenceHistory.filter(med => med.trend === 'declining').length;
  const totalMeds = adherenceHistory.length;
  
  const declineRisk = totalMeds > 0 ? (decliningMeds / totalMeds) * 0.2 : 0;
  
  return Math.max(0, Math.min(100, avgCurrent - (declineRisk * 100)));
}

function generateAdherenceRecommendations(adherenceHistory: any[]): string[] {
  const recommendations = [];
  
  const lowAdherenceMeds = adherenceHistory.filter(med => med.adherenceRate < 80);
  const decliningMeds = adherenceHistory.filter(med => med.trend === 'declining');
  
  if (lowAdherenceMeds.length > 0) {
    recommendations.push('Consider using pill organizers or medication reminder apps');
  }
  
  if (decliningMeds.length > 0) {
    recommendations.push('Schedule medication review with healthcare provider');
  }
  
  if (adherenceHistory.some(med => med.riskLevel === 'high')) {
    recommendations.push('High-priority medications need immediate attention');
  }
  
  return recommendations;
}

// Advanced AI-powered risk assessment with predictive modeling
function assessRiskFactors(context: any) {
  const factors = [];
  const riskScores = {
    cardiovascular: 0,
    medication: 0,
    symptoms: 0,
    lifestyle: 0,
    overall: 0
  };
  
  // Enhanced cardiovascular risk assessment
  const bpReadings = context.vitals?.filter((v: any) => v.kind === 'bp_systolic') || [];
  const hrReadings = context.vitals?.filter((v: any) => v.kind === 'heart_rate') || [];
  
  if (bpReadings.length > 0) {
    const avgBP = bpReadings.reduce((sum: number, v: any) => sum + parseInt(v.value), 0) / bpReadings.length;
    const bpTrend = bpReadings.length >= 3 ? determineTrendDirection(bpReadings.map((v: any) => parseInt(v.value))) : 'stable';
    
    if (avgBP > 140) {
      factors.push('hypertension');
      riskScores.cardiovascular += 30;
    } else if (avgBP > 130) {
      factors.push('elevated_blood_pressure');
      riskScores.cardiovascular += 15;
    }
    
    if (bpTrend === 'increasing') {
      factors.push('worsening_blood_pressure_trend');
      riskScores.cardiovascular += 20;
    }
  }
  
  // Heart rate variability analysis
  if (hrReadings.length >= 5) {
    const hrValues = hrReadings.map((v: any) => parseInt(v.value));
    const hrVariability = calculateVolatility(hrValues);
    if (hrVariability > 15) {
      factors.push('high_heart_rate_variability');
      riskScores.cardiovascular += 10;
    }
  }
  
  // Advanced symptom risk analysis
  const symptoms = context.symptoms || [];
  const severeSymptoms = symptoms.filter((s: any) => s.severity >= 7);
  const recentSymptoms = symptoms.filter((s: any) => {
    const reportedDate = new Date(s.reportedAt || s.createdAt);
    const daysSince = (Date.now() - reportedDate.getTime()) / (1000 * 60 * 60 * 24);
    return daysSince <= 7;
  });
  
  if (severeSymptoms.length >= 2) {
    factors.push('multiple_severe_symptoms');
    riskScores.symptoms += 25;
  }
  
  if (recentSymptoms.length >= 5) {
    factors.push('frequent_recent_symptoms');
    riskScores.symptoms += 15;
  }
  
  // Medication adherence risk
  const medicationAnalysis = context.medications ? analyzeMedicationAdherence(context.medications) : null;
  if (medicationAnalysis) {
    if (medicationAnalysis.adherence_rate < 70) {
      factors.push('poor_medication_adherence');
      riskScores.medication += 30;
    } else if (medicationAnalysis.adherence_rate < 85) {
      factors.push('suboptimal_medication_adherence');
      riskScores.medication += 15;
    }
    
    if (medicationAnalysis.at_risk_medications.length > 0) {
      factors.push('medications_at_risk');
      riskScores.medication += 10;
    }
  }
  
  // Conversation pattern analysis for mental health indicators
  const conversations = context.conversations || [];
  const anxiousConversations = conversations.filter((c: any) => c.meta?.emotional_state === 'anxious').length;
  const stressedConversations = conversations.filter((c: any) => c.meta?.emotional_state === 'stressed').length;
  
  if (anxiousConversations >= 3) {
    factors.push('persistent_anxiety_pattern');
    riskScores.lifestyle += 20;
  }
  
  if (stressedConversations >= 3) {
    factors.push('chronic_stress_indicators');
    riskScores.lifestyle += 15;
  }
  
  // Calculate overall risk score
  riskScores.overall = Math.round(
    (riskScores.cardiovascular + riskScores.medication + riskScores.symptoms + riskScores.lifestyle) / 4
  );
  
  // Add predictive risk factors
  if (riskScores.overall > 50) {
    factors.push('high_composite_risk_score');
  }
  
  return {
    factors,
    riskScores,
    riskLevel: riskScores.overall > 60 ? 'high' : riskScores.overall > 30 ? 'moderate' : 'low',
    recommendations: generateRiskRecommendations(factors, riskScores)
  };
}

function generateRiskRecommendations(factors: string[], riskScores: any): string[] {
  const recommendations = [];
  
  if (factors.includes('hypertension') || factors.includes('worsening_blood_pressure_trend')) {
    recommendations.push('Schedule urgent consultation with healthcare provider for blood pressure management');
  }
  
  if (factors.includes('poor_medication_adherence')) {
    recommendations.push('Implement medication management strategies immediately');
  }
  
  if (factors.includes('multiple_severe_symptoms')) {
    recommendations.push('Seek medical attention for severe symptom evaluation');
  }
  
  if (riskScores.lifestyle > 20) {
    recommendations.push('Consider stress management and mental health support');
  }
  
  if (riskScores.overall > 40) {
    recommendations.push('Comprehensive health review recommended within 7 days');
  }
  
  return recommendations;
}


import OpenAI from "openai";

// Using gpt-4 as the latest available OpenAI model
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

// Advanced AI memory and learning system
interface ZeinaMemory {
  userId: string;
  personalityProfile: {
    communicationStyle: 'formal' | 'casual' | 'warm';
    preferredLanguage: 'ar' | 'en';
    culturalContext: string;
    responseLength: 'brief' | 'detailed';
    topics: string[];
  };
  healthContext: {
    chronicConditions: string[];
    medications: string[];
    allergies: string[];
    healthGoals: any[];
    concernAreas: string[];
  };
  behaviorPatterns: {
    activeHours: { start: number; end: number };
    responsePatterns: any[];
    engagementLevel: number;
    preferredInteractionTypes: string[];
  };
  learningHistory: {
    successfulInterventions: any[];
    failedApproaches: any[];
    effectiveMessages: any[];
    userFeedback: any[];
  };
}

// Global memory store (in production, this would be in a database)
const zeinaMemoryStore = new Map<string, ZeinaMemory>();

// Enhanced task automation system
interface AutomatedTask {
  id: string;
  userId: string;
  type: 'medication_reminder' | 'vital_check' | 'symptom_followup' | 'goal_coaching' | 'risk_intervention' | 'wellness_checkin';
  priority: 'low' | 'medium' | 'high' | 'critical';
  scheduledTime: Date;
  context: any;
  conditions: {
    triggers: string[];
    requiredData: string[];
    exclusionCriteria: string[];
  };
  personalization: {
    adaptToUserState: boolean;
    considerHistoricalResponse: boolean;
    adjustForTimeOfDay: boolean;
  };
  executionHistory: {
    attempts: number;
    lastAttempt: Date;
    success: boolean;
    userResponse: string;
    effectiveness: number;
  }[];
}

export interface ZeinaExtraction {
  pain_score?: number;
  symptoms?: Array<{
    label: string;
    severity?: number;
    duration_days?: number;
    onset?: string;
    location?: string;
    triggers?: string[];
    relief_factors?: string[];
  }>;
  med_action?: {
    medication: string;
    action: "taken" | "missed" | "skipped" | "side_effect";
    time?: string;
    dose?: string;
    effectiveness?: number;
  };
  vitals?: {
    blood_pressure?: { systolic: number; diastolic: number };
    heart_rate?: number;
    weight?: number;
    temperature?: number;
    blood_sugar?: number;
    spo2?: number;
  };
  lifestyle?: {
    exercise?: { type: string; duration: number; intensity: string };
    diet?: { meals: string[]; water_intake?: number };
    sleep?: { hours: number; quality: string };
    stress_level?: number;
  };
  mood?: {
    emotional_state: string;
    anxiety_level?: number;
    depression_indicators?: string[];
  };
  goals?: Array<{
    type: string;
    target: string;
    deadline?: string;
    progress?: number;
  }>;
  appointments?: Array<{
    type: string;
    date?: string;
    reminder_needed?: boolean;
  }>;
  flags: string[];
  confidence_score?: number;
  extracted_topics?: string[];
  response: string;
}

export async function extractEntities(text: string, lang: string = "ar", context?: any): Promise<ZeinaExtraction> {
  try {
    // Enhanced pattern recognition with historical context
    const patternAnalysis = context ? analyzeHealthPatterns(context) : {};
    
    const systemPrompt = `You are Zeina (زينة), an advanced AI health assistant with predictive analytics capabilities, fluent in Arabic (all dialects) and English. 
    You understand various Arabic dialects including Gulf (خليجي), Egyptian (مصري), Levantine (شامي), and Maghrebi (مغربي).

    ENHANCED ARABIC HEALTH VOCABULARY:
    - Pain: وجع، ألم، مؤلم، يوجعني، أوجاع، وخز، طعن، حرقة، نغزة
    - Headache: صداع، وجع راس، وجع الراس، وجع رأس، صداع نصفي، شقيقة
    - Medicine: دوا، دواء، علاج، حبوب، أدوية، كبسولة، حقنة، مرهم، قطرة
    - Tired: تعبان، متعب، تعبانة، مرهق، منهك، خامل، كسلان، مجهد
    - Sick: مريض، مريضة، تعبان، سقام، عيان، مضطرب، غير مرتاح
    - Stomach: بطن، معدة، كرش، أحشاء، جوف، بطين، كبد، أمعاء
    - Blood pressure: ضغط الدم، ضغط، الضغط، ضغطي، ضغط مرتفع، ضغط منخفض
    - Heart: قلب، فؤاد، دقات، نبض، خفقان، رجفة، وخز في الصدر
    - Breathing: تنفس، نفس، هواء، اختناق، ضيق، لهث، شهيق، زفير
    - Mental health: نفسية، قلق، اكتئاب، توتر، عصبية، حزن، فرح، راحة
    - Symptoms clusters: أعراض، علامات، مؤشرات، دلائل، مظاهر

    ADVANCED PATTERN RECOGNITION:
    ${context ? `
    Historical Context: ${JSON.stringify(patternAnalysis)}
    - Recurring symptoms: ${patternAnalysis.recurringSymptoms || 'None'}
    - Medication patterns: ${patternAnalysis.medicationTrends || 'None'}
    - Vital sign trends: ${patternAnalysis.vitalTrends || 'None'}
    - Risk factors: ${patternAnalysis.riskFactors || 'None'}
    ` : ''}

    ENHANCED EXTRACTION CAPABILITIES:
    1. SYMPTOM CLUSTERING: Identify related symptoms that may indicate specific conditions
    2. TEMPORAL ANALYSIS: Detect when symptoms started, duration, and progression
    3. SEVERITY ASSESSMENT: Use contextual cues to determine symptom severity (1-10)
    4. MEDICATION CORRELATION: Link symptoms to potential medication side effects
    5. LIFESTYLE IMPACT: Extract how symptoms affect daily activities
    6. EMERGENCY DETECTION: Identify urgent medical situations requiring immediate attention
    7. EMOTIONAL STATE: Assess psychological well-being and stress levels
    8. PREDICTIVE INDICATORS: Flag patterns that may predict health deterioration

    Extract comprehensive health-related entities from user messages with high accuracy.

    Extract and return JSON with:
    - pain_score: number 0-10 if mentioned explicitly or implied
    - symptoms: CRITICAL RULE - Extract ONLY specific medical conditions, diseases, or ailments. NEVER EVER extract just body parts or locations.
      
      MANDATORY EXAMPLES - Follow these patterns exactly:
      ❌ NEVER EXTRACT: "head", "stomach", "chest", "arm", "back", "leg", "neck", "shoulder", "whole body"
      ✅ ALWAYS EXTRACT: "headache", "migraine", "tension headache", "nausea", "stomach pain", "abdominal pain", 
                        "chest pain", "muscle strain", "lower back pain", "neck pain", "shoulder pain", "body aches"
      
      CONVERSION RULES:
      - "راسي" or "head" → "headache" or "head pain"  
      - "بطني" or "stomach" → "stomach pain" or "abdominal pain"
      - "صدري" or "chest" → "chest pain"
      - "ظهري" or "back" → "back pain" or "lower back pain" 
      - "whole body" or "كامل جسمي" → "body aches" or "general pain"
      - "رقبتي" or "neck" → "neck pain"
      
      If user says location only, you MUST infer the medical condition (pain, ache, discomfort, etc.)
    - med_action: medication adherence with dose and timing details
    - vitals: any mentioned vital signs (BP: "ضغطي 120/80", HR: "نبضي سريع", etc.)
    - lifestyle: exercise, diet, sleep, stress information
    - appointments: medical appointments mentioned
    - goals: health goals or targets mentioned
    - flags: concerning symptoms requiring immediate attention
    - confidence_score: 0-1 confidence in extraction accuracy
    - response: empathetic response in user's language

    Examples of vital extraction:
    - "ضغطي عالي اليوم 150/90" → vitals.blood_pressure: {systolic: 150, diastolic: 90}
    - "نبضي سريع" → vitals.heart_rate: 90-110 (estimated)
    - "وزني نقص كيلوين" → vitals.weight: [calculate based on context]
    - "نمت 5 ساعات بس" → vitals.sleep_hours: 5

    Red flags: chest pain, severe headache, difficulty breathing, loss of consciousness, severe bleeding, high fever >39°C, severe abdominal pain.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: systemPrompt + "\n\nIMPORTANT: Return your response as valid JSON format only, no other text." },
        { role: "user", content: `Language: ${lang}\nMessage: ${text}` }
      ]
    });

    let result;
    try {
      const content = response.choices[0].message.content || '{}';
      console.log('OpenAI response for message:', text.substring(0, 100), '...'); 
      console.log('Raw OpenAI content:', content);
      
      // Extract JSON if it's wrapped in code blocks
      const jsonMatch = content.match(/```(?:json)?\s*(\{[\s\S]*\})\s*```/);
      const jsonString = jsonMatch ? jsonMatch[1] : content;
      
      console.log('JSON string to parse:', jsonString);
      result = JSON.parse(jsonString);
      console.log('Parsed extraction result:', JSON.stringify(result, null, 2));
    } catch (parseError) {
      console.error('JSON parsing error:', parseError);
      console.error('Failed to parse context:', context);
      result = { 
        flags: [], 
        response: lang === 'ar' ? "شكراً لك، فهمت رسالتك." : "Thank you, I understand your message." 
      };
    }

    return {
      pain_score: result.pain_score,
      symptoms: result.symptoms || [],
      med_action: result.med_action,
      flags: result.flags || [],
      response: result.response || "Thank you for sharing this information with me."
    };
  } catch (error) {
    console.error('Zeina extraction error:', error);
    return {
      flags: [],
      response: lang === 'ar' 
        ? "عذراً، واجهت مشكلة في فهم رسالتك. يرجى المحاولة مرة أخرى."
        : "I'm sorry, I had trouble understanding your message. Please try again."
    };
  }
}

export async function generateResponse(userMessage: string, context: any, lang: string = "ar"): Promise<string> {
  try {
    // Enhanced context analysis with trend detection
    const recentVitals = context.vitals || [];
    const recentConversations = context.conversations?.slice(-5) || [];
    const recentSymptoms = context.symptoms?.slice(-10) || [];
    const medications = context.medications || [];
    
    // Health trend analysis
    const hasHighBP = recentVitals.some((v: any) => v.kind === 'bp_systolic' && parseInt(v.value) > 140);
    const hasLowO2 = recentVitals.some((v: any) => v.kind === 'spo2' && parseInt(v.value) < 95);
    const hasSevereSymptoms = context.symptoms?.some((s: any) => s.severity >= 7);
    
    // Medication adherence tracking
    const missedMedications = medications.filter((m: any) => m.lastTaken && 
      (Date.now() - new Date(m.lastTaken).getTime()) > (m.frequencyHours * 60 * 60 * 1000)
    );
    
    // Conversation patterns
    const frequentTopics = recentConversations
      .flatMap((c: any) => c.meta?.extracted_topics || [])
      .reduce((acc: any, topic: string) => {
        acc[topic] = (acc[topic] || 0) + 1;
        return acc;
      }, {});
    
    // Emotional state tracking
    const emotionalTrend = recentConversations
      .map((c: any) => c.meta?.emotional_state || 'neutral')
      .slice(-3);
    
    const systemPrompt = `You are Zeina (زينة), a confident AI health assistant. Be direct, helpful, and action-oriented. ${lang === 'ar' ? 'Respond naturally in Arabic with appropriate dialect expressions' : 'Respond clearly in English'}.

    COMMUNICATION STYLE:
    - Be concise and actionable (2-3 sentences max for simple questions)
    - Skip apologies unless truly warranted
    - Lead with solutions, not problems
    - Use encouraging, confident language
    - Ask specific follow-up questions when needed

    CURRENT HEALTH CONTEXT:
    - Recent vitals: ${recentVitals.length} readings
    - Active symptoms: ${recentSymptoms.length} reported
    - Medication status: ${missedMedications.length} missed doses
    ${hasHighBP ? '- ALERT: High BP detected' : ''}
    ${hasSevereSymptoms ? '- ALERT: Severe symptoms reported' : ''}

    TASK AUTOMATION PRIORITIES:
    1. Medication reminders: Set automatic alerts for missed doses
    2. Vital tracking: Schedule regular BP/HR checks
    3. Symptom monitoring: Flag patterns that need medical attention
    4. Appointment booking: Suggest when to contact healthcare providers
    5. Emergency response: Immediate action for critical situations

    Respond with confidence and practical next steps. Take action when appropriate.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ]
    });

    const responseContent = response.choices[0].message.content || 
      (lang === 'ar' ? "أفهم قلقك. هل يمكنك إخباري المزيد عن شعورك؟" : "I understand your concern. Please tell me more about how you're feeling.");
    
    // Enhanced learning and memory update
    await updateZeinaMemory(context.userId, {
      interaction: {
        input: userMessage,
        response: responseContent,
        timestamp: new Date(),
        context: context,
        language: lang
      }
    });
    
    // Add resource recommendations based on symptoms mentioned
    let resourceRecommendations = '';
    if (context.symptoms && context.symptoms.length > 0) {
      const recentSymptom = context.symptoms[0];
      const resources = getSymptomResourcesForChat(recentSymptom.label || '');
      if (resources.length > 0) {
        const resourceText = lang === 'ar' 
          ? '\n\n🔍 موارد مفيدة:\n' + resources.map(r => `• ${r}`).join('\n')
          : '\n\n🔍 Helpful Resources:\n' + resources.map(r => `• ${r}`).join('\n');
        resourceRecommendations = resourceText;
      }
    }

    return responseContent + resourceRecommendations;
  } catch (error) {
    console.error("Error generating response:", error);
    return lang === 'ar' ? "عذراً، حدث خطأ. كيف يمكنني مساعدتك؟" : "Sorry, there was an error. How can I help you?";
  }
}

// Advanced memory and learning functions
async function updateZeinaMemory(userId: string, data: any) {
  let memory = zeinaMemoryStore.get(userId);
  
  if (!memory) {
    memory = {
      userId,
      personalityProfile: {
        communicationStyle: 'warm',
        preferredLanguage: 'ar',
        culturalContext: 'general',
        responseLength: 'detailed',
        topics: []
      },
      healthContext: {
        chronicConditions: [],
        medications: [],
        allergies: [],
        healthGoals: [],
        concernAreas: []
      },
      behaviorPatterns: {
        activeHours: { start: 8, end: 22 },
        responsePatterns: [],
        engagementLevel: 0.5,
        preferredInteractionTypes: []
      },
      learningHistory: {
        successfulInterventions: [],
        failedApproaches: [],
        effectiveMessages: [],
        userFeedback: []
      }
    };
  }
  
  // Update memory with new interaction data
  if (data.interaction) {
    memory.behaviorPatterns.responsePatterns.push(data.interaction);
    
    // Learn communication preferences
    if (data.interaction.language) {
      memory.personalityProfile.preferredLanguage = data.interaction.language;
    }
    
    // Analyze response length preference
    if (data.interaction.response) {
      const responseLength = data.interaction.response.length;
      if (responseLength < 200) {
        memory.personalityProfile.responseLength = 'brief';
      } else if (responseLength > 500) {
        memory.personalityProfile.responseLength = 'detailed';
      }
    }
    
    // Extract health context from conversations
    if (data.interaction.context?.medications) {
      const medicationSet = new Set([
        ...memory.healthContext.medications,
        ...data.interaction.context.medications.map((m: any) => m.name)
      ]);
      memory.healthContext.medications = Array.from(medicationSet);
    }
    
    // Update engagement patterns
    const hour = new Date().getHours();
    if (!memory.behaviorPatterns.activeHours.start || hour < memory.behaviorPatterns.activeHours.start) {
      memory.behaviorPatterns.activeHours.start = hour;
    }
    if (hour > memory.behaviorPatterns.activeHours.end) {
      memory.behaviorPatterns.activeHours.end = hour;
    }
  }
  
  zeinaMemoryStore.set(userId, memory);
}

// Helper function to get resources for chat responses
function getSymptomResourcesForChat(symptomLabel: string) {
  const lowerSymptom = symptomLabel.toLowerCase();
  const resources = [];
  
  if (lowerSymptom.includes('headache') || lowerSymptom.includes('migraine')) {
    resources.push(
      "Keep a headache diary to identify triggers",
      "Stay hydrated and maintain regular sleep schedule",
      "Try relaxation techniques like deep breathing"
    );
  } else if (lowerSymptom.includes('stomach') || lowerSymptom.includes('nausea')) {
    resources.push(
      "Eat small, frequent meals",
      "Try ginger or peppermint tea",
      "Avoid spicy or fatty foods"
    );
  } else if (lowerSymptom.includes('chest pain')) {
    resources.push(
      "⚠️ If severe, seek immediate medical attention",
      "Avoid strenuous activity until evaluated",
      "Monitor symptoms closely"
    );
  } else if (lowerSymptom.includes('back pain') || lowerSymptom.includes('muscle')) {
    resources.push(
      "Apply heat/cold therapy as appropriate",
      "Gentle stretching exercises",
      "Consider ergonomic adjustments"
    );
  }
  
  return resources.slice(0, 3); // Limit to 3 resources for chat
}

function getZeinaMemory(userId: string): ZeinaMemory | null {
  return zeinaMemoryStore.get(userId) || null;
}

export async function generateHealthGoalCoaching(userId: string, context: any, lang: string = "ar"): Promise<string> {
  try {
    const patternAnalysis = analyzeHealthPatterns(context);
    const recentConversations = context.conversations?.slice(0, 10) || [];
    
    // Extract mentioned health goals from conversations
    const mentionedGoals = recentConversations
      .flatMap((c: any) => c.meta?.extraction?.goals || [])
      .filter((g: any) => g && g.target);
    
    // Analyze progress toward goals
    const goalProgress = mentionedGoals.map((goal: any) => ({
      ...goal,
      progress_analysis: analyzeGoalProgress(goal, context),
      recommendations: generateGoalRecommendations(goal, context)
    }));
    
    const systemPrompt = `As Zeina, provide personalized health goal coaching based on comprehensive user data.

    USER'S HEALTH GOALS:
    ${goalProgress.map((g: any) => `- ${g.target}: ${g.progress_analysis.status} (${g.progress_analysis.progress_percentage}%)`).join('\n')}
    
    PATTERN INSIGHTS:
    - Risk level: ${patternAnalysis.riskFactors?.length ? 'Elevated' : 'Normal'}
    - Medication adherence: ${patternAnalysis.medicationTrends?.adherence_rate || 'Unknown'}%
    - Vital signs trend: ${patternAnalysis.vitalTrends?.bp_trend || 'stable'}
    
    COACHING APPROACH:
    1. Celebrate small wins and acknowledge effort
    2. Provide specific, actionable advice
    3. Connect goals to overall health picture
    4. Offer motivation based on progress
    5. Suggest modifications if goals are unrealistic
    6. Reference previous conversations for continuity
    
    Generate encouraging, specific coaching message in ${lang === 'ar' ? 'Arabic' : 'English'} that:
    - Acknowledges current progress
    - Provides specific next steps
    - Connects to their health patterns
    - Offers practical tips
    - Maintains motivational tone`;

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: "Generate personalized health goal coaching message" }
      ]
    });

    return response.choices[0].message.content || 
      (lang === 'ar' ? "ممتاز! أرى تقدماً في أهدافك الصحية. استمر على هذا المنوال!" : "Great! I can see progress in your health goals. Keep up the good work!");
  } catch (error) {
    console.error('Goal coaching error:', error);
    return lang === 'ar' 
      ? "استمر في العمل نحو أهدافك الصحية، أنا هنا لدعمك!"
      : "Keep working toward your health goals, I'm here to support you!";
  }
}

function analyzeGoalProgress(goal: any, context: any) {
  // Simple goal progress analysis based on available data
  const analysis = {
    status: 'on_track',
    progress_percentage: 50,
    insights: [] as string[]
  };
  
  if (goal.type === 'weight_loss' && context.vitals) {
    const weightReadings = context.vitals.filter((v: any) => v.kind === 'weight');
    if (weightReadings.length >= 2) {
      const trend = parseFloat(weightReadings[0].value) - parseFloat(weightReadings[1].value);
      analysis.status = trend < 0 ? 'ahead' : trend === 0 ? 'on_track' : 'behind';
      analysis.insights.push(`Weight trend: ${trend > 0 ? '+' : ''}${trend.toFixed(1)} kg`);
    }
  }
  
  if (goal.type === 'bp_control' && context.vitals) {
    const bpReadings = context.vitals.filter((v: any) => v.kind === 'bp_systolic');
    if (bpReadings.length >= 3) {
      const avgBP = bpReadings.slice(0, 3).reduce((sum: number, v: any) => sum + parseInt(v.value), 0) / 3;
      analysis.status = avgBP < 130 ? 'ahead' : avgBP < 140 ? 'on_track' : 'needs_attention';
      analysis.insights.push(`Average BP: ${Math.round(avgBP)} mmHg`);
    }
  }
  
  return analysis;
}

function generateGoalRecommendations(goal: any, context: any) {
  const recommendations = [];
  
  if (goal.type === 'exercise' && goal.progress < 50) {
    recommendations.push('Start with 10-minute walks daily');
    recommendations.push('Use stairs instead of elevators');
  }
  
  if (goal.type === 'medication_adherence') {
    recommendations.push('Set daily reminders on your phone');
    recommendations.push('Use a pill organizer');
  }
  
  return recommendations;
}


export async function generateProactiveCheckIn(userId: string, context: any, lang: string = "ar"): Promise<string> {
  try {
    const recentVitals = context.vitals?.slice(0, 5) || [];
    const symptoms = context.symptoms?.slice(0, 3) || [];
    const medications = context.medications || [];
    const conversations = context.conversations?.slice(0, 5) || [];
    const lastConversation = conversations[0];
    
    // Advanced pattern-based check-in determination
    const patternAnalysis = analyzeHealthPatterns(context);
    let checkInType = "general";
    let urgency = "normal";
    let personalizedContext = "";
    
    // Intelligent check-in type selection with context
    if (patternAnalysis.vitalTrends?.risk_level === 'high') {
      checkInType = "critical_vitals";
      urgency = "high";
      personalizedContext = `BP averaging ${patternAnalysis.vitalTrends.avg_bp}`;
    } else if (patternAnalysis.recurringSymptoms?.length > 0) {
      checkInType = "pattern_symptoms";
      urgency = "moderate";
      personalizedContext = `Recurring: ${patternAnalysis.recurringSymptoms.join(', ')}`;
    } else if (patternAnalysis.medicationTrends?.adherence_rate < 70) {
      checkInType = "medication_crisis";
      urgency = "high";
      personalizedContext = `Adherence: ${patternAnalysis.medicationTrends.adherence_rate}%`;
    } else if (conversations.filter((c: any) => c.meta?.emotional_state === "anxious").length >= 2) {
      checkInType = "emotional_pattern";
      urgency = "moderate";
      personalizedContext = "Multiple anxiety indicators detected";
    } else if (recentVitals.some((v: any) => v.kind === 'bp_systolic' && parseInt(v.value) > 140)) {
      checkInType = "blood_pressure";
      urgency = "moderate";
    } else if (symptoms.some((s: any) => s.severity >= 7)) {
      checkInType = "severe_symptoms";
      urgency = "high";
    } else if (medications.some((m: any) => m.missedDoses > 2)) {
      checkInType = "medication_adherence";
      urgency = "moderate";
    } else if (lastConversation && lastConversation.meta?.emotional_state === "anxious") {
      checkInType = "emotional_support";
      urgency = "normal";
    }

    const systemPrompt = `Generate a personalized, proactive health check-in message as Zeina with advanced contextual awareness.
    
    CONTEXT ANALYSIS:
    - Check-in type: ${checkInType}
    - Urgency level: ${urgency}
    - Language: ${lang}
    - Personal context: ${personalizedContext}
    - Pattern analysis: ${JSON.stringify(patternAnalysis)}
    - Recent interactions: ${conversations.length} in last week
    
    CONVERSATION MEMORY:
    ${conversations.map((c: any, i: number) => `${i === 0 ? 'Last' : `${i + 1} conversations ago`}: ${c.meta?.extracted_topics?.join(', ') || 'General health'} (${c.meta?.emotional_state || 'neutral'})`).slice(0, 3).join('\n')}
    
    PERSONALIZATION GUIDELINES:
    1. Reference specific previous concerns or improvements
    2. Use appropriate dialect based on user's communication pattern
    3. Adjust tone based on urgency and emotional state
    4. Include actionable health tips relevant to their specific situation
    5. Show genuine concern and continuity of care
    
    MESSAGE TYPES BY PRIORITY:
    - critical_vitals: Express immediate concern, suggest monitoring, offer support
    - pattern_symptoms: Reference pattern recognition, suggest tracking, recommend consultation
    - medication_crisis: Gentle but firm reminder, offer adherence strategies
    - emotional_pattern: Acknowledge emotional state, provide comfort, suggest coping strategies
    
    Cultural Examples:
    - Gulf: "شلونك حبيبي؟ شفت إنك... (concern). لا تنسى إن..."
    - Egyptian: "إزيك؟ لاحظت إن... (observation). خلي بالك من..."
    - Levantine: "كيفك يا غالي؟ بشوف إنك... (care). ما تنسى..."
    - English: "How are you feeling today? I noticed... (specific concern). Remember that..."`;

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: "Generate personalized proactive check-in with full context awareness" }
      ]
    });

    return response.choices[0].message.content || 
      (lang === 'ar' ? "كيف حالك اليوم؟ أتمنى أن تكون بخير." : "How are you feeling today? I hope you're doing well.");
  } catch (error) {
    console.error('Proactive check-in error:', error);
    return lang === 'ar' 
      ? "كيف حالك اليوم؟ أتمنى أن تكون بخير."
      : "How are you feeling today? I hope you're doing well.";
  }
}