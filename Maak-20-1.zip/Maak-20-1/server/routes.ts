import type { Express } from "express";
import { createServer, type Server } from "http";
import authRoutes from "./routes/auth";
import ingestRoutes from "./routes/ingest";
import webhookRoutes from "./routes/webhooks";
import adminRoutes from "./routes/admin";
import meRoutes from "./routes/me";
import { jobRunner } from "./jobs/runner";

export async function registerRoutes(app: Express): Promise<Server> {
  // Register route modules
  app.use("/api/auth", authRoutes);
  app.use("/api/ingest", ingestRoutes);
  app.use("/api/webhooks", webhookRoutes);
  app.use("/api/admin", adminRoutes);
  app.use("/api/me", meRoutes);

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      version: "2.0.0"
    });
  });

  // Start job runner in development only
  if (process.env.NODE_ENV === 'development') {
    jobRunner.start();
    console.log('Job runner started');
  }

  const httpServer = createServer(app);
  return httpServer;
}
