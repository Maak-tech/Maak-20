import { Router } from "express";
import { storage } from "../storage";
import { requireAuth } from "../lib/supabase";

const router = Router();

// GET /admin/family/:familyId/members - Get family members with health overview
router.get("/family/:familyId/members", async (req, res) => {
  try {
    const adminUserId = requireAuth(req);
    const { familyId } = req.params;
    
    // Verify user is admin of this family
    const adminMembers = await storage.getFamilyMembersByAdmin(adminUserId);
    const isAdmin = adminMembers.some(member => 
      member.familyId === familyId && member.role === "admin"
    );
    
    if (!isAdmin) {
      return res.status(403).json({ error: "Access denied - not family admin" });
    }
    
    const members = await storage.getFamilyMembers(familyId);
    const memberDetails = [];
    
    for (const member of members) {
      const profile = await storage.getProfile(member.userId!);
      const recentVitals = await storage.getVitals(member.userId!, { range: "1d" });
      const openAlerts = await storage.getAlerts(member.userId!, "open");
      
      // Get latest vitals by type
      const latestVitals = recentVitals.reduce((acc, vital) => {
        if (!acc[vital.kind] || new Date(vital.measuredAt) > new Date(acc[vital.kind].measuredAt)) {
          acc[vital.kind] = vital;
        }
        return acc;
      }, {} as any);
      
      // Calculate risk level based on open alerts
      const riskLevel = openAlerts.some(a => a.severity === 'high') ? 'critical' :
                      openAlerts.some(a => a.severity === 'med') ? 'warning' : 'normal';
      
      memberDetails.push({
        id: member.userId,
        profile,
        latestVitals,
        openAlertsCount: openAlerts.length,
        riskLevel,
        lastVitalTime: recentVitals[0]?.measuredAt || null
      });
    }
    
    res.json(memberDetails);
  } catch (error) {
    console.error('Get family members error:', error);
    res.status(500).json({ error: "Failed to get family members" });
  }
});

// GET /admin/member/:userId/overview - Get detailed member health overview
router.get("/member/:userId/overview", async (req, res) => {
  try {
    const adminUserId = requireAuth(req);
    const { userId } = req.params;
    
    // Verify admin has access to this member
    const adminMembers = await storage.getFamilyMembersByAdmin(adminUserId);
    const memberIds = adminMembers.map(m => m.userId);
    
    if (!memberIds.includes(userId)) {
      return res.status(403).json({ error: "Access denied - member not in your family" });
    }
    
    const profile = await storage.getProfile(userId);
    const vitals = await storage.getVitals(userId, { range: "7d" });
    const alerts = await storage.getAlerts(userId);
    const medications = await storage.getMedications(userId);
    const medicationLogs = await storage.getMedicationLogs(userId, new Date());
    const conversations = await storage.getConversations(userId, 10);
    
    // Group vitals by type for charting
    const vitalsByType = vitals.reduce((acc, vital) => {
      if (!acc[vital.kind]) acc[vital.kind] = [];
      acc[vital.kind].push(vital);
      return acc;
    }, {} as any);
    
    // Calculate medication adherence
    const totalScheduled = medicationLogs.length;
    const taken = medicationLogs.filter(log => log.status === 'taken').length;
    const adherenceRate = totalScheduled > 0 ? (taken / totalScheduled) * 100 : 0;
    
    res.json({
      profile,
      vitals: vitalsByType,
      alerts: alerts.slice(0, 20), // Latest 20 alerts
      medications,
      adherenceRate,
      recentConversations: conversations.filter(c => c.direction === 'inbound').slice(0, 5)
    });
  } catch (error) {
    console.error('Get member overview error:', error);
    res.status(500).json({ error: "Failed to get member overview" });
  }
});

// GET /admin/alerts - Get alerts for admin's family
router.get("/alerts", async (req, res) => {
  try {
    const adminUserId = requireAuth(req);
    const { status = "open" } = req.query;
    
    const adminMembers = await storage.getFamilyMembersByAdmin(adminUserId);
    if (adminMembers.length === 0) {
      return res.json([]);
    }
    
    const familyId = adminMembers[0].familyId!;
    const alerts = await storage.getAlertsByFamily(familyId, status as string);
    
    // Enrich alerts with member info
    const enrichedAlerts = [];
    for (const alert of alerts) {
      const profile = await storage.getProfile(alert.userId!);
      enrichedAlerts.push({
        ...alert,
        memberName: profile?.fullName || 'Unknown Member'
      });
    }
    
    res.json(enrichedAlerts);
  } catch (error) {
    console.error('Get admin alerts error:', error);
    res.status(500).json({ error: "Failed to get alerts" });
  }
});

// POST /admin/alerts/:id/acknowledge - Acknowledge an alert
router.post("/alerts/:id/acknowledge", async (req, res) => {
  try {
    const adminUserId = requireAuth(req);
    const { id } = req.params;
    
    // TODO: Verify admin has access to this alert
    
    const updatedAlert = await storage.updateAlert(id, {
      status: "acknowledged",
      resolvedBy: adminUserId,
      resolvedAt: new Date()
    });
    
    res.json(updatedAlert);
  } catch (error) {
    console.error('Acknowledge alert error:', error);
    res.status(500).json({ error: "Failed to acknowledge alert" });
  }
});

// POST /admin/alerts/:id/resolve - Resolve an alert
router.post("/alerts/:id/resolve", async (req, res) => {
  try {
    const adminUserId = requireAuth(req);
    const { id } = req.params;
    const { notes } = req.body;
    
    const updatedAlert = await storage.updateAlert(id, {
      status: "resolved",
      resolvedBy: adminUserId,
      resolvedAt: new Date(),
      resolutionNotes: notes
    });
    
    res.json(updatedAlert);
  } catch (error) {
    console.error('Resolve alert error:', error);
    res.status(500).json({ error: "Failed to resolve alert" });
  }
});

// Additional routes for new family dashboard
router.get("/family-members", async (req, res) => {
  try {
    const adminUserId = requireAuth(req);
    const adminMembers = await storage.getFamilyMembersByAdmin(adminUserId);
    
    if (adminMembers.length === 0) {
      return res.json([]);
    }
    
    const familyId = adminMembers[0].familyId!;
    const members = await storage.getFamilyMembers(familyId);
    
    const memberDetails = [];
    for (const member of members) {
      const profile = await storage.getProfile(member.userId!);
      const recentVitals = await storage.getVitals(member.userId!, { range: "1d" });
      const openAlerts = await storage.getAlerts(member.userId!, "open");
      
      // Get latest vital for display
      const lastVital = recentVitals[0] || null;
      
      // Simple risk calculation
      const riskLevel = openAlerts.some(a => a.severity === 'high') ? 'high' :
                       openAlerts.some(a => a.severity === 'med') ? 'medium' : 'low';
      
      memberDetails.push({
        id: member.userId,
        fullName: profile?.fullName || 'Family Member',
        email: profile ? `member${member.userId?.slice(-4)}@family.com` : 'unknown@family.com',
        lastVital: lastVital ? {
          kind: lastVital.kind,
          value: lastVital.value,
          measuredAt: lastVital.measuredAt
        } : null,
        riskLevel,
        alertCount: openAlerts.length
      });
    }
    
    res.json(memberDetails);
  } catch (error) {
    console.error("Failed to get family members:", error);
    res.status(500).json({ error: "Failed to get family members" });
  }
});

router.get("/family-stats", async (req, res) => {
  try {
    const adminUserId = requireAuth(req);
    const adminMembers = await storage.getFamilyMembersByAdmin(adminUserId);
    
    if (adminMembers.length === 0) {
      return res.json({ totalMembers: 0, activeAlerts: 0, medicationAdherence: 0, recentEvents: 0 });
    }
    
    const familyId = adminMembers[0].familyId!;
    const members = await storage.getFamilyMembers(familyId);
    
    // Count active alerts across all family members
    let totalActiveAlerts = 0;
    for (const member of members) {
      const alerts = await storage.getAlerts(member.userId!, "open");
      totalActiveAlerts += alerts.length;
    }
    
    const stats = {
      totalMembers: members.length,
      activeAlerts: totalActiveAlerts,
      medicationAdherence: 85, // TODO: Calculate real adherence
      recentEvents: 2 // TODO: Count real device events
    };
    
    res.json(stats);
  } catch (error) {
    console.error("Failed to get family stats:", error);
    res.status(500).json({ error: "Failed to get family stats" });
  }
});

// Device events and family history routes
router.get("/member/:userId/family-history", async (req, res) => {
  try {
    const adminUserId = requireAuth(req);
    const { userId } = req.params;
    
    // Verify access
    const adminMembers = await storage.getFamilyMembersByAdmin(adminUserId);
    const memberIds = adminMembers.map(m => m.userId);
    
    if (!memberIds.includes(userId)) {
      return res.status(403).json({ error: "Access denied" });
    }
    
    // TODO: Implement family history storage and retrieval
    const familyHistory = [
      {
        id: "1",
        relation: "mother",
        condition: "diabetes",
        ageOfOnset: 45,
        status: "present",
        notes: "Type 2 diabetes diagnosed at 45"
      },
      {
        id: "2", 
        relation: "father",
        condition: "hypertension",
        ageOfOnset: 50,
        status: "present",
        notes: "High blood pressure, managed with medication"
      }
    ];
    
    res.json(familyHistory);
  } catch (error) {
    console.error("Failed to get family history:", error);
    res.status(500).json({ error: "Failed to get family history" });
  }
});

router.get("/member/:userId/device-events", async (req, res) => {
  try {
    const adminUserId = requireAuth(req);
    const { userId } = req.params;
    
    // Verify access
    const adminMembers = await storage.getFamilyMembersByAdmin(adminUserId);
    const memberIds = adminMembers.map(m => m.userId);
    
    if (!memberIds.includes(userId)) {
      return res.status(403).json({ error: "Access denied" });
    }
    
    // TODO: Implement device events storage and retrieval
    const deviceEvents = [
      {
        id: "1",
        event: "fall_detected",
        occurredAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
        meta: { 
          severity: "high", 
          location: "living_room",
          deviceId: "apple_watch_1" 
        }
      }
    ];
    
    res.json(deviceEvents);
  } catch (error) {
    console.error("Failed to get device events:", error);
    res.status(500).json({ error: "Failed to get device events" });
  }
});

export default router;
