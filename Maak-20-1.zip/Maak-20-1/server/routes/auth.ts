import { Router } from "express";
import { storage } from "../storage";
import { getCurrentUserId } from "../lib/supabase";

const router = Router();

// Bootstrap auth - create user record if doesn't exist
router.post("/bootstrap", async (req, res) => {
  try {
    const authId = req.body.auth_id;
    const email = req.body.email;
    
    if (!authId || !email) {
      return res.status(400).json({ error: "auth_id and email required" });
    }

    // Check if user already exists
    let user = await storage.getUserByAuthId(authId);
    
    if (!user) {
      // Create new user
      user = await storage.createUser({
        authId,
        email,
        role: "user"
      });
      
      // Create default profile
      await storage.updateProfile(user.id, {
        locale: "ar",
        updatedAt: new Date()
      });
      
      // Create default coaching preferences
      await storage.updateCoachingPrefs(user.id, {
        allowCheckins: true,
        allowMedReminders: true,
        shareVitalsWithAdmins: true,
        language: "ar",
        timezone: "Asia/Hebron"
      });
    }
    
    res.json({ user, created: !user });
  } catch (error) {
    console.error('Auth bootstrap error:', error);
    res.status(500).json({ error: "Failed to bootstrap user" });
  }
});

// Get current user info
router.get("/me", async (req, res) => {
  try {
    const userId = getCurrentUserId(req);
    if (!userId) {
      return res.status(401).json({ error: "Authentication required" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    const profile = await storage.getProfile(userId);
    const prefs = await storage.getCoachingPrefs(userId);
    
    res.json({ user, profile, prefs });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: "Failed to get user info" });
  }
});

export default router;
