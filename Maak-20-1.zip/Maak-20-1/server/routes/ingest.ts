import { Router } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { evaluateVitalAlerts } from "../lib/rules";
import { notificationService } from "../lib/notify";
import { requireAuth } from "../lib/supabase";

const router = Router();

// Vital ingestion schema
const vitalSchema = z.object({
  kind: z.string(),
  value: z.number(),
  unit: z.string().optional(),
  measured_at: z.string().datetime().optional(),
  source: z.string().optional().default("device")
});

const vitalsArraySchema = z.array(vitalSchema);

// POST /ingest/vitals - Generic vitals ingestion
router.post("/vitals", async (req, res) => {
  try {
    const userId = requireAuth(req);
    const vitalsData = vitalsArraySchema.parse(req.body);
    
    const vitals = vitalsData.map(vital => ({
      userId,
      kind: vital.kind,
      value: vital.value.toString(),
      unit: vital.unit,
      measuredAt: vital.measured_at ? new Date(vital.measured_at) : new Date(),
      source: vital.source
    }));
    
    const insertedVitals = await storage.insertVitals(vitals);
    
    // Check for alerts
    for (const vital of insertedVitals) {
      const alerts = evaluateVitalAlerts(vital);
      for (const alert of alerts) {
        const insertedAlert = await storage.insertAlert(alert);
        
        // Send critical alerts immediately
        if (alert.severity === 'high') {
          await notificationService.sendCriticalAlert(userId, alert.message!);
          await notificationService.notifyAdmins(userId, alert.message!, alert.severity);
        }
      }
    }
    
    res.json({ 
      message: "Vitals ingested successfully", 
      count: insertedVitals.length,
      alerts_created: insertedVitals.flatMap(v => evaluateVitalAlerts(v)).length
    });
  } catch (error) {
    console.error('Vitals ingestion error:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid vital data format", details: error.errors });
    }
    res.status(500).json({ error: "Failed to ingest vitals" });
  }
});

// POST /ingest/healthkit - Same as vitals but with HealthKit source
router.post("/healthkit", async (req, res) => {
  try {
    const userId = requireAuth(req);
    const vitalsData = vitalsArraySchema.parse(req.body);
    
    const vitals = vitalsData.map(vital => ({
      userId,
      kind: vital.kind,
      value: vital.value.toString(),
      unit: vital.unit,
      measuredAt: vital.measured_at ? new Date(vital.measured_at) : new Date(),
      source: "healthkit"
    }));
    
    const insertedVitals = await storage.insertVitals(vitals);
    
    // Check for alerts (same as vitals endpoint)
    for (const vital of insertedVitals) {
      const alerts = evaluateVitalAlerts(vital);
      for (const alert of alerts) {
        await storage.insertAlert(alert);
        
        if (alert.severity === 'high') {
          await notificationService.sendCriticalAlert(userId, alert.message!);
          await notificationService.notifyAdmins(userId, alert.message!, alert.severity);
        }
      }
    }
    
    res.json({ 
      message: "HealthKit data ingested successfully", 
      count: insertedVitals.length 
    });
  } catch (error) {
    console.error('HealthKit ingestion error:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid HealthKit data format", details: error.errors });
    }
    res.status(500).json({ error: "Failed to ingest HealthKit data" });
  }
});

// Device event ingestion schema
const deviceEventSchema = z.object({
  event: z.string(), // 'fall_detected', 'hard_impact', 'sos_triggered'
  occurred_at: z.string().datetime().optional(),
  device_id: z.string().optional(),
  meta: z.record(z.any()).optional()
});

// POST /ingest/device-event - Device event ingestion (falls, etc.)
router.post("/device-event", async (req, res) => {
  try {
    const userId = requireAuth(req);
    const eventData = deviceEventSchema.parse(req.body);
    
    // Insert device event
    const deviceEvent = {
      userId,
      event: eventData.event,
      occurredAt: eventData.occurred_at ? new Date(eventData.occurred_at) : new Date(),
      deviceId: eventData.device_id,
      meta: eventData.meta
    };
    
    // TODO: Add device event to storage (when schema is ready)
    console.log('Device event received:', deviceEvent);
    
    // Create alert for critical events like falls
    if (eventData.event === 'fall_detected') {
      const alert = {
        userId,
        type: 'fall',
        severity: 'high' as const,
        message: `Fall detected${eventData.meta?.location ? ` in ${eventData.meta.location}` : ''}`,
        status: 'open' as const,
        createdAt: new Date()
      };
      
      await storage.insertAlert(alert);
      
      // Notify admins immediately
      await notificationService.sendCriticalAlert(userId, alert.message);
      await notificationService.notifyAdmins(userId, alert.message, 'high');
    }
    
    res.json({ 
      message: "Device event processed successfully",
      event: eventData.event,
      alert_created: eventData.event === 'fall_detected'
    });
  } catch (error) {
    console.error('Device event ingestion error:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid device event format", details: error.errors });
    }
    res.status(500).json({ error: "Failed to process device event" });
  }
});

export default router;
