import { Router } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { extractEntities, generateResponse } from "../lib/zeina";
import { requireAuth } from "../lib/supabase";
import { jobRunner } from "../jobs/runner";

// Helper function to process extracted entities
async function processExtractedEntities(userId: string, extraction: any, language: string = 'ar') {
  try {
    // Auto-create alerts for concerning patterns
    if (extraction.confidence_score > 0.8 && extraction.symptoms) {
      const severeSymptomsCount = extraction.symptoms.filter((s: any) => s.severity >= 7).length;
      
      if (severeSymptomsCount > 0) {
        await storage.insertAlert({
          userId,
          type: "severe_symptoms",
          severity: "high",
          message: `${severeSymptomsCount} severe symptoms reported through conversation`,
          status: "open",
          // meta: { 
          //   extraction_id: extraction.id,
          //   symptoms: extraction.symptoms.filter((s: any) => s.severity >= 7)
          // }
        });
      }
    }
    
    // Intelligent follow-up scheduling based on multiple factors
    if (extraction.goals && extraction.goals.length > 0) {
      for (const goal of extraction.goals) {
        if (goal.deadline) {
          const followupTime = new Date(goal.deadline);
          followupTime.setDate(followupTime.getDate() - 1);
          
          await jobRunner.scheduleFollowup(
            userId,
            language === 'ar' 
              ? `تذكير بالهدف: ${goal.target} - كيف تسير الأمور؟`
              : `Goal reminder: ${goal.target} - How are things going?`,
            followupTime
          );
        }
      }
    }

    // Schedule medication follow-ups
    if (extraction.med_action && extraction.med_action.action === "missed") {
      const followupTime = new Date(Date.now() + 4 * 60 * 60 * 1000); // 4 hours later
      await jobRunner.scheduleFollowup(
        userId,
        language === 'ar'
          ? `تذكير لطيف: هل تمكنت من أخذ دواء ${extraction.med_action.medication}؟`
          : `Gentle reminder: Were you able to take your ${extraction.med_action.medication}?`,
        followupTime
      );
    }

    // Schedule symptom progression checks
    if (extraction.symptoms && extraction.symptoms.some((s: any) => s.severity && s.severity >= 6)) {
      const followupTime = new Date(Date.now() + 6 * 60 * 60 * 1000); // 6 hours later
      await jobRunner.scheduleFollowup(
        userId,
        language === 'ar'
          ? "كيف تشعر الآن؟ هل تحسنت الأعراض أم تحتاج للمزيد من المساعدة؟"
          : "How are you feeling now? Have your symptoms improved or do you need more help?",
        followupTime
      );
    }

    // Schedule vitals check-ins based on concerning trends
    if (extraction.vitals) {
      const hasHighBP = extraction.vitals.blood_pressure && 
        (extraction.vitals.blood_pressure.systolic > 140 || extraction.vitals.blood_pressure.diastolic > 90);
      
      if (hasHighBP) {
        const followupTime = new Date(Date.now() + 12 * 60 * 60 * 1000); // 12 hours later
        await jobRunner.scheduleFollowup(
          userId,
          language === 'ar'
            ? "كيف ضغط الدم اليوم؟ تذكر أن التمارين البسيطة والتنفس العميق يساعدان كثيراً."
            : "How's your blood pressure today? Remember that light exercise and deep breathing help a lot.",
          followupTime
        );
      }
    }
    
    // Create wellness score based on extracted data
    const wellnessFactors = {
      symptoms: extraction.symptoms?.length || 0,
      medication_adherence: extraction.med_action?.action === "taken" ? 1 : 0,
      lifestyle_positive: (extraction.lifestyle?.exercise ? 1 : 0) + 
                         (extraction.lifestyle?.sleep_quality >= 7 ? 1 : 0),
      stress_level: extraction.lifestyle?.stress_level || 5
    };
    
    const wellnessScore = Math.max(0, 10 - 
      (wellnessFactors.symptoms * 1.5) - 
      (wellnessFactors.stress_level * 0.5) + 
      (wellnessFactors.medication_adherence * 2) + 
      (wellnessFactors.lifestyle_positive * 1.5)
    );
    
    // Store wellness score as a vital
    if (wellnessScore > 0 && !isNaN(wellnessScore) && isFinite(wellnessScore)) {
      await storage.insertVital({
        userId,
        kind: "wellness_score",
        value: Math.round(wellnessScore).toString(),
        unit: "score",
        source: "zeina_analysis",
        measuredAt: new Date()
      });
    }
    
    logger.info('Entities processed successfully', userId, {
      symptoms: extraction.symptoms?.length || 0,
      vitals: extraction.vitals ? Object.keys(extraction.vitals).length : 0,
      wellness_score: Math.round(wellnessScore)
    });
    
  } catch (error) {
    logger.error('Entity processing error', userId, { error: error instanceof Error ? error.message : 'Unknown error' });
  }
}


import { logger } from "../lib/logger";

const router = Router();

// GET /me/vitals - Get user's vitals
router.get("/vitals", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const { range, kind } = req.query;
    
    const vitals = await storage.getVitals(userId, {
      range: range as string,
      kind: kind as string
    });
    
    // Group by kind for easier consumption by frontend
    const grouped = vitals.reduce((acc, vital) => {
      if (!acc[vital.kind]) acc[vital.kind] = [];
      acc[vital.kind].push(vital);
      return acc;
    }, {} as any);
    
    res.json(grouped);
  } catch (error) {
    logger.error('Get vitals error', undefined, { error: error instanceof Error ? error.message : 'Unknown error' });
    res.status(500).json({ error: "Failed to get vitals" });
  }
});

// GET /me/alerts - Get user's alerts
router.get("/alerts", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const { status } = req.query;
    
    const alerts = await storage.getAlerts(userId, status as string);
    res.json(alerts);
  } catch (error) {
    console.error('Get alerts error:', error);
    res.status(500).json({ error: "Failed to get alerts" });
  }
});

// GET /me/medications - Get user's medications
router.get("/medications", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    
    const medications = await storage.getMedications(userId);
    const todayLogs = await storage.getMedicationLogs(userId, new Date());
    
    res.json({ medications, todayLogs });
  } catch (error) {
    console.error('Get medications error:', error);
    res.status(500).json({ error: "Failed to get medications" });
  }
});

// GET /me/conversations - Get user's conversations
router.get("/conversations", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const { limit = 50 } = req.query;
    
    const conversations = await storage.getConversations(userId, parseInt(limit as string));
    res.json(conversations);
  } catch (error) {
    console.error('Get conversations error:', error);
    res.status(500).json({ error: "Failed to get conversations" });
  }
});

// POST /me/conversations - Send message to Zeina
const conversationSchema = z.object({
  message: z.string().min(1),
  language: z.string().optional().default("ar")
});

router.post("/conversations", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const { message, language } = conversationSchema.parse(req.body);
    
    // Store user message
    const userConversation = await storage.insertConversation({
      userId,
      direction: "inbound",
      channel: "in_app",
      message,
      meta: { language }
    });
    
    // Get user context for Zeina
    const recentVitals = await storage.getVitals(userId, { range: "1d" });
    const medications = await storage.getMedications(userId);
    const recentSymptoms = await storage.getSymptoms(userId, { range: "7d" });
    
    const context = {
      vitals: recentVitals.slice(0, 10),
      medications,
      symptoms: recentSymptoms
    };
    
    // Process with Zeina using enhanced context
    const extraction = await extractEntities(message, language, context);
    const response = await generateResponse(message, context, language);
    
    // Generate health goal coaching if goals are mentioned
    let goalCoaching = '';
    if (extraction.goals && extraction.goals.length > 0) {
      try {
        const { generateHealthGoalCoaching } = await import('../lib/zeina');
        goalCoaching = await generateHealthGoalCoaching(userId, context, language);
      } catch (error) {
        console.error('Goal coaching generation failed:', error);
      }
    }
    
    // Store Zeina response
    const zeinaConversation = await storage.insertConversation({
      userId,
      direction: "outbound",
      channel: "in_app", 
      message: response,
      meta: { 
        extraction,
        language,
        context_used: true
      }
    });
    
    // Process extracted entities automatically
    await processExtractedEntities(userId, extraction);
    
    // Store symptoms
    console.log('Processing extracted symptoms:', extraction.symptoms);
    if (extraction.symptoms && extraction.symptoms.length > 0) {
      console.log(`Found ${extraction.symptoms.length} symptoms to process for user ${userId}`);
      for (const symptom of extraction.symptoms) {
        // Handle both string and object formats
        let symptomLabel = '';
        if (typeof symptom === 'string') {
          symptomLabel = symptom;
        } else if (typeof symptom === 'object') {
          symptomLabel = symptom.label || symptom.location || '';
        }
        
        // Skip symptoms without valid labels
        if (!symptomLabel || typeof symptomLabel !== 'string' || !symptomLabel.trim()) {
          console.warn('Skipping symptom with invalid label:', symptom);
          continue;
        }
        
        // Convert body parts to medical conditions
        symptomLabel = convertBodyPartToCondition(symptomLabel.trim());
        
        // Skip if still a body part after conversion
        if (isBodyPart(symptomLabel)) {
          console.warn('Skipping body part that could not be converted:', symptomLabel);
          continue;
        }
        
        // Convert text severity to number
        let severityNumber = 5; // Default severity
        if (typeof symptom === 'object' && symptom.severity !== undefined) {
          if (typeof symptom.severity === 'number') {
            severityNumber = symptom.severity;
          } else if (typeof symptom.severity === 'string') {
            const severityText = (symptom.severity as string).toLowerCase();
            if (severityText.includes('mild') || severityText.includes('low')) severityNumber = 3;
            else if (severityText.includes('moderate') || severityText.includes('medium')) severityNumber = 5;
            else if (severityText.includes('severe') || severityText.includes('high')) severityNumber = 8;
            else if (severityText.includes('extreme') || severityText.includes('critical')) severityNumber = 10;
          }
        } else if (extraction.pain_score && typeof extraction.pain_score === 'number') {
          // Use pain score as severity if no symptom-specific severity
          severityNumber = extraction.pain_score;
        }
        
        console.log(`Storing symptom: ${symptomLabel} with severity ${severityNumber}`);
        await storage.insertSymptom({
          userId,
          label: symptomLabel.trim(),
          severity: severityNumber,
          onset: (typeof symptom === 'object' && symptom.onset) ? new Date(symptom.onset) : new Date()
        });
      }
      logger.info('Symptoms stored automatically', userId, { count: extraction.symptoms.length });
    } else {
      console.log('No symptoms found in extraction to store');
    }
    
    // Update medication logs
    if (extraction.med_action && extraction.med_action.medication) {
      const medication = medications.find(m => 
        m.name && m.name.toLowerCase().includes(extraction.med_action!.medication.toLowerCase())
      );
      
      if (medication) {
        await storage.insertMedicationLog({
          medicationId: medication.id,
          status: extraction.med_action.action,
          takenAt: extraction.med_action.time ? new Date(extraction.med_action.time) : new Date()
        });
        logger.info('Medication log updated automatically', userId, { 
          medication: medication.name,
          action: extraction.med_action.action 
        });
      }
    }
    
    // Store extracted pain score as vital
    if (extraction.pain_score !== undefined && extraction.pain_score !== null && typeof extraction.pain_score === 'number') {
      await storage.insertVital({
        userId,
        kind: "pain_score",
        value: extraction.pain_score.toString(),
        unit: "scale_0_10",
        source: "conversation",
        measuredAt: new Date()
      });
      logger.info('Pain score stored automatically', userId, { pain_score: extraction.pain_score });
    }
    
    // Note: Vitals extraction removed as ZeinaExtraction doesn't include vitals
    
    // Check for red flags
    if (extraction.flags && extraction.flags.length > 0) {
      await storage.insertAlert({
        userId,
        type: "symptom_concern",
        severity: "high",
        message: `Concerning symptoms reported: ${extraction.flags.join(', ')}`,
        status: "open"
      });
      
      // Schedule follow-up
      const followupTime = new Date(Date.now() + 2 * 60 * 60 * 1000); // 2 hours
      await jobRunner.scheduleFollowup(
        userId,
        language === 'ar' 
          ? "كيف تشعر الآن؟ أتمنى أن تكون الأعراض قد تحسنت"
          : "How are you feeling now? I hope your symptoms have improved",
        followupTime
      );
    }
    
    res.json({
      userMessage: userConversation,
      zeinaResponse: zeinaConversation,
      extraction
    });
  } catch (error) {
    console.error('Conversation error:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid message format", details: error.errors });
    }
    res.status(500).json({ error: "Failed to process conversation" });
  }
});

// POST /me/vitals - Manually log vitals
const manualVitalSchema = z.object({
  kind: z.string(),
  value: z.number(),
  unit: z.string().optional(),
  notes: z.string().optional()
});

router.post("/vitals", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const vitalData = manualVitalSchema.parse(req.body);
    
    const vital = await storage.insertVital({
      userId,
      kind: vitalData.kind,
      value: vitalData.value.toString(),
      unit: vitalData.unit,
      source: "manual",
      measuredAt: new Date()
    });
    
    res.json(vital);
  } catch (error) {
    console.error('Manual vital entry error:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid vital data", details: error.errors });
    }
    res.status(500).json({ error: "Failed to log vital" });
  }
});

// GET /me/symptoms - Get user's symptoms
router.get("/symptoms", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const { range } = req.query;
    
    const symptoms = await storage.getSymptoms(userId, {
      range: range as string
    });
    
    res.json(symptoms);
  } catch (error) {
    logger.error('Get symptoms error', undefined, { error: error instanceof Error ? error.message : 'Unknown error' });
    res.status(500).json({ error: "Failed to get symptoms" });
  }
});

// Mood Entries endpoints
const moodEntrySchema = z.object({
  moodScore: z.number().min(1).max(10),
  emotionalState: z.string().optional(),
  stressLevel: z.number().min(1).max(10),
  sleepQuality: z.number().min(1).max(10),
  energyLevel: z.number().min(1).max(10),
  notes: z.string().optional(),
  triggers: z.array(z.string()).optional(),
  copingStrategies: z.array(z.string()).optional()
});

const manualSymptomSchema = z.object({
  label: z.string().min(1).max(200),
  severity: z.number().min(0).max(10),
  notes: z.string().optional(),
  onset: z.string().optional().transform(val => val ? new Date(val) : new Date())
});

// POST /me/mood-entries - Create mood entry
router.post("/mood-entries", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const moodData = moodEntrySchema.parse(req.body);
    
    const moodEntry = await storage.insertMoodEntry({
      userId,
      moodScore: moodData.moodScore,
      emotionalState: moodData.emotionalState,
      stressLevel: moodData.stressLevel,
      sleepQuality: moodData.sleepQuality,
      energyLevel: moodData.energyLevel,
      notes: moodData.notes,
      triggers: moodData.triggers || [],
      copingStrategies: moodData.copingStrategies || []
    });
    
    logger.info('Mood entry created', userId, { moodEntry });
    res.json(moodEntry);
  } catch (error) {
    console.error('Mood entry creation error:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid mood data", details: error.errors });
    }
    res.status(500).json({ error: "Failed to create mood entry" });
  }
});

// GET /me/mood-entries - Get user's mood entries
router.get("/mood-entries", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const { range = "30d" } = req.query;
    
    const moodEntries = await storage.getMoodEntries(userId, {
      range: range as string
    });
    
    res.json(moodEntries);
  } catch (error) {
    logger.error('Get mood entries error', undefined, { error: error instanceof Error ? error.message : 'Unknown error' });
    res.status(500).json({ error: "Failed to get mood entries" });
  }
});

// POST /me/symptoms - Manually add symptom
router.post("/symptoms", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const symptomData = manualSymptomSchema.parse(req.body);
    
    const symptom = await storage.insertSymptom({
      userId,
      label: symptomData.label,
      severity: symptomData.severity,
      notes: symptomData.notes,
      onset: symptomData.onset,
      source: "manual"
    });
    
    // Provide resource recommendations based on symptom
    const recommendations = getSymptomResources(symptomData.label);
    
    logger.info('Manual symptom entry created', userId, { symptom });
    res.json({ symptom, recommendations });
  } catch (error) {
    console.error('Manual symptom entry error:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid symptom data", details: error.errors });
    }
    res.status(500).json({ error: "Failed to log symptom" });
  }
});

// Helper function to get resources based on symptom
function getSymptomResources(symptomLabel: string) {
  const lowerSymptom = symptomLabel.toLowerCase();
  const resources = [];
  
  if (lowerSymptom.includes('headache') || lowerSymptom.includes('migraine')) {
    resources.push(
      "Keep a headache diary to identify triggers",
      "Stay hydrated and maintain regular sleep schedule",
      "Consider stress management techniques like meditation",
      "If frequent, consult with a neurologist"
    );
  } else if (lowerSymptom.includes('stomach') || lowerSymptom.includes('nausea') || lowerSymptom.includes('abdominal')) {
    resources.push(
      "Eat small, frequent meals instead of large ones",
      "Avoid spicy, fatty, or acidic foods", 
      "Try ginger or peppermint tea for nausea relief",
      "If persistent, consider food diary and consult doctor"
    );
  } else if (lowerSymptom.includes('chest pain') || lowerSymptom.includes('heart')) {
    resources.push(
      "⚠️ If severe chest pain, seek immediate medical attention",
      "Avoid strenuous activity until evaluated",
      "Monitor heart rate and blood pressure regularly",
      "Schedule cardiology consultation if recurring"
    );
  } else if (lowerSymptom.includes('back pain') || lowerSymptom.includes('muscle')) {
    resources.push(
      "Apply ice for acute pain, heat for muscle tension",
      "Gentle stretching and movement when possible",
      "Consider ergonomic assessment of workspace",
      "Physical therapy may help with chronic pain"
    );
  } else if (lowerSymptom.includes('fever') || lowerSymptom.includes('temperature')) {
    resources.push(
      "Stay hydrated with water and electrolyte solutions",
      "Rest and avoid strenuous activities", 
      "Monitor temperature regularly",
      "Seek medical care if fever >38.5°C or persists >3 days"
    );
  } else if (lowerSymptom.includes('cough') || lowerSymptom.includes('throat')) {
    resources.push(
      "Stay hydrated and use humidifier",
      "Honey and warm liquids can soothe throat",
      "Avoid irritants like smoke and strong odors",
      "See doctor if cough persists >2 weeks or has blood"
    );
  } else {
    resources.push(
      "Monitor symptom progression and severity",
      "Keep detailed notes about triggers and patterns",
      "Maintain healthy lifestyle with proper sleep and nutrition",
      "Consult healthcare provider if symptoms worsen or persist"
    );
  }
  
  return resources;
}

// Helper functions for symptom processing
function convertBodyPartToCondition(label: string): string {
  const lowerLabel = label.toLowerCase();
  
  // Convert common body parts to medical conditions
  if (lowerLabel === 'head' || lowerLabel === 'راس' || lowerLabel === 'راسي') {
    return 'headache';
  }
  if (lowerLabel === 'stomach' || lowerLabel === 'بطن' || lowerLabel === 'بطني' || lowerLabel === 'معدة') {
    return 'stomach pain';
  }
  if (lowerLabel === 'chest' || lowerLabel === 'صدر' || lowerLabel === 'صدري') {
    return 'chest pain';
  }
  if (lowerLabel === 'back' || lowerLabel === 'ظهر' || lowerLabel === 'ظهري') {
    return 'back pain';
  }
  if (lowerLabel === 'whole body' || lowerLabel === 'كامل الجسم' || lowerLabel === 'كامل جسمي') {
    return 'body aches';
  }
  if (lowerLabel === 'neck' || lowerLabel === 'رقبة' || lowerLabel === 'رقبتي') {
    return 'neck pain';
  }
  if (lowerLabel === 'shoulder' || lowerLabel === 'كتف' || lowerLabel === 'كتفي') {
    return 'shoulder pain';
  }
  if (lowerLabel === 'leg' || lowerLabel === 'رجل' || lowerLabel === 'رجلي') {
    return 'leg pain';
  }
  if (lowerLabel === 'arm' || lowerLabel === 'ذراع' || lowerLabel === 'ذراعي') {
    return 'arm pain';
  }
  
  return label; // Return original if no conversion needed
}

function isBodyPart(label: string): boolean {
  const bodyParts = [
    'head', 'stomach', 'chest', 'back', 'neck', 'shoulder', 'leg', 'arm', 'whole body',
    'راس', 'بطن', 'صدر', 'ظهر', 'رقبة', 'كتف', 'رجل', 'ذراع', 'كامل الجسم'
  ];
  
  return bodyParts.includes(label.toLowerCase());
}

export default router;



// GET /me/proactive-checkin - Get personalized proactive check-in from Zeina
router.get("/proactive-checkin", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const { language = 'ar' } = req.query;
    
    // Get comprehensive user context
    const recentVitals = await storage.getVitals(userId, { range: "7d" });
    const medications = await storage.getMedications(userId);
    const recentSymptoms = await storage.getSymptoms(userId, { range: "7d" });
    const conversations = await storage.getConversations(userId, 10);
    
    const context = {
      vitals: recentVitals,
      medications,
      symptoms: recentSymptoms,
      conversations
    };
    
    const { generateProactiveCheckIn } = await import('../lib/zeina');
    const checkInMessage = await generateProactiveCheckIn(userId, context, language as string);
    
    res.json({
      message: checkInMessage,
      timestamp: new Date().toISOString(),
      context_used: {
        vitals_count: recentVitals.length,
        medications_count: medications.length,
        symptoms_count: recentSymptoms.length,
        conversations_count: conversations.length
      }
    });
  } catch (error) {
    logger.error('Proactive check-in error', undefined, { error: error instanceof Error ? error.message : 'Unknown error' });
    res.status(500).json({ error: "Failed to generate proactive check-in" });
  }
});

// GET /me/health-coaching - Get personalized health goal coaching
router.get("/health-coaching", async (req, res) => {
  try {
    const userId = await requireAuth(req);
    const { language = 'ar' } = req.query;
    
    // Get comprehensive context for coaching
    const recentVitals = await storage.getVitals(userId, { range: "30d" });
    const medications = await storage.getMedications(userId);
    const recentSymptoms = await storage.getSymptoms(userId, { range: "14d" });
    const conversations = await storage.getConversations(userId, 20);
    
    const context = {
      vitals: recentVitals,
      medications,
      symptoms: recentSymptoms,
      conversations
    };
    
    const { generateHealthGoalCoaching } = await import('../lib/zeina');
    const coachingMessage = await generateHealthGoalCoaching(userId, context, language as string);
    
    res.json({
      coaching: coachingMessage,
      timestamp: new Date().toISOString(),
      context_analysis: {
        vitals_trend: recentVitals.length > 0 ? 'available' : 'limited',
        goal_mentions: conversations.filter((c: any) => c.meta?.extraction?.goals?.length > 0).length
      }
    });
  } catch (error) {
    logger.error('Health coaching error', undefined, { error: error instanceof Error ? error.message : 'Unknown error' });
    res.status(500).json({ error: "Failed to generate health coaching" });
  }
});
