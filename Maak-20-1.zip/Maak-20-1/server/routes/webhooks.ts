import { Router } from "express";
import { jobRunner } from "../jobs/runner";

const router = Router();

// POST /webhooks/fitbit - Handle Fitbit subscription notifications
router.post("/fitbit", async (req, res) => {
  try {
    const { hub } = req.query;
    
    // Handle subscription verification
    if (hub && req.query['hub.mode'] === 'subscribe') {
      const challenge = req.query['hub.challenge'];
      const verify_token = req.query['hub.verify_token'];
      
      // TODO: Verify the token matches what you expect
      if (verify_token === process.env.FITBIT_VERIFY_TOKEN) {
        return res.status(200).send(challenge);
      } else {
        return res.status(403).send('Forbidden');
      }
    }
    
    // Handle actual notifications
    const notifications = req.body;
    
    if (!Array.isArray(notifications)) {
      return res.status(400).json({ error: "Expected array of notifications" });
    }
    
    for (const notification of notifications) {
      const { collectionType, date, ownerId, ownerType, subscriptionId } = notification;
      
      // Schedule a job to fetch the actual data
      await jobRunner.scheduleJob({
        userId: ownerId, // This would need mapping from Fitbit user ID to our user ID
        kind: 'fitbit_fetch',
        runAt: new Date(Date.now() + 30000), // Fetch in 30 seconds
        payload: {
          collectionType,
          date,
          ownerId,
          subscriptionId
        }
      });
    }
    
    res.status(204).send(); // Fitbit expects 204 No Content
  } catch (error) {
    console.error('Fitbit webhook error:', error);
    res.status(500).json({ error: "Failed to process Fitbit webhook" });
  }
});

// GET /webhooks/fitbit - Handle subscription verification
router.get("/fitbit", (req, res) => {
  const challenge = req.query['hub.challenge'];
  const verify_token = req.query['hub.verify_token'];
  
  if (verify_token === process.env.FITBIT_VERIFY_TOKEN) {
    res.status(200).send(challenge);
  } else {
    res.status(403).send('Forbidden');
  }
});

export default router;
