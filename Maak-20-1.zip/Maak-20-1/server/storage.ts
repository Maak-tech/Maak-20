import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, desc, and, gte, lte, inArray } from "drizzle-orm";
import * as schema from "@shared/schema";
import type { 
  User, InsertUser, Vital, InsertVital, 
  Conversation, InsertConversation, Alert, InsertAlert,
  Medication, InsertMedication, Profile, FamilyMember,
  CoachingPrefs, Symptom, MedicationLog, Job, MoodEntry, InsertMoodEntry
} from "@shared/schema";

const sql = neon(process.env.DATABASE_URL!);
const db = drizzle(sql, { schema });

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByAuthId(authId: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Profiles
  getProfile(userId: string): Promise<Profile | undefined>;
  updateProfile(userId: string, profile: Partial<Profile>): Promise<Profile>;

  // Family Management
  getFamilyMembers(familyId: string): Promise<FamilyMember[]>;
  getFamilyMembersByAdmin(adminUserId: string): Promise<FamilyMember[]>;

  // Vitals
  getVitals(userId: string, options?: { range?: string; kind?: string }): Promise<Vital[]>;
  insertVital(vital: InsertVital): Promise<Vital>;
  insertVitals(vitals: InsertVital[]): Promise<Vital[]>;

  // Conversations
  getConversations(userId: string, limit?: number): Promise<Conversation[]>;
  insertConversation(conversation: InsertConversation): Promise<Conversation>;

  // Alerts
  getAlerts(userId: string, status?: string): Promise<Alert[]>;
  getAlertsByFamily(familyId: string, status?: string): Promise<Alert[]>;
  insertAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: string, updates: Partial<Alert>): Promise<Alert>;

  // Medications
  getMedications(userId: string): Promise<Medication[]>;
  insertMedication(medication: InsertMedication): Promise<Medication>;
  getMedicationLogs(userId: string, date?: Date): Promise<MedicationLog[]>;
  insertMedicationLog(log: Partial<MedicationLog>): Promise<MedicationLog>;

  // Symptoms
  insertSymptom(symptom: Partial<Symptom>): Promise<Symptom>;
  getSymptoms(userId: string, options?: { range?: string }): Promise<Symptom[]>;

  // Mood Entries
  insertMoodEntry(moodEntry: Partial<MoodEntry>): Promise<MoodEntry>;
  getMoodEntries(userId: string, options?: { range?: string }): Promise<MoodEntry[]>;

  // Coaching Preferences
  getCoachingPrefs(userId: string): Promise<CoachingPrefs | undefined>;
  updateCoachingPrefs(userId: string, prefs: Partial<CoachingPrefs>): Promise<CoachingPrefs>;

  // Jobs
  getJobsDue(timestamp: Date): Promise<Job[]>;
  insertJob(job: Partial<Job>): Promise<Job>;
  updateJobStatus(id: string, status: string): Promise<void>;
}

export class DrizzleStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.id, id)).limit(1);
    return result[0];
  }

  async getUserByAuthId(authId: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.authId, authId)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.email, email)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(schema.users).values(user).returning();
    return result[0];
  }

  async getProfile(userId: string): Promise<Profile | undefined> {
    const result = await db.select().from(schema.profiles).where(eq(schema.profiles.userId, userId)).limit(1);
    return result[0];
  }

  async updateProfile(userId: string, profile: Partial<Profile>): Promise<Profile> {
    const result = await db.update(schema.profiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(schema.profiles.userId, userId))
      .returning();
    return result[0];
  }

  async getFamilyMembers(familyId: string): Promise<FamilyMember[]> {
    return await db.select().from(schema.familyMembers).where(eq(schema.familyMembers.familyId, familyId));
  }

  async getFamilyMembersByAdmin(adminUserId: string): Promise<FamilyMember[]> {
    const adminMember = await db.select()
      .from(schema.familyMembers)
      .where(and(
        eq(schema.familyMembers.userId, adminUserId),
        eq(schema.familyMembers.role, "admin")
      ))
      .limit(1);

    if (!adminMember[0]) return [];

    return await db.select().from(schema.familyMembers)
      .where(eq(schema.familyMembers.familyId, adminMember[0].familyId!));
  }

  async getVitals(userId: string, options: { range?: string; kind?: string } = {}): Promise<Vital[]> {
    const conditions = [eq(schema.vitals.userId, userId)];

    if (options.kind) {
      conditions.push(eq(schema.vitals.kind, options.kind));
    }

    if (options.range) {
      const days = parseInt(options.range.replace('d', ''));
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      conditions.push(gte(schema.vitals.measuredAt, startDate));
    }

    return await db.select().from(schema.vitals)
      .where(and(...conditions))
      .orderBy(desc(schema.vitals.measuredAt))
      .limit(100);
  }

  async insertVital(vital: InsertVital): Promise<Vital> {
    const result = await db.insert(schema.vitals).values(vital).returning();
    return result[0];
  }

  async insertVitals(vitals: InsertVital[]): Promise<Vital[]> {
    return await db.insert(schema.vitals).values(vitals).returning();
  }

  async getConversations(userId: string, limit: number = 50): Promise<Conversation[]> {
    return await db.select().from(schema.conversations)
      .where(eq(schema.conversations.userId, userId))
      .orderBy(desc(schema.conversations.createdAt))
      .limit(limit);
  }

  async insertConversation(conversation: InsertConversation): Promise<Conversation> {
    const result = await db.insert(schema.conversations).values(conversation).returning();
    return result[0];
  }

  async getAlerts(userId: string, status?: string): Promise<Alert[]> {
    const conditions = [eq(schema.alerts.userId, userId)];

    if (status) {
      conditions.push(eq(schema.alerts.status, status));
    }

    return await db.select().from(schema.alerts)
      .where(and(...conditions))
      .orderBy(desc(schema.alerts.createdAt))
      .limit(50);
  }

  async getAlertsByFamily(familyId: string, status?: string): Promise<Alert[]> {
    const members = await this.getFamilyMembers(familyId);
    const memberIds = members.map(m => m.userId!);

    if (memberIds.length === 0) return [];

    let query = db.select().from(schema.alerts)
      .where(inArray(schema.alerts.userId, memberIds))
      .orderBy(desc(schema.alerts.createdAt));

    if (status) {
      const conditions = [
        inArray(schema.alerts.userId, memberIds),
        eq(schema.alerts.status, status)
      ];
      query = db.select().from(schema.alerts)
        .where(and(...conditions))
        .orderBy(desc(schema.alerts.createdAt));
    }

    return await query.limit(100);
  }

  async insertAlert(alert: InsertAlert): Promise<Alert> {
    const result = await db.insert(schema.alerts).values(alert).returning();
    return result[0];
  }

  async updateAlert(id: string, updates: Partial<Alert>): Promise<Alert> {
    const result = await db.update(schema.alerts)
      .set(updates)
      .where(eq(schema.alerts.id, id))
      .returning();
    return result[0];
  }

  async getMedications(userId: string): Promise<Medication[]> {
    return await db.select().from(schema.medications)
      .where(eq(schema.medications.userId, userId));
  }

  async insertMedication(medication: InsertMedication): Promise<Medication> {
    const result = await db.insert(schema.medications).values(medication).returning();
    return result[0];
  }

  async getMedicationLogs(userId: string, date?: Date): Promise<MedicationLog[]> {
    let query = db.select().from(schema.medicationLogs)
      .innerJoin(schema.medications, eq(schema.medicationLogs.medicationId, schema.medications.id))
      .where(eq(schema.medications.userId, userId));

    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);

      query = db.select().from(schema.medicationLogs)
        .innerJoin(schema.medications, eq(schema.medicationLogs.medicationId, schema.medications.id))
        .where(and(
          eq(schema.medications.userId, userId),
          gte(schema.medicationLogs.scheduledAt, startOfDay),
          lte(schema.medicationLogs.scheduledAt, endOfDay)
        ));
    }

    const results = await query;
    return results.map(result => result.medication_logs);
  }

  async getCoachingPrefs(userId: string): Promise<CoachingPrefs | undefined> {
    const result = await db.select().from(schema.coachingPrefs)
      .where(eq(schema.coachingPrefs.userId, userId)).limit(1);
    return result[0];
  }

  async updateCoachingPrefs(userId: string, prefs: Partial<CoachingPrefs>): Promise<CoachingPrefs> {
    const result = await db.update(schema.coachingPrefs)
      .set({ ...prefs, updatedAt: new Date() })
      .where(eq(schema.coachingPrefs.userId, userId))
      .returning();
    return result[0];
  }

  async getJobsDue(timestamp: Date): Promise<Job[]> {
    return await db.select().from(schema.jobs)
      .where(and(
        lte(schema.jobs.runAt, timestamp),
        eq(schema.jobs.status, "queued")
      ))
      .limit(100);
  }

  async insertJob(job: Partial<Job>): Promise<Job> {
    const result = await db.insert(schema.jobs).values(job as any).returning();
    return result[0];
  }

  async updateJobStatus(id: string, status: string): Promise<void> {
    await db.update(schema.jobs)
      .set({ status })
      .where(eq(schema.jobs.id, id));
  }

  async insertMedicationLog(log: Partial<MedicationLog>): Promise<MedicationLog> {
    const result = await db.insert(schema.medicationLogs).values(log as any).returning();
    return result[0];
  }

  async insertSymptom(symptom: Partial<Symptom>): Promise<Symptom> {
    const result = await db.insert(schema.symptoms).values(symptom as any).returning();
    return result[0];
  }

  async getSymptoms(userId: string, options: { range?: string } = {}): Promise<Symptom[]> {
    const conditions = [eq(schema.symptoms.userId, userId)];

    if (options.range) {
      const days = parseInt(options.range.replace('d', ''));
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      conditions.push(gte(schema.symptoms.createdAt, startDate));
    }

    return await db.select().from(schema.symptoms)
      .where(and(...conditions))
      .orderBy(desc(schema.symptoms.createdAt))
      .limit(100);
  }

  async insertMoodEntry(moodEntry: Partial<MoodEntry>): Promise<MoodEntry> {
    const result = await db.insert(schema.moodEntries).values(moodEntry as any).returning();
    return result[0];
  }

  async getMoodEntries(userId: string, options: { range?: string } = {}): Promise<MoodEntry[]> {
    const conditions = [eq(schema.moodEntries.userId, userId)];

    if (options.range) {
      const days = parseInt(options.range.replace('d', ''));
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      conditions.push(gte(schema.moodEntries.recordedAt, startDate));
    }

    return await db.select().from(schema.moodEntries)
      .where(and(...conditions))
      .orderBy(desc(schema.moodEntries.recordedAt))
      .limit(100);
  }
}

export const storage = new DrizzleStorage();