import { sql } from "drizzle-orm";
import { pgTable, text, varchar, uuid, timestamp, numeric, integer, boolean, date, time, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// USERS / FAMILIES 
export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  authId: uuid("auth_id").unique().notNull(),
  email: text("email").unique().notNull(),
  role: text("role").notNull().default("user"),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

export const families = pgTable("families", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name"),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

export const familyMembers = pgTable("family_members", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  familyId: uuid("family_id").references(() => families.id, { onDelete: "cascade" }),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  role: text("role").notNull().default("member"),
});

export const profiles = pgTable("profiles", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  fullName: text("full_name"),
  dob: date("dob"),
  sex: text("sex"),
  conditions: text("conditions").array(),
  locale: text("locale").default("ar"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).default(sql`now()`),
});

// COACHING PREFS / CONSENT
export const coachingPrefs = pgTable("coaching_prefs", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  allowCheckins: boolean("allow_checkins").default(true),
  allowMedReminders: boolean("allow_med_reminders").default(true),
  shareVitalsWithAdmins: boolean("share_vitals_with_admins").default(true),
  quietHours: jsonb("quiet_hours").default(sql`'{"start":"21:00","end":"07:00"}'`),
  channels: text("channels").array().default(sql`'{in_app,email}'`),
  language: text("language").default("ar"),
  timezone: text("timezone").default("Asia/Hebron"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).default(sql`now()`),
});

// VITALS & SYMPTOMS
export const vitals = pgTable("vitals", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(),
  value: numeric("value").notNull(),
  unit: text("unit"),
  measuredAt: timestamp("measured_at", { withTimezone: true }).notNull().default(sql`now()`),
  source: text("source").default("device"),
});

export const symptoms = pgTable("symptoms", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  label: text("label").notNull(),
  severity: integer("severity"),
  onset: timestamp("onset", { withTimezone: true }),
  notes: text("notes"),
  source: text("source").default("zeina"),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

// MEDICATIONS
export const medications = pgTable("medications", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  dose: text("dose"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  instructions: text("instructions"),
  critical: boolean("critical").default(false),
  genericName: text("generic_name"),
  brandName: text("brand_name"),
  rxcui: text("rxcui"), // RxNorm Concept Unique Identifier for drug interaction API
  category: text("category"), // e.g., "blood_pressure", "diabetes", "pain"
  sideEffects: text("side_effects").array(),
  contraindications: text("contraindications").array(),
  foodInteractions: text("food_interactions").array(),
  adherenceTarget: integer("adherence_target").default(100), // Target adherence percentage
  reminderEnabled: boolean("reminder_enabled").default(true),
  prescribedBy: text("prescribed_by"),
  pharmacy: text("pharmacy"),
  notes: text("notes")
});

export const medicationSchedules = pgTable("medication_schedules", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  medicationId: uuid("medication_id").references(() => medications.id, { onDelete: "cascade" }),
  timeOfDay: time("time_of_day").notNull(),
  daysOfWeek: integer("days_of_week").array(),
});

export const medicationLogs = pgTable("medication_logs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  medicationId: uuid("medication_id").references(() => medications.id, { onDelete: "cascade" }),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  takenAt: timestamp("taken_at", { withTimezone: true }),
  status: text("status").notNull().default("pending"),
  source: text("source").default("user"),
  notes: text("notes"),
  sideEffectsReported: text("side_effects_reported").array(),
  adherenceScore: integer("adherence_score"), // Daily adherence score (0-100)
  remindersSent: integer("reminders_sent").default(0),
  delayMinutes: integer("delay_minutes").default(0) // How late was the medication taken
});

// DRUG INTERACTIONS
export const drugInteractions = pgTable("drug_interactions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  medicationId1: uuid("medication_id_1").references(() => medications.id, { onDelete: "cascade" }),
  medicationId2: uuid("medication_id_2").references(() => medications.id, { onDelete: "cascade" }),
  interactionType: text("interaction_type").notNull(), // "major", "moderate", "minor"
  severity: text("severity").notNull(), // "critical", "significant", "moderate", "minor"
  description: text("description").notNull(),
  recommendation: text("recommendation"),
  source: text("source").default("system"), // "system", "pharmacist", "doctor"
  acknowledgedAt: timestamp("acknowledged_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`)
});

// CONVERSATIONS & JOBS
export const conversations = pgTable("conversations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  direction: text("direction").notNull(),
  channel: text("channel").notNull(),
  message: text("message").notNull(),
  meta: jsonb("meta"),
  emergencyLevel: integer("emergency_level").default(0), // 0=normal, 1=concern, 2=urgent, 3=emergency
  moodScore: integer("mood_score"), // 1-10 mood rating extracted from conversation
  contextMemory: jsonb("context_memory"), // Previous conversation context and patterns
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

// Health Goals and Progress Tracking
export const healthGoals = pgTable("health_goals", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  targetValue: numeric("target_value"),
  currentValue: numeric("current_value").default("0"),
  unit: text("unit"), // kg, steps, hours, etc
  targetDate: date("target_date"),
  status: text("status").default("active"), // active, paused, completed, cancelled
  priority: integer("priority").default(1), // 1=low, 2=medium, 3=high
  category: text("category").notNull(), // fitness, nutrition, medication, mental_health, etc
  reminderFrequency: text("reminder_frequency"), // daily, weekly, etc
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).default(sql`now()`),
});

export const goalProgress = pgTable("goal_progress", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  goalId: uuid("goal_id").references(() => healthGoals.id, { onDelete: "cascade" }),
  value: numeric("value").notNull(),
  note: text("note"),
  loggedAt: timestamp("logged_at", { withTimezone: true }).default(sql`now()`),
});

// Mental Health and Mood Tracking
export const moodEntries = pgTable("mood_entries", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  moodScore: integer("mood_score").notNull(), // 1-10
  emotionalState: text("emotional_state"), // anxious, happy, stressed, calm, etc
  stressLevel: integer("stress_level"), // 1-10
  sleepQuality: integer("sleep_quality"), // 1-10
  energyLevel: integer("energy_level"), // 1-10
  notes: text("notes"),
  triggers: text("triggers").array(), // Array of mood triggers
  copingStrategies: text("coping_strategies").array(),
  conversationId: uuid("conversation_id").references(() => conversations.id),
  recordedAt: timestamp("recorded_at", { withTimezone: true }).default(sql`now()`),
});

// Health Insights and Reports
export const healthInsights = pgTable("health_insights", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(), // weekly_summary, monthly_report, trend_alert, recommendation
  title: text("title").notNull(),
  content: text("content").notNull(),
  insights: jsonb("insights"), // Structured insight data
  priority: integer("priority").default(1), // 1=low, 2=medium, 3=high
  status: text("status").default("unread"), // unread, read, archived
  generatedAt: timestamp("generated_at", { withTimezone: true }).default(sql`now()`),
  validUntil: timestamp("valid_until", { withTimezone: true }),
});

// Emergency and Alert System
export const emergencyContacts = pgTable("emergency_contacts", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  relationship: text("relationship"), // family, doctor, emergency, etc
  phoneNumber: text("phone_number"),
  email: text("email"),
  priority: integer("priority").default(1), // 1=primary, 2=secondary, etc
  notifyForEmergencies: boolean("notify_for_emergencies").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

// Health Device Integration
export const deviceConnections = pgTable("device_connections", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  deviceType: text("device_type").notNull(), // fitbit, apple_health, blood_pressure_monitor, etc
  deviceName: text("device_name"),
  connectionStatus: text("connection_status").default("connected"), // connected, disconnected, error
  lastSyncAt: timestamp("last_sync_at", { withTimezone: true }),
  syncFrequency: text("sync_frequency").default("hourly"), // hourly, daily, manual
  config: jsonb("config"), // Device-specific configuration
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

export const jobs = pgTable("jobs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(),
  runAt: timestamp("run_at", { withTimezone: true }).notNull(),
  payload: jsonb("payload"),
  status: text("status").default("queued"),
});

// ALERTS
export const alerts = pgTable("alerts", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  severity: text("severity").notNull(),
  message: text("message"),
  vitalId: uuid("vital_id").references(() => vitals.id),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
  status: text("status").default("open"),
  notifiedAdminIds: uuid("notified_admin_ids").array().default(sql`'{}'`),
  resolvedBy: uuid("resolved_by"),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  resolutionNotes: text("resolution_notes"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertVitalSchema = createInsertSchema(vitals).omit({
  id: true,
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
});

export const insertMedicationSchema = createInsertSchema(medications).omit({
  id: true,
});

export const insertMedicationLogSchema = createInsertSchema(medicationLogs).omit({
  id: true,
});

export const insertDrugInteractionSchema = createInsertSchema(drugInteractions).omit({
  id: true,
  createdAt: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertVital = z.infer<typeof insertVitalSchema>;
export type Vital = typeof vitals.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertMedication = z.infer<typeof insertMedicationSchema>;
export type Medication = typeof medications.$inferSelect;
export type InsertMedicationLog = z.infer<typeof insertMedicationLogSchema>;
export type MedicationLog = typeof medicationLogs.$inferSelect;
export type InsertDrugInteraction = z.infer<typeof insertDrugInteractionSchema>;
export type DrugInteraction = typeof drugInteractions.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;
export type Profile = typeof profiles.$inferSelect;
export type FamilyMember = typeof familyMembers.$inferSelect;
export type CoachingPrefs = typeof coachingPrefs.$inferSelect;
export type Symptom = typeof symptoms.$inferSelect;
export type InsertSymptom = typeof symptoms.$inferInsert;
export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = typeof moodEntries.$inferInsert;
export type MedicationSchedule = typeof medicationSchedules.$inferSelect;
export type Job = typeof jobs.$inferSelect;
