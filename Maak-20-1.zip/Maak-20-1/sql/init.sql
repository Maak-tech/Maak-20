-- USERS / FAMILIES
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_id UUID UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.families (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.family_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID REFERENCES public.families(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member',
  UNIQUE (family_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.profiles (
  user_id UUID PRIMARY KEY REFERENCES public.users(id) ON DELETE CASCADE,
  full_name TEXT, 
  dob DATE, 
  sex TEXT, 
  conditions TEXT[],
  locale TEXT DEFAULT 'ar', 
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- COACHING PREFS / CONSENT
CREATE TABLE IF NOT EXISTS public.coaching_prefs (
  user_id UUID PRIMARY KEY REFERENCES public.users(id) ON DELETE CASCADE,
  allow_checkins BOOLEAN DEFAULT true,
  allow_med_reminders BOOLEAN DEFAULT true,
  share_vitals_with_admins BOOLEAN DEFAULT true,
  quiet_hours JSONB DEFAULT '{"start":"21:00","end":"07:00"}',
  channels TEXT[] DEFAULT '{in_app,email}',
  language TEXT DEFAULT 'ar',
  timezone TEXT DEFAULT 'Asia/Hebron',
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- VITALS & SYMPTOMS
CREATE TABLE IF NOT EXISTS public.vitals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,              -- 'heart_rate','spo2','bp_systolic','bp_diastolic','temp','resp_rate','sleep_score','steps'
  value NUMERIC NOT NULL,
  unit TEXT,
  measured_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  source TEXT DEFAULT 'device'     -- 'healthkit','fitbit','device','manual'
);
CREATE INDEX IF NOT EXISTS idx_vitals_user_time ON public.vitals (user_id, measured_at DESC);

CREATE TABLE IF NOT EXISTS public.symptoms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  severity INT CHECK (severity BETWEEN 0 AND 10),
  onset TIMESTAMPTZ,
  notes TEXT,
  source TEXT DEFAULT 'zeina',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- MEDICATIONS
CREATE TABLE IF NOT EXISTS public.medications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  dose TEXT,
  start_date DATE,
  end_date DATE,
  instructions TEXT,
  critical BOOLEAN DEFAULT false
);

CREATE TABLE IF NOT EXISTS public.medication_schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  medication_id UUID REFERENCES public.medications(id) ON DELETE CASCADE,
  time_of_day TIME NOT NULL,
  days_of_week INT[]      -- [1..7] Mon..Sun; null = daily
);

CREATE TABLE IF NOT EXISTS public.medication_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  medication_id UUID REFERENCES public.medications(id) ON DELETE CASCADE,
  scheduled_at TIMESTAMPTZ NOT NULL,
  taken_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'pending',  -- 'taken'|'missed'|'pending'
  source TEXT DEFAULT 'user'
);

-- CONVERSATIONS & JOBS
CREATE TABLE IF NOT EXISTS public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  direction TEXT NOT NULL,  -- 'outbound'|'inbound'
  channel TEXT NOT NULL,    -- 'in_app'|'sms'|'email'|'whatsapp'
  message TEXT NOT NULL,
  meta JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,       -- 'daily_checkin'|'med_reminder'|'followup'|'fitbit_fetch'
  run_at TIMESTAMPTZ NOT NULL,
  payload JSONB,
  status TEXT DEFAULT 'queued'
);

-- ALERTS
CREATE TABLE IF NOT EXISTS public.alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,       -- 'fall','spo2_low','hr_high','bp_crisis','missed_meds','sleep_poor'
  severity TEXT NOT NULL,   -- 'low'|'med'|'high'
  message TEXT,
  vital_id UUID REFERENCES public.vitals(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  status TEXT DEFAULT 'open',  -- 'open'|'ack'|'resolved'
  notified_admin_ids UUID[] DEFAULT '{}',
  resolved_by UUID,
  resolved_at TIMESTAMPTZ,
  resolution_notes TEXT
);

-- RLS
ALTER TABLE public.vitals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medication_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medication_logs ENABLE ROW LEVEL SECURITY;

-- Helper to get current app user_id from auth
CREATE OR REPLACE VIEW public.v_current_user AS
SELECT id AS user_id, auth_id FROM public.users WHERE auth_id = auth.uid();

-- Policies: member sees own records
DO $$ BEGIN
  CREATE POLICY member_read_own_vitals ON public.vitals FOR SELECT USING (user_id = (SELECT user_id FROM public.v_current_user));
  CREATE POLICY member_insert_own_vitals ON public.vitals FOR INSERT WITH CHECK (user_id = (SELECT user_id FROM public.v_current_user));

  CREATE POLICY member_read_own_alerts ON public.alerts FOR SELECT USING (user_id = (SELECT user_id FROM public.v_current_user));

  CREATE POLICY member_read_own_conversations ON public.conversations FOR SELECT USING (user_id = (SELECT user_id FROM public.v_current_user));
  CREATE POLICY member_insert_own_conversations ON public.conversations FOR INSERT WITH CHECK (user_id = (SELECT user_id FROM public.v_current_user));

  CREATE POLICY member_read_own_meds ON public.medications FOR SELECT USING (user_id = (SELECT user_id FROM public.v_current_user));
  CREATE POLICY member_insert_own_meds ON public.medications FOR INSERT WITH CHECK (user_id = (SELECT user_id FROM public.v_current_user));

  CREATE POLICY member_read_own_jobs ON public.jobs FOR SELECT USING (user_id = (SELECT user_id FROM public.v_current_user));
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Admin read family members' vitals if sharing is on
CREATE POLICY admin_read_family_vitals ON public.vitals FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.family_members fm_admin
    JOIN public.family_members fm_member ON fm_admin.family_id = fm_member.family_id
    JOIN public.coaching_prefs cp ON cp.user_id = fm_member.user_id
    WHERE fm_admin.user_id = (SELECT user_id FROM public.v_current_user)
      AND fm_admin.role = 'admin'
      AND fm_member.user_id = public.vitals.user_id
      AND COALESCE(cp.share_vitals_with_admins, true) = true
  )
);

-- Trigger: create alerts on critical vitals
CREATE OR REPLACE FUNCTION public.fn_eval_vital_alert()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE sev TEXT; typ TEXT; msg TEXT;
BEGIN
  IF NEW.kind = 'spo2' AND NEW.value < 90 THEN
    sev := 'high'; typ := 'spo2_low'; msg := 'SpO₂ below 90%';
  ELSIF NEW.kind = 'heart_rate' AND NEW.value >= 130 THEN
    sev := 'med'; typ := 'hr_high'; msg := 'High heart rate';
  ELSIF NEW.kind = 'bp_systolic' AND NEW.value >= 180 THEN
    sev := 'high'; typ := 'bp_crisis'; msg := 'Hypertensive crisis';
  END IF;

  IF sev IS NOT NULL THEN
    INSERT INTO public.alerts(user_id, type, severity, message, vital_id, created_at, status)
    VALUES (NEW.user_id, typ, sev, msg, NEW.id, now(), 'open');
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_eval_vital_alert ON public.vitals;
CREATE TRIGGER trg_eval_vital_alert
AFTER INSERT ON public.vitals
FOR EACH ROW EXECUTE FUNCTION public.fn_eval_vital_alert();
